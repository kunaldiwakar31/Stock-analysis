package com.stockscreener.domain.repo;

import com.stockscreener.domain.TechnicalIndicator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Optional;

public interface TechnicalIndicatorRepository extends JpaRepository<TechnicalIndicator, Long> {

    Optional<TechnicalIndicator> findByCompanyIdAndTradeDate(Long companyId, LocalDate tradeDate);

    Optional<TechnicalIndicator> findFirstByCompanyIdOrderByTradeDateDesc(Long companyId);

    /**
     * Wipes a company's series before a full rebuild, so a shortened price history (e.g.
     * after a correction) can't leave a stale indicator row behind with no matching price.
     */
    @Modifying
    @Transactional
    @Query("delete from TechnicalIndicator t where t.companyId = :companyId")
    void deleteAllForCompany(@Param("companyId") Long companyId);
}
