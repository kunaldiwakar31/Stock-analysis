package com.stockscreener.screener;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns query text into tokens.
 *
 * <p>Unit suffixes are captured as part of the number token rather than discarded, because
 * {@code 18} and {@code 18%} must be distinguishable downstream: {@link ValueNormalizer}
 * needs to know whether the user was explicit about the unit before deciding whether
 * {@code 0.5} means "0.5%" or is a mistake for "50%".
 */
public class Lexer {

    private final String src;
    private int i;

    public Lexer(String src) {
        this.src = src == null ? "" : src;
    }

    public List<Token> tokenize() {
        List<Token> out = new ArrayList<>();
        while (true) {
            skipWhitespace();
            if (i >= src.length()) {
                out.add(new Token(Token.Type.EOF, "", i));
                return out;
            }
            int start = i;
            char c = src.charAt(i);

            if (c == '(') {
                i++;
                out.add(new Token(Token.Type.LPAREN, "(", start));
            } else if (c == ')') {
                i++;
                out.add(new Token(Token.Type.RPAREN, ")", start));
            } else if (c == ',') {
                i++;
                out.add(new Token(Token.Type.COMMA, ",", start));
            } else if (c == '"' || c == '\'') {
                out.add(readString(c));
            } else if (isOpStart(c)) {
                out.add(readOperator());
            } else if (Character.isDigit(c) || (c == '-' && peekDigit(i + 1))) {
                out.add(readNumber());
            } else if (Character.isLetter(c) || c == '_') {
                out.add(readWord());
            } else {
                throw new QueryException("UNEXPECTED_CHAR", start, String.valueOf(c),
                        "Unexpected character '" + c + "'");
            }
        }
    }

    private void skipWhitespace() {
        while (i < src.length() && Character.isWhitespace(src.charAt(i))) {
            i++;
        }
    }

    private boolean peekDigit(int idx) {
        return idx < src.length() && Character.isDigit(src.charAt(idx));
    }

    private boolean isOpStart(char c) {
        return c == '>' || c == '<' || c == '=' || c == '!' || c == '~'
                || c == '&' || c == '|';
    }

    private Token readOperator() {
        int start = i;
        char c = src.charAt(i);

        if (c == '&' || c == '|') {
            // Accept && and || as aliases for AND / OR.
            if (i + 1 < src.length() && src.charAt(i + 1) == c) {
                i += 2;
                return new Token(c == '&' ? Token.Type.AND : Token.Type.OR,
                        String.valueOf(c) + c, start);
            }
            throw new QueryException("UNEXPECTED_CHAR", start, String.valueOf(c),
                    "Use '&&' or 'AND', '||' or 'OR'");
        }

        if (i + 1 < src.length() && src.charAt(i + 1) == '=') {
            String op = src.substring(i, i + 2);
            i += 2;
            if (!op.equals(">=") && !op.equals("<=") && !op.equals("!=")) {
                throw new QueryException("BAD_OPERATOR", start, op, "Unknown operator '" + op + "'");
            }
            return new Token(Token.Type.OP, op, start);
        }

        i++;
        return new Token(Token.Type.OP, String.valueOf(c), start);
    }

    private Token readString(char quote) {
        int start = i;
        i++; // opening quote
        StringBuilder sb = new StringBuilder();
        while (i < src.length() && src.charAt(i) != quote) {
            sb.append(src.charAt(i));
            i++;
        }
        if (i >= src.length()) {
            throw new QueryException("UNTERMINATED_STRING", start, sb.toString(),
                    "Unterminated string literal");
        }
        i++; // closing quote
        return new Token(Token.Type.STRING, sb.toString(), start);
    }

    private Token readNumber() {
        int start = i;
        if (src.charAt(i) == '-') {
            i++;
        }
        boolean seenDot = false;
        while (i < src.length()) {
            char c = src.charAt(i);
            if (Character.isDigit(c)) {
                i++;
            } else if (c == '.' && !seenDot && peekDigit(i + 1)) {
                seenDot = true;
                i++;
            } else if (c == '_' || c == ',') {
                // Tolerate digit grouping only when a digit follows: "1_000".
                // A bare comma is the AND separator, so it must not be swallowed.
                if (peekDigit(i + 1) && c == '_') {
                    i++;
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        String numText = src.substring(start, i).replace("_", "");

        // Optional unit suffix, longest match first.
        String suffix = "";
        String[] suffixes = {"crore", "crores", "lakh", "lakhs", "days", "cr", "%", "x", "d", "l"};
        for (String s : suffixes) {
            if (matchesIgnoreCase(s)) {
                suffix = s.toLowerCase();
                i += s.length();
                break;
            }
        }
        return new Token(Token.Type.NUMBER, numText, suffix, start);
    }

    private boolean matchesIgnoreCase(String s) {
        if (i + s.length() > src.length()) {
            return false;
        }
        if (!src.regionMatches(true, i, s, 0, s.length())) {
            return false;
        }
        // A letter suffix must not run into an identifier: "1000crore" is fine,
        // "1000crores_x" is not a unit.
        int after = i + s.length();
        if (after < src.length()) {
            char c = src.charAt(after);
            if (Character.isLetterOrDigit(c) || c == '_') {
                return false;
            }
        }
        return true;
    }

    private Token readWord() {
        int start = i;
        while (i < src.length()) {
            char c = src.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '_' || c == '.') {
                i++;
            } else {
                break;
            }
        }
        String w = src.substring(start, i);
        String u = w.toUpperCase();
        switch (u) {
            case "AND":
                return new Token(Token.Type.AND, w, start);
            case "OR":
                return new Token(Token.Type.OR, w, start);
            case "NOT":
                return new Token(Token.Type.NOT, w, start);
            case "BETWEEN":
                return new Token(Token.Type.BETWEEN, w, start);
            case "IN":
                return new Token(Token.Type.IN, w, start);
            case "IS":
                return new Token(Token.Type.IS, w, start);
            case "NULL":
                return new Token(Token.Type.NULL, w, start);
            case "TRUE":
            case "FALSE":
                return new Token(Token.Type.BOOL, w.toLowerCase(), start);
            default:
                return new Token(Token.Type.IDENT, w, start);
        }
    }
}
