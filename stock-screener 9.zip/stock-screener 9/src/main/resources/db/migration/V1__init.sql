-- Stock screener schema.
-- Money in `financials` is stored in Rupees LAKH (the unit NSE filings mostly use).
-- Money in `company_metrics` is stored in Rupees CRORE (the unit users type queries in).
-- Percentages are stored as plain numbers: 18.50 means 18.50%.

CREATE TABLE companies (
  id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  symbol             VARCHAR(30)  NOT NULL,
  company_name       VARCHAR(255) NOT NULL,
  isin               VARCHAR(12)  NULL,
  sector             VARCHAR(100) NULL,
  is_financial_co    BOOLEAN      NOT NULL DEFAULT FALSE,
  face_value         DECIMAL(12,4) NULL,
  shares_outstanding DECIMAL(20,2) NULL,
  status             VARCHAR(20)  NOT NULL DEFAULT 'ACTIVE',
  created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                       ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_companies_symbol (symbol),
  KEY idx_companies_sector (sector)
) ENGINE=InnoDB;

CREATE TABLE financials (
  id                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id           BIGINT UNSIGNED NOT NULL,
  period_end           DATE       NOT NULL,
  period_type          VARCHAR(8) NOT NULL,   -- Q | FY
  consolidated         BOOLEAN    NOT NULL,
  months_covered       INT        NOT NULL,   -- 3 or 12
  derivation           VARCHAR(10) NOT NULL,  -- REPORTED | YTD_DIFF
  audited              BOOLEAN    NULL,
  source_url           VARCHAR(700) NULL,
  rounding_level       VARCHAR(12) NULL,      -- as declared by the filer
  filed_at             DATETIME   NULL,

  revenue              DECIMAL(22,2) NULL,
  other_income         DECIMAL(22,2) NULL,
  total_expenses       DECIMAL(22,2) NULL,
  operating_profit     DECIMAL(22,2) NULL,
  depreciation         DECIMAL(22,2) NULL,
  finance_costs        DECIMAL(22,2) NULL,
  profit_before_tax    DECIMAL(22,2) NULL,
  tax_expense          DECIMAL(22,2) NULL,
  net_profit           DECIMAL(22,2) NULL,
  eps                  DECIMAL(14,4) NULL,

  total_equity         DECIMAL(22,2) NULL,
  total_borrowings     DECIMAL(22,2) NULL,
  cash_and_investments DECIMAL(22,2) NULL,
  total_assets         DECIMAL(22,2) NULL,
  paid_up_capital      DECIMAL(22,2) NULL,

  cash_from_operations DECIMAL(22,2) NULL,
  capex                DECIMAL(22,2) NULL,
  dividends_paid       DECIMAL(22,2) NULL,

  warnings             JSON NULL,
  created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_fin (company_id, period_end, period_type, consolidated),
  KEY idx_fin_lookup (company_id, period_type, period_end DESC),
  CONSTRAINT fk_fin_company FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;

CREATE TABLE daily_prices (
  id          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id  BIGINT UNSIGNED NOT NULL,
  trade_date  DATE NOT NULL,
  close_price DECIMAL(14,4) NOT NULL,
  high_price  DECIMAL(14,4) NULL,
  low_price   DECIMAL(14,4) NULL,
  volume      BIGINT NULL,
  UNIQUE KEY uk_price (company_id, trade_date),
  KEY idx_price_date (trade_date DESC),
  CONSTRAINT fk_price_company FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;

CREATE TABLE company_metrics (
  company_id            BIGINT UNSIGNED PRIMARY KEY,
  as_of_date            DATE NOT NULL,
  basis                 VARCHAR(12) NOT NULL,   -- CONSOLIDATED | STANDALONE

  -- Denormalised from companies on purpose. This is a read model: keeping the profile
  -- fields here means a screener query never joins, and symbol/name/sector become
  -- filterable without one.
  symbol                VARCHAR(30)  NOT NULL,
  company_name          VARCHAR(255) NOT NULL,
  sector                VARCHAR(100) NULL,
  is_financial_co       BOOLEAN NOT NULL DEFAULT FALSE,

  current_price         DECIMAL(14,4) NULL,
  market_cap_cr         DECIMAL(20,2) NULL,
  high_52w              DECIMAL(14,4) NULL,
  low_52w               DECIMAL(14,4) NULL,
  pct_from_high         DECIMAL(10,4) NULL,

  pe_ratio              DECIMAL(14,4) NULL,
  pb_ratio              DECIMAL(14,4) NULL,
  book_value            DECIMAL(14,4) NULL,
  ev_to_ebitda          DECIMAL(14,4) NULL,
  dividend_yield_pct    DECIMAL(10,4) NULL,
  earnings_yield_pct    DECIMAL(10,4) NULL,

  roe_pct               DECIMAL(12,4) NULL,
  roce_pct              DECIMAL(12,4) NULL,
  roa_pct               DECIMAL(12,4) NULL,

  operating_margin_pct  DECIMAL(12,4) NULL,
  net_profit_margin_pct DECIMAL(12,4) NULL,

  debt_to_equity        DECIMAL(12,4) NULL,
  interest_coverage     DECIMAL(12,4) NULL,

  sales_ttm_cr          DECIMAL(20,2) NULL,
  ebitda_ttm_cr         DECIMAL(20,2) NULL,
  net_profit_ttm_cr     DECIMAL(20,2) NULL,
  eps_ttm               DECIMAL(14,4) NULL,
  cfo_ttm_cr            DECIMAL(20,2) NULL,
  fcf_ttm_cr            DECIMAL(20,2) NULL,
  ocf_to_net_profit     DECIMAL(12,4) NULL,

  sales_growth_1y_pct   DECIMAL(12,4) NULL,
  sales_growth_2y_pct   DECIMAL(12,4) NULL,
  sales_growth_3y_pct   DECIMAL(12,4) NULL,
  sales_growth_5y_pct   DECIMAL(12,4) NULL,
  profit_growth_1y_pct  DECIMAL(12,4) NULL,
  profit_growth_2y_pct  DECIMAL(12,4) NULL,
  profit_growth_3y_pct  DECIMAL(12,4) NULL,
  profit_growth_5y_pct  DECIMAL(12,4) NULL,
  eps_growth_3y_pct     DECIMAL(12,4) NULL,

  qtr_sales_yoy_pct     DECIMAL(12,4) NULL,
  qtr_profit_yoy_pct    DECIMAL(12,4) NULL,

  promoter_holding_pct  DECIMAL(8,4) NULL,
  promoter_pledge_pct   DECIMAL(8,4) NULL,
  fii_holding_pct       DECIMAL(8,4) NULL,
  dii_holding_pct       DECIMAL(8,4) NULL,
  public_holding_pct    DECIMAL(8,4) NULL,

  llm_verdict           VARCHAR(20) NULL,
  llm_score             INT NULL,
  llm_summary           TEXT NULL,
  llm_analyzed_at       DATETIME NULL,

  data_completeness_pct DECIMAL(6,2) NULL,
  warnings              JSON NULL,
  updated_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                          ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_m_symbol (symbol),
  KEY idx_m_roe (roe_pct),
  KEY idx_m_roce (roce_pct),
  KEY idx_m_pe (pe_ratio),
  KEY idx_m_mcap (market_cap_cr),
  KEY idx_m_verdict (llm_verdict),
  KEY idx_m_sector (sector),
  CONSTRAINT fk_m_company FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;

-- Operational log, not domain data. Exists because 23k downloads need
-- restartability and a record of what failed and why.
CREATE TABLE filing_ingest (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  symbol         VARCHAR(30) NOT NULL,
  company_name   VARCHAR(255) NULL,
  quarter_end    DATE NOT NULL,
  consolidated   BOOLEAN NOT NULL,
  submission_type VARCHAR(12) NOT NULL,
  audited        BOOLEAN NULL,
  xbrl_url       VARCHAR(700) NOT NULL,
  html_url       VARCHAR(700) NULL,
  broadcast_at   DATETIME NULL,
  status         VARCHAR(12) NOT NULL DEFAULT 'PENDING', -- PENDING|DONE|FAILED|SKIPPED
  attempts       INT NOT NULL DEFAULT 0,
  error_message  TEXT NULL,
  created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                   ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uk_ingest_url (xbrl_url),
  KEY idx_ingest_status (status),
  KEY idx_ingest_natural (symbol, quarter_end, consolidated)
) ENGINE=InnoDB;
