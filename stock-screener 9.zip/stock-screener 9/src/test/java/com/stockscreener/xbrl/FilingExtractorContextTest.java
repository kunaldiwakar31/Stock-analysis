package com.stockscreener.xbrl;

import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Context selection.
 *
 * <p>Regression cover for the reason some filings stored nulls: selection used to match on
 * shape alone — plain, duration, exact end date — so it only worked when the primary
 * statement happened to sit on the undimensioned context. Selection is now driven by which
 * context actually carries the mapped facts, with shape used only to rank ties.
 */
class FilingExtractorContextTest {

    private static final LocalDate Q_END = LocalDate.of(2025, 9, 30);

    private final FilingExtractor extractor = new FilingExtractor(new ConceptMap());

    // ------------------------------------------------------------------
    // Fixture helpers
    // ------------------------------------------------------------------

    private XbrlDocument.Context duration(String id, LocalDate start, LocalDate end,
                                          String dims) {
        XbrlDocument.Context c = new XbrlDocument.Context();
        c.id = id;
        c.start = start;
        c.end = end;
        c.dimensionKey = dims == null ? "" : dims;
        return c;
    }

    private XbrlDocument.Context instant(String id, LocalDate at, String dims) {
        XbrlDocument.Context c = new XbrlDocument.Context();
        c.id = id;
        c.instant = at;
        c.dimensionKey = dims == null ? "" : dims;
        return c;
    }

    private void addContext(XbrlDocument doc, XbrlDocument.Context c) {
        doc.contexts.put(c.id, c);
    }

    private void fact(XbrlDocument doc, String concept, String ctxId, String value) {
        XbrlDocument.Fact f = new XbrlDocument.Fact();
        f.concept = concept;
        f.contextRef = ctxId;
        f.value = value;
        doc.facts.add(f);
    }

    /** Puts a full profit and loss account on one context. */
    private void addPnl(XbrlDocument doc, String ctxId, String revenue, String netProfit) {
        fact(doc, "RevenueFromOperations", ctxId, revenue);
        fact(doc, "OtherIncome", ctxId, "624");
        fact(doc, "Expenses", ctxId, "27556");
        fact(doc, "DepreciationDepletionAndAmortisationExpense", ctxId, "1865");
        fact(doc, "FinanceCosts", ctxId, "122");
        fact(doc, "ProfitBeforeTax", ctxId, "11180");
        fact(doc, "TaxExpense", ctxId, "3272");
        fact(doc, "ProfitLossForPeriod", ctxId, netProfit);
    }

    private void addBalanceSheet(XbrlDocument doc, String ctxId) {
        fact(doc, "Assets", ctxId, "65144");
        fact(doc, "Equity", ctxId, "51644");
        fact(doc, "Liabilities", ctxId, "13500");
        fact(doc, "CashAndCashEquivalents", ctxId, "2905");
        fact(doc, "Inventories", ctxId, "3665");
    }

    private XbrlDocument baseDoc() {
        XbrlDocument doc = new XbrlDocument();
        addContext(doc, duration("MetaD", LocalDate.of(2025, 4, 1), Q_END, null));
        fact(doc, "LevelOfRoundingUsedInFinancialResults", "MetaD", "Lakhs");
        fact(doc, "ISIN", "MetaD", "INE594H01019");
        return doc;
    }

    private FilingExtractor.Result extract(XbrlDocument doc) {
        doc.index();
        return extractor.extract(doc, Q_END, false, "https://example/test.xml", Boolean.FALSE);
    }

    private Financial quarterRow(FilingExtractor.Result res) {
        for (Financial f : res.rows) {
            if (f.getPeriodType() == PeriodType.Q) {
                return f;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // The actual bug
    // ------------------------------------------------------------------

    @Test
    @DisplayName("picks a dimensioned context when that is where the facts are")
    void prefersFactsOverShape() {
        XbrlDocument doc = baseDoc();
        // The plain context a shape-only match would have chosen — and it is empty.
        addContext(doc, duration("OneD", LocalDate.of(2025, 7, 1), Q_END, null));
        // The statement actually lives on a context tagged with a consolidation axis.
        addContext(doc, duration("ThreeD_Cons", LocalDate.of(2025, 7, 1), Q_END,
                "ResultTypeAxis=ConsolidatedMember"));
        addPnl(doc, "ThreeD_Cons", "20223", "4303");

        FilingExtractor.Result res = extract(doc);

        Financial q = quarterRow(res);
        assertNotNull(q, "shape-only matching returned nothing here");
        assertEquals(0, new BigDecimal("20223").compareTo(q.getRevenue()));
        assertEquals(0, new BigDecimal("4303").compareTo(q.getNetProfit()));
        assertTrue(res.warnings.stream().anyMatch(w -> w.startsWith("pnl_on_dimensioned")),
                "using a dimensioned context should be recorded: " + res.warnings);
    }

    @Test
    @DisplayName("ignores the prior-year comparative in the same instance")
    void ignoresComparatives() {
        XbrlDocument doc = baseDoc();
        // Same three-month shape, one year earlier. Present in nearly every real filing.
        addContext(doc, duration("PriorD", LocalDate.of(2024, 7, 1),
                LocalDate.of(2024, 9, 30), null));
        addPnl(doc, "PriorD", "17500", "3600");

        addContext(doc, duration("CurrentD", LocalDate.of(2025, 7, 1), Q_END, null));
        addPnl(doc, "CurrentD", "20223", "4303");

        Financial q = quarterRow(extract(doc));
        assertNotNull(q);
        assertEquals(0, new BigDecimal("20223").compareTo(q.getRevenue()),
                "the current period must win over the comparative");
    }

    @Test
    @DisplayName("tolerates a period end a few days off the exchange label")
    void tolerantEndDate() {
        XbrlDocument doc = baseDoc();
        // A 52/53-week filer, or a preparer off by a day. Exact matching found nothing.
        addContext(doc, duration("WeekD", LocalDate.of(2025, 7, 1),
                LocalDate.of(2025, 9, 27), null));
        addPnl(doc, "WeekD", "20223", "4303");

        FilingExtractor.Result res = extract(doc);
        Financial q = quarterRow(res);
        assertNotNull(q, "a period end three days early should still be matched");
        assertTrue(res.warnings.stream().anyMatch(w -> w.contains("2025-09-27")),
                "the date mismatch must be recorded: " + res.warnings);
    }

    @Test
    @DisplayName("does not mistake the cumulative window for the quarter")
    void doesNotTreatYtdAsQuarter() {
        XbrlDocument doc = baseDoc();
        // Only a six-month cumulative column was filed, which is legal.
        addContext(doc, duration("SixD", LocalDate.of(2025, 4, 1), Q_END, null));
        addPnl(doc, "SixD", "38112", "7908");

        FilingExtractor.Result res = extract(doc);
        Financial row = quarterRow(res);
        assertNotNull(row);
        assertEquals(6, row.getMonthsCovered(),
                "six months of revenue must not be labelled a quarter");
        assertTrue(res.warnings.contains("only_ytd_reported_6m"));
    }

    @Test
    @DisplayName("separates the quarter from the cumulative window when both are filed")
    void separatesQuarterAndYtd() {
        XbrlDocument doc = baseDoc();
        addContext(doc, duration("ThreeD", LocalDate.of(2025, 7, 1), Q_END, null));
        addPnl(doc, "ThreeD", "20223", "4303");
        addContext(doc, duration("SixD", LocalDate.of(2025, 4, 1), Q_END, null));
        addPnl(doc, "SixD", "38112", "7908");

        Financial q = quarterRow(extract(doc));
        assertNotNull(q);
        assertEquals(3, q.getMonthsCovered());
        assertEquals(0, new BigDecimal("20223").compareTo(q.getRevenue()));
    }

    @Test
    @DisplayName("finds the balance sheet on an instant context and checks it balances")
    void readsBalanceSheet() {
        XbrlDocument doc = baseDoc();
        addContext(doc, duration("ThreeD", LocalDate.of(2025, 7, 1), Q_END, null));
        addPnl(doc, "ThreeD", "20223", "4303");
        addContext(doc, instant("OneI", Q_END, null));
        addBalanceSheet(doc, "OneI");

        FilingExtractor.Result res = extract(doc);
        Financial q = quarterRow(res);
        assertNotNull(q);
        assertEquals(0, new BigDecimal("51644").compareTo(q.getTotalEquity()));
        assertEquals(0, new BigDecimal("65144").compareTo(q.getTotalAssets()));
        // 65144 = 51644 + 13500, so no imbalance should be reported.
        assertFalse(res.warnings.stream().anyMatch(w -> w.startsWith("balance_sheet_does_not")),
                "unexpected imbalance: " + res.warnings);
    }

    @Test
    @DisplayName("reports every context when nothing matches, instead of storing silent nulls")
    void dumpsContextsOnFailure() {
        XbrlDocument doc = baseDoc();
        // Facts exist, but a year away from the expected period.
        addContext(doc, duration("FarD", LocalDate.of(2023, 7, 1),
                LocalDate.of(2023, 9, 30), null));
        addPnl(doc, "FarD", "9999", "999");

        FilingExtractor.Result res = extract(doc);
        assertTrue(res.rows.isEmpty());
        assertTrue(res.warnings.contains("no_period_context_matching_2025-09-30"));
        assertFalse(res.contextDump.isEmpty(), "the failure must be diagnosable");
        assertTrue(res.contextDump.stream().anyMatch(s -> s.contains("FarD")));
    }

    @Test
    @DisplayName("a filing with no declared rounding level is rejected, not guessed")
    void rejectsMissingRoundingLevel() {
        XbrlDocument doc = new XbrlDocument();
        addContext(doc, duration("ThreeD", LocalDate.of(2025, 7, 1), Q_END, null));
        addPnl(doc, "ThreeD", "20223", "4303");
        doc.index();

        // Guessing the scale risks a hundredfold error in every figure from this filing.
        org.junit.jupiter.api.Assertions.assertThrows(IllegalArgumentException.class,
                () -> extractor.extract(doc, Q_END, false, "https://example/x.xml", null));
    }

    @Test
    @DisplayName("date parsing accepts the forms that appear in real instances")
    void parsesDateVariants() {
        assertEquals(LocalDate.of(2025, 9, 30), XbrlStaxParser.parseDate("2025-09-30"));
        assertEquals(LocalDate.of(2025, 9, 30), XbrlStaxParser.parseDate("2025-09-30+05:30"));
        assertEquals(LocalDate.of(2025, 9, 30),
                XbrlStaxParser.parseDate("2025-09-30T00:00:00"));
        assertEquals(LocalDate.of(2025, 9, 30), XbrlStaxParser.parseDate("30-09-2025"));
        assertEquals(LocalDate.of(2025, 9, 30), XbrlStaxParser.parseDate("30-Sep-2025"));
        assertNull(XbrlStaxParser.parseDate(null));
        assertNull(XbrlStaxParser.parseDate("not a date"));
    }
}
