package com.stockscreener.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "companies")
@Getter
@Setter
public class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 30)
    private String symbol;

    @Column(name = "company_name", nullable = false)
    private String companyName;

    @Column(length = 12)
    private String isin;

    @Column(length = 100)
    private String sector;

    /**
     * Banks and NBFCs. ROCE, debt/equity and EV/EBITDA are skipped for these rather
     * than computed, because leverage of six times is ordinary banking rather than
     * distress and a screener that ranks them alongside manufacturers is misleading.
     */
    @Column(name = "is_financial_co", nullable = false)
    private boolean financialCo;

    /** Rupees per share, as filed. Needed to derive the share count. */
    @Column(name = "face_value")
    private BigDecimal faceValue;

    /** Absolute share count, derived as paid-up capital / face value. */
    @Column(name = "shares_outstanding")
    private BigDecimal sharesOutstanding;

    @Column(nullable = false, length = 20)
    private String status = "ACTIVE";

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
