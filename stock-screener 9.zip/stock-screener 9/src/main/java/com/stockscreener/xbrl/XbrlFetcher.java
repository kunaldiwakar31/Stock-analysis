package com.stockscreener.xbrl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;

/**
 * Downloads XBRL instances, with an on-disk cache.
 *
 * <p>The cache is not an optimisation, it is the working assumption. Filings are immutable
 * and a revision arrives as a new URL, so any instance already on disk never needs
 * refetching. That means a concept-mapping fix can be applied by re-parsing roughly 23,000
 * cached files instead of re-downloading them — which is the difference between a
 * five-minute iteration and an afternoon of hammering a public archive.
 */
@Component
public class XbrlFetcher {

    private static final Logger log = LoggerFactory.getLogger(XbrlFetcher.class);

    private final HttpClient http;
    private final Path cacheDir;
    private final String userAgent;
    private final Duration timeout;

    public XbrlFetcher(@Value("${app.ingest.cache-dir:./data/xbrl-cache}") String cacheDir,
                       @Value("${app.ingest.user-agent:stock-screener/0.1}") String userAgent,
                       @Value("${app.ingest.request-timeout-ms:20000}") long timeoutMs) {
        this.cacheDir = Paths.get(cacheDir);
        this.userAgent = userAgent;
        this.timeout = Duration.ofMillis(timeoutMs);
        this.http = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(10))
                .build();
    }

    /** Returns the instance bytes, from cache when present. */
    public byte[] fetch(String url) throws IOException, InterruptedException {
        Path cached = cachePath(url);
        if (Files.exists(cached)) {
            return Files.readAllBytes(cached);
        }

        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(timeout)
                .header("User-Agent", userAgent)
                .header("Accept", "application/xml, text/xml, */*")
                .GET()
                .build();

        HttpResponse<byte[]> resp = http.send(req, HttpResponse.BodyHandlers.ofByteArray());
        if (resp.statusCode() != 200) {
            throw new IOException("HTTP " + resp.statusCode() + " for " + url);
        }
        byte[] body = resp.body();
        Files.createDirectories(cached.getParent());
        Files.write(cached, body);
        log.debug("Fetched {} ({} bytes)", url, body.length);
        return body;
    }

    public InputStream open(String url) throws IOException, InterruptedException {
        return new java.io.ByteArrayInputStream(fetch(url));
    }

    /** Content-addressed by URL hash, sharded so no directory holds 23k entries. */
    private Path cachePath(String url) {
        String h = sha256(url);
        return cacheDir.resolve(h.substring(0, 2)).resolve(h + ".xml");
    }

    static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(d.length * 2);
            for (byte b : d) {
                sb.append(Character.forDigit((b >> 4) & 0xF, 16));
                sb.append(Character.forDigit(b & 0xF, 16));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 unavailable", e);
        }
    }
}
