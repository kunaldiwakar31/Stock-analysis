package com.stockscreener.metrics;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Ratio engine tests, anchored on a real filing.
 *
 * <p>The base case uses Thyrocare Technologies' H1 FY26 standalone figures exactly as
 * filed (rupees lakh). Two independent facts make it a strong fixture:
 * <ul>
 *   <li>Total assets equal equity plus liabilities to the rupee (65,144 = 51,644 + 13,500),
 *       so a mapping error would show up immediately.</li>
 *   <li>EPS derived from net profit and a share count of paid-up capital over face value
 *       reproduces the filed EPS of 14.92 exactly. That validates the lakh scaling and the
 *       share-count derivation end to end — the two places a silent hundredfold error
 *       would otherwise hide.</li>
 * </ul>
 */
class RatioCalculatorTest {

    private static final BigDecimal EXPECTED_SHARES = new BigDecimal("52990000");

    private final RatioCalculator calc = new RatioCalculator();

    /** Thyrocare H1 FY26 standalone, rupees lakh, exactly as filed. */
    private RatioInputs thyrocare() {
        RatioInputs in = new RatioInputs();
        in.windowMonths = 6;              // half year: SEBI requires the balance sheet only then
        in.quartersUsed = 2;

        in.revenue = bd("38112");
        in.otherIncome = bd("624");
        in.depreciation = bd("1865");
        in.financeCosts = bd("122");
        in.profitBeforeTax = bd("11180");
        in.taxExpense = bd("3272");
        in.netProfit = bd("7908");
        in.reportedEpsSum = bd("14.92");

        in.totalEquity = bd("51644");
        in.totalAssets = bd("65144");
        in.totalBorrowings = bd("0");
        in.cashAndInvestments = bd("15199");   // 2905 cash + 3926 bank + 8368 investments
        in.balanceSheetWindowMonths = 6;

        // These are the full FY25 annual figures (MetricsService.attachCashFlow only ever
        // reads a PeriodType.FY row), paired here with the six-month FY26 P&L window above —
        // the exact combination that inflated cfoTtmCr/fcfTtmCr/dividendYieldPct by 2x
        // before cashFlowWindowMonths was tracked separately from windowMonths.
        in.cashFromOperations = bd("11879");
        in.capex = bd("1026");
        in.dividendsPaid = bd("11124");
        in.cashFlowWindowMonths = 12;

        in.sharesOutstanding = EXPECTED_SHARES;
        in.currentPrice = bd("900");
        in.high52w = bd("1200");
        in.low52w = bd("700");
        return in;
    }

    @Nested
    @DisplayName("Thyrocare H1 FY26, verified by hand")
    class RealFiling {

        @Test
        void derivesEbitdaExcludingOtherIncome() {
            // PBT 11180 + finance 122 + depreciation 1865 - other income 624
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("32.9109"), round(o.operatingMarginPct, 4));
        }

        @Test
        void computesMarginsOnTheSameWindow() {
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("20.7494"), round(o.netProfitMarginPct, 4));
        }

        @Test
        void annualisesTheHalfYearProfitBeforeDividingByEquity() {
            // Without annualisation this would read 15.31% - half the true figure.
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("30.6250"), round(o.roePct, 4));
        }

        @Test
        void computesRoceWithoutNettingCash() {
            // Netting cash would give 62.02%. The unnetted form matches Indian screeners.
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("43.7689"), round(o.rocePct, 4));
        }

        @Test
        void computesRoaAndLeverage() {
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("24.2785"), round(o.roaPct, 4));
            assertEquals(0, o.debtToEquity.compareTo(BigDecimal.ZERO));
            assertEquals(bd("92.6393"), round(o.interestCoverage, 4));
        }

        @Test
        void derivedEpsReproducesTheFiledFigure() {
            RatioInputs in = thyrocare();
            in.windowMonths = 6;
            RatioOutputs o = calc.compute(in);
            // Annualised EPS is 29.85; halving it returns the filed half-year EPS of 14.92.
            BigDecimal halfYear = o.epsTtm.divide(bd("2"), 2, RoundingMode.HALF_UP);
            assertEquals(bd("14.92"), halfYear);
        }

        @Test
        void computesBookValueAndValuationFromDerivedShareCount() {
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("97.4599"), round(o.bookValue, 4));
            assertEquals(bd("4769.10"), round(o.marketCapCr, 2));
            assertEquals(bd("30.1536"), round(o.peRatio, 4));
            assertEquals(bd("9.2346"), round(o.pbRatio, 4));
        }

        @Test
        void nettsCashForEnterpriseValueOnly() {
            RatioOutputs o = calc.compute(thyrocare());
            // Net cash of 151.99 cr reduces EV below market cap.
            assertEquals(bd("18.4051"), round(o.evToEbitda, 4));
        }

        @Test
        void computesCashQualityAndYields() {
            RatioOutputs o = calc.compute(thyrocare());
            // cashFromOperations (11879) is a true 12-month figure; netProfit (7908) covers
            // only 6 months. Annualising netProfit to 15816 before dividing is what makes
            // this 0.7511 rather than the 1.5021 you'd get from dividing mismatched windows.
            assertEquals(bd("0.7511"), round(o.ocfToNetProfit, 4));
            // fcf = 11879 - 1026 = 10853, already a 12-month figure — no annualisation
            // needed. The pre-fix code annualised it by 12/6 anyway, reporting 217.06.
            assertEquals(bd("108.53"), round(o.fcfTtmCr, 2));
            // Same story: dividendsPaid is annual; halving windowMonths from the fix removes
            // the 2x that put this at 4.6650 before.
            assertEquals(bd("2.3325"), round(o.dividendYieldPct, 4));
            assertEquals(bd("3.3163"), round(o.earningsYieldPct, 4));
        }

        @Test
        void convertsLakhToCroreForDisplay() {
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("762.24"), round(o.salesTtmCr, 2));
            assertEquals(bd("250.86"), round(o.ebitdaTtmCr, 2));
            assertEquals(bd("158.16"), round(o.netProfitTtmCr, 2));
        }

        @Test
        void recordsThatFiguresWereAnnualised() {
            RatioOutputs o = calc.compute(thyrocare());
            assertTrue(o.warnings.contains("annualised_from_6m"),
                    "a 2x factor must be visible in the audit trail");
            assertTrue(o.warnings.contains("ttm_incomplete_2q"));
        }

        @Test
        void reportsPercentFromFiftyTwoWeekHigh() {
            RatioOutputs o = calc.compute(thyrocare());
            assertEquals(bd("-25.0000"), round(o.pctFromHigh, 4));
        }
    }

    @Nested
    @DisplayName("Missing data never becomes zero")
    class NullSafety {

        @Test
        void noBalanceSheetMeansNoReturnRatios() {
            RatioInputs in = thyrocare();
            in.totalEquity = null;
            in.totalAssets = null;
            in.totalBorrowings = null;

            RatioOutputs o = calc.compute(in);
            assertNull(o.roePct, "a missing balance sheet is not zero equity");
            assertNull(o.roaPct);
            assertNull(o.rocePct);
            assertNull(o.debtToEquity);
            assertNull(o.bookValue);
            assertNull(o.pbRatio);
            assertTrue(o.warnings.contains("no_balance_sheet"));
            // Margins survive, because they need only the profit and loss account.
            assertNotNull(o.operatingMarginPct);
        }

        @Test
        void noPriceFeedMeansNoValuationRatios() {
            RatioInputs in = thyrocare();
            in.currentPrice = null;

            RatioOutputs o = calc.compute(in);
            assertNull(o.marketCapCr);
            assertNull(o.peRatio);
            assertNull(o.pbRatio);
            assertNull(o.evToEbitda);
            assertTrue(o.warnings.contains("no_price_feed"));
            // Fundamentals are unaffected by the absent feed.
            assertNotNull(o.roePct);
            assertNotNull(o.ocfToNetProfit);
        }

        @Test
        void noShareCountMeansNoPerShareFigures() {
            RatioInputs in = thyrocare();
            in.sharesOutstanding = null;

            RatioOutputs o = calc.compute(in);
            assertNull(o.bookValue);
            assertNull(o.epsTtm);
            assertNull(o.marketCapCr);
            assertTrue(o.warnings.contains("no_share_count"));
        }

        @Test
        void completenessFallsWhenDataIsAbsent() {
            RatioOutputs full = calc.compute(thyrocare());

            RatioInputs sparse = thyrocare();
            sparse.currentPrice = null;
            sparse.totalEquity = null;
            sparse.cashFromOperations = null;
            RatioOutputs thin = calc.compute(sparse);

            assertTrue(thin.dataCompletenessPct.compareTo(full.dataCompletenessPct) < 0,
                    "completeness must distinguish a thin row from a full one");
        }
    }

    @Nested
    @DisplayName("Nothing is clamped, everything is flagged")
    class EdgeCases {

        @Test
        void nearZeroEquityProducesAnExtremeRoeWithAWarning() {
            RatioInputs in = thyrocare();
            in.totalEquity = bd("100");     // 1 crore equity against 79 crore of profit
            in.prevTotalEquity = null;

            RatioOutputs o = calc.compute(in);
            assertTrue(o.roePct.compareTo(bd("200")) > 0);
            assertTrue(o.warnings.contains("near_zero_equity_roe_unreliable"),
                    "an absurd ROE must be flagged rather than quietly capped");
        }

        @Test
        void negativeEquityYieldsNoRoe() {
            RatioInputs in = thyrocare();
            in.totalEquity = bd("-5000");
            in.prevTotalEquity = null;

            RatioOutputs o = calc.compute(in);
            assertNull(o.roePct);
            assertTrue(o.warnings.contains("non_positive_equity"));
        }

        @Test
        void lossMakingCompanyHasNoPriceEarningsRatio() {
            RatioInputs in = thyrocare();
            in.netProfit = bd("-4000");

            RatioOutputs o = calc.compute(in);
            assertNull(o.peRatio, "a negative P/E is meaningless, not a bargain");
            assertNull(o.earningsYieldPct);
            assertTrue(o.warnings.contains("non_positive_eps_pe_undefined"));
        }

        @Test
        void zeroFinanceCostLeavesInterestCoverageUndefined() {
            RatioInputs in = thyrocare();
            in.financeCosts = bd("0");

            RatioOutputs o = calc.compute(in);
            assertNull(o.interestCoverage);
            assertTrue(o.warnings.contains("no_finance_cost_interest_coverage_undefined"));
        }

        @Test
        void financialCompaniesSkipInapplicableRatios() {
            RatioInputs in = thyrocare();
            in.financialCompany = true;

            RatioOutputs o = calc.compute(in);
            assertNull(o.rocePct, "ROCE is meaningless for a bank");
            assertNull(o.debtToEquity, "sixfold leverage is ordinary banking, not distress");
            assertNull(o.evToEbitda);
            // ROE and margins remain meaningful.
            assertNotNull(o.roePct);
            assertNotNull(o.netProfitMarginPct);
        }

        @Test
        void averagesEquityWhenAPriorPeriodExists() {
            RatioInputs in = thyrocare();
            in.prevTotalEquity = bd("41644");   // average becomes 46644

            RatioOutputs o = calc.compute(in);
            assertEquals(bd("33.9079"), round(o.roePct, 4));
            assertTrue(!o.warnings.contains("equity_not_averaged"));
        }
    }

    @Nested
    @DisplayName("Growth")
    class Growth {

        @Test
        void computesCagrOnlyWhenBothEndpointsExist() {
            RatioInputs in = thyrocare();
            in.annualRevenue.put(2023, bd("50000"));
            in.annualRevenue.put(2024, bd("60000"));
            in.annualRevenue.put(2025, bd("70000"));
            in.annualRevenue.put(2026, bd("80000"));

            RatioOutputs o = calc.compute(in);
            assertEquals(bd("14.2857"), round(o.salesGrowth1yPct, 4));
            assertEquals(bd("16.9607"), round(o.salesGrowth3yPct, 4));
            assertNull(o.salesGrowth5yPct, "FY2021 is absent, so 5-year growth is unknowable");
        }

        @Test
        void refusesCagrAcrossASignFlip() {
            RatioInputs in = thyrocare();
            in.annualNetProfit.put(2023, bd("-500"));   // loss
            in.annualNetProfit.put(2026, bd("2000"));   // profit

            RatioOutputs o = calc.compute(in);
            assertNull(o.profitGrowth3yPct,
                    "an n-th root across a sign flip is not a growth rate");
        }

        @Test
        void warnsWhenAnnualHistoryIsTooShort() {
            RatioInputs in = thyrocare();
            in.annualRevenue.put(2025, bd("70000"));
            in.annualRevenue.put(2026, bd("80000"));

            RatioOutputs o = calc.compute(in);
            assertNotNull(o.salesGrowth1yPct);
            assertNull(o.salesGrowth3yPct);
            assertTrue(o.warnings.contains("insufficient_annual_history_for_3y_cagr"));
        }

        @Test
        void computesQuarterOnQuarterYearAgoChange() {
            RatioInputs in = thyrocare();
            in.latestQuarterRevenue = bd("20223");
            in.yearAgoQuarterRevenue = bd("17500");
            in.latestQuarterNetProfit = bd("4303");
            in.yearAgoQuarterNetProfit = bd("3600");

            RatioOutputs o = calc.compute(in);
            assertEquals(bd("15.5600"), round(o.qtrSalesYoyPct, 4));
            assertEquals(bd("19.5278"), round(o.qtrProfitYoyPct, 4));
        }
    }

    @Nested
    @DisplayName("Cash flow window must not follow the P&L quarter-run window")
    class CashFlowWindowMismatch {

        /**
         * Only 3 consecutive quarters on file (windowMonths = 9), but cash flow is always
         * sourced from a full annual row (cashFlowWindowMonths = 12). Before
         * cashFlowWindowMonths existed, {@code absolutes()} annualised cash flow with the
         * P&amp;L's 9-month window, inflating it by 12/9 = 1.333x.
         */
        private RatioInputs partialQuarterRun() {
            RatioInputs in = new RatioInputs();
            in.windowMonths = 9;
            in.quartersUsed = 3;
            in.netProfit = bd("900");
            in.cashFromOperations = bd("1200");
            in.capex = bd("200");
            in.cashFlowWindowMonths = 12;
            return in;
        }

        @Test
        void doesNotInflateCfoWhenTheQuarterRunIsShort() {
            RatioOutputs o = calc.compute(partialQuarterRun());
            // Pre-fix this would have been 16.00 (1200 * 12/9 / 100).
            assertEquals(bd("12.00"), round(o.cfoTtmCr, 2));
            // Pre-fix this would have been 13.33 ((1200-200) * 12/9 / 100).
            assertEquals(bd("10.00"), round(o.fcfTtmCr, 2));
        }

        @Test
        void comparesCfoAgainstNetProfitOnTheSameAnnualisedFooting() {
            RatioOutputs o = calc.compute(partialQuarterRun());
            // netProfit (900, 9mo) annualised to 1200 matches cashFromOperations (1200,
            // already annual) exactly. Dividing the raw 9-month netProfit into the annual
            // CFO — the pre-fix behaviour — would have read 1.33, not 1.00.
            assertEquals(bd("1.0000"), round(o.ocfToNetProfit, 4));
        }

        @Test
        void fallsBackToThePnlWindowWhenCashFlowWindowIsUnknown() {
            // A caller that never populates cashFlowWindowMonths (e.g. an older test
            // fixture, or a source that genuinely doesn't know the cash-flow row's own
            // months) keeps the pre-fix behaviour rather than throwing or guessing.
            RatioInputs in = partialQuarterRun();
            in.cashFlowWindowMonths = null;

            RatioOutputs o = calc.compute(in);
            assertEquals(bd("16.00"), round(o.cfoTtmCr, 2));
        }
    }

    // ------------------------------------------------------------------

    private static BigDecimal bd(String s) {
        return new BigDecimal(s);
    }

    private static BigDecimal round(BigDecimal v, int places) {
        assertNotNull(v, "expected a value but got null");
        return v.setScale(places, RoundingMode.HALF_UP);
    }
}
