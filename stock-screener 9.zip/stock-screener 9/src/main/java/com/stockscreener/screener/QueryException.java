package com.stockscreener.screener;

import java.util.ArrayList;
import java.util.List;

/**
 * A query the user can fix. Carries the character position and, for unknown metrics,
 * the nearest valid names.
 *
 * <p>Every failure path in the parser raises this rather than returning an empty result
 * set. A screener that silently matches nothing when the user typed {@code roec} instead
 * of {@code roce} is worse than one that says so.
 */
public class QueryException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final String code;
    private final int position;
    private final String token;
    private final List<String> suggestions = new ArrayList<>();

    public QueryException(String code, int position, String token, String message) {
        super(message);
        this.code = code;
        this.position = position;
        this.token = token;
    }

    public QueryException(String code, int position, String token, String message,
                          List<String> suggestions) {
        this(code, position, token, message);
        if (suggestions != null) {
            this.suggestions.addAll(suggestions);
        }
    }

    public String getCode() {
        return code;
    }

    public int getPosition() {
        return position;
    }

    public String getToken() {
        return token;
    }

    public List<String> getSuggestions() {
        return suggestions;
    }
}
