package com.stockscreener.domain.repo;

import com.stockscreener.domain.CorporateAction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CorporateActionRepository extends JpaRepository<CorporateAction, Long> {

    @Query("select a from CorporateAction a where a.companyId = :companyId "
            + "order by a.effectivePeriodEnd desc")
    List<CorporateAction> findByCompanyId(@Param("companyId") Long companyId);
}
