-- Same class of problem as V3, one field at a time: book_value, pe_ratio, pb_ratio,
-- ev_to_ebitda, roe_pct, roce_pct, roa_pct, eps_ttm and ocf_to_net_profit are all ratios
-- where the numerator and denominator can come from DIFFERENT parts of a filing (P&L vs.
-- balance sheet vs. cash flow) that are not guaranteed to share a scale error, unlike e.g.
-- operating_margin_pct where both sides are P&L lines and a document-wide scale mistake
-- cancels out. Widening these now, together, instead of one at a time as each company
-- happens to be the one that crashes MetricsService.recomputeAll() next.
--
-- This does not fix any wrong VALUE already in company_metrics or financials — it only
-- stops the crash so a wrong row can be saved and its warnings inspected. The actual fix
-- for wrong data is re-parsing the affected filings with FilingExtractor's rounding-level
-- cross-check (see the note given alongside this migration).

ALTER TABLE company_metrics
  MODIFY COLUMN book_value        DECIMAL(24,4) NULL,
  MODIFY COLUMN pe_ratio          DECIMAL(24,4) NULL,
  MODIFY COLUMN pb_ratio          DECIMAL(24,4) NULL,
  MODIFY COLUMN ev_to_ebitda      DECIMAL(24,4) NULL,
  MODIFY COLUMN roe_pct           DECIMAL(24,4) NULL,
  MODIFY COLUMN roce_pct          DECIMAL(24,4) NULL,
  MODIFY COLUMN roa_pct           DECIMAL(24,4) NULL,
  MODIFY COLUMN eps_ttm           DECIMAL(24,4) NULL,
  MODIFY COLUMN ocf_to_net_profit DECIMAL(24,4) NULL;
