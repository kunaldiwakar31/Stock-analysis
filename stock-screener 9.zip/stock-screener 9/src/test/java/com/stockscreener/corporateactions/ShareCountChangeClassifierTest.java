package com.stockscreener.corporateactions;

import com.stockscreener.corporateactions.ShareCountChangeClassifier.Classification;
import com.stockscreener.corporateactions.ShareCountChangeClassifier.Type;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ShareCountChangeClassifierTest {

    private static Classification classify(String facePrev, String faceNew,
                                           String sharesPrev, String sharesNew) {
        return ShareCountChangeClassifier.classify(
                facePrev == null ? null : new BigDecimal(facePrev),
                faceNew == null ? null : new BigDecimal(faceNew),
                new BigDecimal(sharesPrev), new BigDecimal(sharesNew));
    }

    @Nested
    @DisplayName("bonus issues: flat face value, share count grows by a simple ratio")
    class BonusIssues {

        @Test
        @DisplayName("1:1 bonus doubles the count and is restatable")
        void oneForOneBonus() {
            Classification c = classify("10", "10", "1000000", "2000000");
            assertEquals(Type.BONUS, c.type());
            assertTrue(c.restatementRecommended());
            assertEquals(0, new BigDecimal("2.0").compareTo(c.ratio()));
        }

        @Test
        @DisplayName("1:10 bonus (a real, if less common, ratio) is still caught")
        void oneForTenBonus() {
            Classification c = classify("5", "5", "1000000", "1100000");
            assertEquals(Type.BONUS, c.type());
            assertTrue(c.restatementRecommended());
        }

        @Test
        @DisplayName("3:5 bonus resolves to a clean fraction with a small denominator")
        void threeForFiveBonus() {
            Classification c = classify("2", "2", "5000000", "8000000");
            assertEquals(Type.BONUS, c.type());
        }
    }

    @Nested
    @DisplayName("splits: face value changes and the ratio confirms it")
    class Splits {

        @Test
        @DisplayName("2-for-1 split (face value 10 -> 5) is restatable")
        void forwardSplit() {
            Classification c = classify("10", "5", "1000000", "2000000");
            assertEquals(Type.SPLIT, c.type());
            assertTrue(c.restatementRecommended());
        }

        @Test
        @DisplayName("10-for-1 reverse split (face value 1 -> 10) is restatable")
        void reverseSplit() {
            Classification c = classify("1", "10", "10000000", "1000000");
            assertEquals(Type.SPLIT, c.type());
            assertTrue(c.restatementRecommended());
            assertEquals(0, new BigDecimal("0.1").compareTo(c.ratio()));
        }

        @Test
        @DisplayName("face value changed but the share count doesn't follow from it - don't guess")
        void faceValueChangedButRatioDoesNotMatch() {
            // Face value halved (implying 2x shares) but shares only grew 1.3x - something
            // else happened alongside the face-value change; must not be restated.
            Classification c = classify("10", "5", "1000000", "1300000");
            assertEquals(Type.MINOR_CHANGE, c.type());
            assertFalse(c.restatementRecommended());
        }
    }

    @Nested
    @DisplayName("real changes that must never be restated")
    class NonRestatable {

        @Test
        @DisplayName("a buyback shrinks the count at a flat face value - never restated, "
                + "even if the ratio happens to look clean")
        void buybackNeverRestated() {
            // 9000000/10000000 = 0.9 = 9/10 exactly - a "clean" fraction, but a buyback is
            // not a pro-rata event, so it must be left alone regardless.
            Classification c = classify("10", "10", "10000000", "9000000");
            assertEquals(Type.MINOR_CHANGE, c.type());
            assertFalse(c.restatementRecommended());
        }

        @Test
        @DisplayName("an 8% ESOP allotment at a flat face value is not a clean ratio")
        void esopAllotmentNotClean() {
            Classification c = classify("10", "10", "10000000", "10800000");
            assertEquals(Type.MINOR_CHANGE, c.type());
            assertFalse(c.restatementRecommended());
        }

        @Test
        @DisplayName("a preferential allotment landing near a round ratio is still not "
                + "clean enough with a tight denominator cap")
        void preferentialAllotmentNearRoundRatio() {
            Classification c = classify("10", "10", "10000000", "11500000");
            assertEquals(Type.MINOR_CHANGE, c.type());
        }
    }

    @Nested
    @DisplayName("implausible jumps: extraction/scale bugs, not corporate actions")
    class Implausible {

        @Test
        @DisplayName("a ~1e7x jump (the class of bug already fixed for paid-up capital) "
                + "is rejected outright")
        void extractionScaleBug() {
            Classification c = classify("10", "10", "51300000", "513000000000000");
            assertEquals(Type.IMPLAUSIBLE, c.type());
            assertFalse(c.restatementRecommended());
        }

        @Test
        @DisplayName("a share count that collapses to near zero is rejected, not treated "
                + "as a 20-for-1 reverse split")
        void collapsedShareCount() {
            Classification c = classify("10", "10", "10000000", "1000");
            assertEquals(Type.IMPLAUSIBLE, c.type());
        }
    }
}
