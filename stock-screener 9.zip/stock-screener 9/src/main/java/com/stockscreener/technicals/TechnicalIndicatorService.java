package com.stockscreener.technicals;

import com.stockscreener.domain.DailyPrice;
import com.stockscreener.domain.TechnicalIndicator;
import com.stockscreener.domain.repo.DailyPriceRepository;
import com.stockscreener.domain.repo.TechnicalIndicatorRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

/**
 * Turns stored {@link DailyPrice} history into {@link TechnicalIndicator} rows.
 *
 * <p>Structurally the same shape as {@code MetricsService}: this class owns the
 * DB-facing plumbing (loading history, persisting results, the self-proxy
 * {@code @Transactional} workaround), while {@link TechnicalIndicatorCalculator} stays a
 * pure function that never touches the database. See that class for the actual formulas.
 *
 * <p><b>Recompute is a full rebuild, not an incremental update.</b> Every call to
 * {@link #recompute} deletes and regenerates a company's entire indicator series from
 * whatever price history is currently stored. That is deliberate: with retention bounding
 * history to roughly a year, regenerating the whole series costs about as much as updating
 * one day and stays correct automatically if a price gets corrected retroactively — an
 * incremental "just add today" path would silently keep serving indicator values computed
 * against the old, wrong price.
 */
@Service
public class TechnicalIndicatorService {

    private static final Logger log = LoggerFactory.getLogger(TechnicalIndicatorService.class);

    private final DailyPriceRepository prices;
    private final TechnicalIndicatorRepository indicators;
    private final TechnicalIndicatorCalculator calculator = new TechnicalIndicatorCalculator();

    /**
     * Self-reference through the Spring proxy — see {@code MetricsService} for why this
     * exists: {@code this.recompute(...)} from an untransacted loop would bypass the proxy
     * and silently lose {@code @Transactional} entirely.
     */
    private final ObjectProvider<TechnicalIndicatorService> self;

    public TechnicalIndicatorService(DailyPriceRepository prices,
                                     TechnicalIndicatorRepository indicators,
                                     ObjectProvider<TechnicalIndicatorService> self) {
        this.prices = prices;
        this.indicators = indicators;
        this.self = self;
    }

    /** Recomputes every company that has at least one stored price. */
    public int recomputeAll() {
        List<Long> ids = prices.findCompanyIdsWithData();
        TechnicalIndicatorService proxy = self.getObject();
        int done = 0;
        for (Long id : ids) {
            try {
                // One transaction per company: a single bad row must not roll back the rest.
                proxy.recompute(id);
                done++;
            } catch (Exception e) {
                log.warn("Technical indicators for company {} failed: {}", id, e.toString());
            }
        }
        return done;
    }

    @Transactional
    public int recompute(Long companyId) {
        List<DailyPrice> history = prices.findByCompanyIdOrderByTradeDateAsc(companyId);
        if (history.isEmpty()) {
            return 0;
        }

        List<PricePoint> points = new ArrayList<>(history.size());
        for (DailyPrice p : history) {
            points.add(new PricePoint(p.getTradeDate(), p.getClosePrice(), p.getHighPrice(),
                    p.getLowPrice(), p.getVolume(), p.getDeliveryPct()));
        }

        List<TechnicalIndicatorResult> results = calculator.computeSeries(points);

        indicators.deleteAllForCompany(companyId);
        for (TechnicalIndicatorResult r : results) {
            TechnicalIndicator row = new TechnicalIndicator();
            row.setCompanyId(companyId);
            row.setTradeDate(r.date);
            row.setClosePrice(r.close);
            row.setEma20(r.ema20);
            row.setEma50(r.ema50);
            row.setEma200(r.ema200);
            row.setSma20(r.sma20);
            row.setSma50(r.sma50);
            row.setSma200(r.sma200);
            row.setRsi14(r.rsi14);
            row.setMacd(r.macd);
            row.setMacdSignal(r.macdSignal);
            row.setMacdHistogram(r.macdHistogram);
            row.setAtr14(r.atr14);
            row.setBollingerUpper(r.bollingerUpper);
            row.setBollingerMiddle(r.bollingerMiddle);
            row.setBollingerLower(r.bollingerLower);
            row.setVolume(r.volume);
            row.setVolumeSma20(r.volumeSma20);
            row.setDeliveryPct(r.deliveryPct);
            row.setWarnings(toJsonArray(r.warnings));
            indicators.save(row);
        }
        return results.size();
    }

    private static String toJsonArray(List<String> items) {
        if (items == null || items.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(items.get(i).replace("\"", "'")).append('"');
        }
        return sb.append(']').toString();
    }
}
