package com.stockscreener.corporateactions;

import com.stockscreener.common.JsonWarnings;
import com.stockscreener.common.Nums;
import com.stockscreener.corporateactions.ShareCountChangeClassifier.Classification;
import com.stockscreener.corporateactions.ShareCountChangeClassifier.Type;
import com.stockscreener.domain.Company;
import com.stockscreener.domain.CorporateAction;
import com.stockscreener.domain.Financial;
import com.stockscreener.domain.repo.CorporateActionRepository;
import com.stockscreener.domain.repo.FinancialRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

/**
 * Decides what to do about a share-count jump big enough to break historical EPS
 * comparability, and records the decision either way.
 *
 * <p>Every jump gets a {@link CorporateAction} audit row. Only a {@link Type#SPLIT} or
 * {@link Type#BONUS} confirmed by {@link ShareCountChangeClassifier} — and only when the
 * new period is genuinely later than anything already on file for the company — gets its
 * prior {@code financials.eps} rows divided by the ratio. Everything else (buybacks, ESOP
 * allotments, a reparse of a period already stored, or a jump too large to be a real
 * corporate action) is recorded but left alone: restating on a guess would be worse than
 * leaving stale data flagged as stale.
 */
@Service
public class CorporateActionService {

    private static final Logger log = LoggerFactory.getLogger(CorporateActionService.class);

    private final CorporateActionRepository actions;
    private final FinancialRepository financials;

    public CorporateActionService(CorporateActionRepository actions,
                                  FinancialRepository financials) {
        this.actions = actions;
        this.financials = financials;
    }

    /** What the caller should do with the newly-derived share count. */
    public record Outcome(CorporateAction action, boolean acceptNewShareCount) {
    }

    /**
     * @param forwardInTime whether {@code filingPeriodEnd} is later than every period
     *     already stored for this company. When it is not, the jump is a correction to
     *     already-stored data (a reparse, or a backfill landing out of order), not a new
     *     event in the company's history, and must never trigger restatement.
     */
    @Transactional
    public Outcome recordAndMaybeAdjust(Company company, BigDecimal facePrev,
                                        BigDecimal faceNew, BigDecimal sharesPrev,
                                        BigDecimal sharesNew, LocalDate filingPeriodEnd,
                                        String sourceUrl, boolean forwardInTime) {
        Classification cls = ShareCountChangeClassifier.classify(
                facePrev, faceNew, sharesPrev, sharesNew);

        CorporateAction action = new CorporateAction();
        action.setCompanyId(company.getId());
        action.setSymbol(company.getSymbol());
        action.setEffectivePeriodEnd(filingPeriodEnd);
        action.setSourceUrl(sourceUrl);
        action.setSharesBefore(sharesPrev);
        action.setSharesAfter(sharesNew);
        action.setRatio(cls.ratio());
        action.setActionType(cls.type().name());
        action.setAppliedRestatement(false);

        boolean acceptNewShareCount = true;

        if (cls.type() == Type.IMPLAUSIBLE) {
            // No real corporate action moves a share count this far in one filing; keep
            // the prior value rather than let an extraction/scale bug corrupt it.
            acceptNewShareCount = false;
            action.setNote("implausible_share_count_change_kept_prior_value");
        } else if (!forwardInTime) {
            action.setNote("reparse_or_backfill_correction_no_restatement");
        } else if (cls.restatementRecommended()) {
            int rowsAdjusted = restatePriorEps(company.getId(), filingPeriodEnd, cls.ratio());
            action.setAppliedRestatement(true);
            action.setRowsRestated(rowsAdjusted);
            action.setNote("restated_prior_eps_for_" + cls.type().name().toLowerCase(Locale.ROOT));
        } else {
            action.setNote("real_but_non_pro_rata_change_no_restatement");
        }

        actions.save(action);
        return new Outcome(action, acceptNewShareCount);
    }

    /**
     * Divides every {@code eps} filed before {@code filingPeriodEnd} by {@code ratio}, so
     * a pre-split/pre-bonus EPS reads on the same share-count basis as everything filed
     * after it.
     *
     * <p>Rows are fetched and mutated within the caller's transaction and flushed on
     * commit — same pattern as {@code FilingParseService.deriveQuarterFromYtd} — so there
     * is no explicit {@code save()} call per row.
     */
    private int restatePriorEps(Long companyId, LocalDate filingPeriodEnd, BigDecimal ratio) {
        List<Financial> prior =
                financials.findByCompanyIdAndPeriodEndLessThan(companyId, filingPeriodEnd);
        int adjusted = 0;
        for (Financial f : prior) {
            if (f.getEps() == null) {
                continue;
            }
            f.setEps(Nums.div(f.getEps(), ratio));
            f.setWarnings(JsonWarnings.append(f.getWarnings(), "eps_restated_for_corporate_action"));
            adjusted++;
        }
        log.info("Restated eps on {} prior row(s) for company {} (ratio {})",
                adjusted, companyId, ratio);
        return adjusted;
    }
}
