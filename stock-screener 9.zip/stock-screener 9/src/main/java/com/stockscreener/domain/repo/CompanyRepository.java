package com.stockscreener.domain.repo;

import com.stockscreener.domain.Company;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CompanyRepository extends JpaRepository<Company, Long> {

    Optional<Company> findBySymbol(String symbol);

    List<Company> findByStatus(String status);
}
