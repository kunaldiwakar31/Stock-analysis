package com.stockscreener.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Audit trail for every share-count jump big enough to break comparability of historical
 * EPS ({@code >5%} between two filings for the same company).
 *
 * <p>Every such jump gets a row here regardless of what was decided about it - including
 * the ones rejected as implausible or left alone as a buyback/ESOP allotment - so a
 * screener maintainer can see the full history of what {@link
 * com.stockscreener.corporateactions.CorporateActionService} concluded and why, not just
 * the cases it acted on.
 */
@Entity
@Table(name = "corporate_actions")
@Getter
@Setter
public class CorporateAction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "company_id", nullable = false)
    private Long companyId;

    @Column(length = 30)
    private String symbol;

    @Column(name = "effective_period_end", nullable = false)
    private LocalDate effectivePeriodEnd;

    @Column(name = "source_url", length = 700)
    private String sourceUrl;

    @Column(name = "shares_before", precision = 24, scale = 4)
    private BigDecimal sharesBefore;

    @Column(name = "shares_after", precision = 24, scale = 4)
    private BigDecimal sharesAfter;

    @Column(precision = 14, scale = 6)
    private BigDecimal ratio;

    /** {@link com.stockscreener.corporateactions.ShareCountChangeClassifier.Type} as text. */
    @Column(name = "action_type", nullable = false, length = 20)
    private String actionType;

    @Column(name = "applied_restatement", nullable = false)
    private boolean appliedRestatement;

    @Column(name = "rows_restated")
    private Integer rowsRestated;

    /** Free-text reasoning, e.g. "restated_prior_eps_for_bonus" or
     *  "implausible_share_count_change_kept_prior_value". */
    @Column(length = 60)
    private String note;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;
}
