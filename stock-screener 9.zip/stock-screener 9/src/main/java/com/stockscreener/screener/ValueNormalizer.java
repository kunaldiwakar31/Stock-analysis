package com.stockscreener.screener;

import com.stockscreener.common.Nums;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

/**
 * Converts a typed literal into the unit its column actually stores.
 *
 * <p>This is where most wrong screener results come from, so the rule everywhere is:
 * <b>an ambiguous or implausible value is rejected with an explanation, never silently
 * accepted.</b> A query that returns zero rows because {@code roe > 0.18} was read as
 * "0.18 percent" is far worse than one that refuses to run and says "did you mean 18%?".
 */
public final class ValueNormalizer {

    private static final List<String> LAKH_SUFFIXES = Arrays.asList("l", "lakh", "lakhs");
    private static final List<String> CRORE_SUFFIXES = Arrays.asList("cr", "crore", "crores");
    private static final List<String> DAY_SUFFIXES = Arrays.asList("d", "days");

    /** Above this, a bare number on a crore metric was almost certainly meant as rupees. */
    private static final BigDecimal CRORE_IMPLAUSIBLE = BigDecimal.valueOf(1_000_000);

    private ValueNormalizer() {
    }

    public static NormalizedValue normalize(MetricDef metric, Token num) {
        BigDecimal raw;
        try {
            raw = new BigDecimal(num.text);
        } catch (NumberFormatException e) {
            throw new QueryException("BAD_NUMBER", num.position, num.text,
                    "Not a number: '" + num.text + "'");
        }
        String sfx = num.unitSuffix;

        switch (metric.unit()) {
            case PERCENT:
                return percent(metric, num, raw, sfx);
            case CRORE:
                return crore(metric, num, raw, sfx);
            case RATIO:
                return ratio(metric, num, raw, sfx);
            case DAYS:
                return days(metric, num, raw, sfx);
            case RUPEE:
                return rupee(metric, num, raw, sfx);
            case INT:
                return plain(metric, num, raw, sfx);
            default:
                throw new QueryException("TYPE_MISMATCH", num.position, num.text,
                        "Metric '" + metric.key() + "' is not numeric");
        }
    }

    private static NormalizedValue percent(MetricDef m, Token t, BigDecimal v, String sfx) {
        if ("%".equals(sfx)) {
            // Explicit: 0.5% really means 0.5%, which is a valid dividend yield.
            return new NormalizedValue(v, "PERCENT", m.unit());
        }
        if (!sfx.isEmpty()) {
            throw wrongUnit(m, t, sfx, "%");
        }
        BigDecimal abs = v.abs();
        if (abs.signum() != 0 && abs.compareTo(BigDecimal.ONE) < 0) {
            BigDecimal asPct = v.multiply(Nums.HUNDRED);
            throw new QueryException("AMBIGUOUS_PERCENT", t.position, t.text,
                    "'" + m.key() + " " + t.text + "' looks like a fraction. "
                            + "Percentages are stored as plain numbers - did you mean "
                            + asPct.stripTrailingZeros().toPlainString() + "% ? "
                            + "Write '" + t.text + "%' if you really meant "
                            + t.text + " percent.");
        }
        return new NormalizedValue(v, "NONE", m.unit());
    }

    private static NormalizedValue crore(MetricDef m, Token t, BigDecimal v, String sfx) {
        if (CRORE_SUFFIXES.contains(sfx)) {
            return new NormalizedValue(v, "CRORE", m.unit());
        }
        if (LAKH_SUFFIXES.contains(sfx)) {
            return new NormalizedValue(v.divide(Nums.HUNDRED, Nums.MC), "LAKH", m.unit());
        }
        if ("%".equals(sfx)) {
            throw wrongUnit(m, t, sfx, "cr / lakh");
        }
        if (!sfx.isEmpty()) {
            throw wrongUnit(m, t, sfx, "cr / lakh");
        }
        if (v.abs().compareTo(CRORE_IMPLAUSIBLE) > 0) {
            throw new QueryException("AMBIGUOUS_SCALE", t.position, t.text,
                    "'" + m.key() + " " + t.text + "' is implausibly large for a crore value. "
                            + "Amounts are stored in crore - write e.g. '1000cr'.");
        }
        return new NormalizedValue(v, "NONE", m.unit());
    }

    private static NormalizedValue ratio(MetricDef m, Token t, BigDecimal v, String sfx) {
        if (sfx.isEmpty() || "x".equals(sfx)) {
            return new NormalizedValue(v, sfx.isEmpty() ? "NONE" : "MULTIPLE", m.unit());
        }
        throw wrongUnit(m, t, sfx, "x");
    }

    private static NormalizedValue days(MetricDef m, Token t, BigDecimal v, String sfx) {
        if (sfx.isEmpty() || DAY_SUFFIXES.contains(sfx)) {
            return new NormalizedValue(v, sfx.isEmpty() ? "NONE" : "DAYS", m.unit());
        }
        throw wrongUnit(m, t, sfx, "d / days");
    }

    private static NormalizedValue rupee(MetricDef m, Token t, BigDecimal v, String sfx) {
        if (sfx.isEmpty()) {
            return new NormalizedValue(v, "NONE", m.unit());
        }
        throw wrongUnit(m, t, sfx, "(none - rupees per share)");
    }

    private static NormalizedValue plain(MetricDef m, Token t, BigDecimal v, String sfx) {
        if (sfx.isEmpty()) {
            return new NormalizedValue(v, "NONE", m.unit());
        }
        throw wrongUnit(m, t, sfx, "(none)");
    }

    private static QueryException wrongUnit(MetricDef m, Token t, String sfx, String expected) {
        return new QueryException("WRONG_UNIT", t.position, t.text + sfx,
                "Unit '" + sfx + "' is not valid for '" + m.key()
                        + "' (" + m.label() + "). Expected: " + expected);
    }
}
