-- dividend_yield_pct and earnings_yield_pct are ratios with no natural upper bound: both
-- have a price or market cap in the denominator, and a small-enough denominator (a penny
-- stock, or a genuine data problem upstream) makes the result arbitrarily large. DECIMAL(10,4)
-- (max 999999.9999) was too narrow for that and started throwing "Data truncation: Out of
-- range value" on MetricsService's batch update, which drops the company's ENTIRE metrics
-- row for that recompute cycle, not just the one field.
--
-- pct_from_high is bounded in practice (a price is very unlikely to sit 999999% below its
-- 52-week high) but is widened too for consistency with every other unbounded percentage
-- field in this table, which already use DECIMAL(12,4) or wider.

ALTER TABLE company_metrics
  MODIFY COLUMN pct_from_high      DECIMAL(20,4) NULL,
  MODIFY COLUMN dividend_yield_pct DECIMAL(20,4) NULL,
  MODIFY COLUMN earnings_yield_pct DECIMAL(20,4) NULL;
