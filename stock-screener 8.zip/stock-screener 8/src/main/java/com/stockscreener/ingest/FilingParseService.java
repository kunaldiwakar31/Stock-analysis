package com.stockscreener.ingest;

import com.stockscreener.common.FiscalCalendar;
import com.stockscreener.common.JsonWarnings;
import com.stockscreener.common.Nums;
import com.stockscreener.corporateactions.CorporateActionService;
import com.stockscreener.domain.Company;
import com.stockscreener.domain.Enums.Derivation;
import com.stockscreener.domain.Enums.IngestStatus;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import com.stockscreener.domain.FilingIngest;
import com.stockscreener.domain.repo.CompanyRepository;
import com.stockscreener.domain.repo.FilingIngestRepository;
import com.stockscreener.domain.repo.FinancialRepository;
import com.stockscreener.xbrl.FilingExtractor;
import com.stockscreener.xbrl.XbrlDocument;
import com.stockscreener.xbrl.XbrlFetcher;
import com.stockscreener.xbrl.XbrlStaxParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Downloads queued filings, parses them, and persists the line items. */
@Service
public class FilingParseService {

    private static final Logger log = LoggerFactory.getLogger(FilingParseService.class);
    private static final BigDecimal LAKH = BigDecimal.valueOf(100_000);

    /** Below this, a share-count difference is filing-to-filing rounding noise, not a
     *  corporate action worth classifying. */
    private static final BigDecimal SIGNIFICANT_SHARE_CHANGE = new BigDecimal("0.05");

    /** Real face values are ₹1/2/5/10, occasionally into the low hundreds; this is a
     *  generous upper bound, not a real-world one, so it only ever rejects a concept
     *  mismatch, never a genuine filing. */
    private static final BigDecimal MAX_PLAUSIBLE_FACE_VALUE = BigDecimal.valueOf(1000);

    private final FilingIngestRepository ingests;
    private final FinancialRepository financials;
    private final CompanyRepository companies;
    private final XbrlFetcher fetcher;
    private final FilingExtractor extractor;
    private final CorporateActionService corporateActions;
    private final XbrlStaxParser parser = new XbrlStaxParser();

    /**
     * Self-reference through the Spring proxy.
     *
     * <p>Calling {@code this.processOne(...)} directly from the loop below would bypass the
     * proxy, so {@code @Transactional} would not apply and every mutation to a managed
     * entity — including marking the filing DONE — would be silently discarded. The filings
     * would then stay PENDING and be reprocessed forever.
     */
    private final ObjectProvider<FilingParseService> self;

    public FilingParseService(FilingIngestRepository ingests, FinancialRepository financials,
                              CompanyRepository companies, XbrlFetcher fetcher,
                              FilingExtractor extractor, CorporateActionService corporateActions,
                              ObjectProvider<FilingParseService> self) {
        this.ingests = ingests;
        this.financials = financials;
        this.companies = companies;
        this.fetcher = fetcher;
        this.extractor = extractor;
        this.corporateActions = corporateActions;
        this.self = self;
    }

    /**
     * Processes up to {@code limit} pending filings.
     *
     * <p>One filing per transaction on purpose: a single malformed instance out of 23,000
     * must not roll back the rest of the batch.
     */
    public int processPending(int limit) {
        List<FilingIngest> batch = ingests.findByStatusOrderByQuarterEndDesc(
                IngestStatus.PENDING, PageRequest.of(0, limit));
        FilingParseService proxy = self.getObject();
        int ok = 0;
        for (FilingIngest fi : batch) {
            try {
                proxy.processOne(fi.getId());
                ok++;
            } catch (Exception e) {
                proxy.recordFailure(fi.getId(), e);
                log.warn("Filing {} failed: {}", fi.getXbrlUrl(), e.toString());
            }
        }
        return ok;
    }

    @Transactional
    public void processOne(Long ingestId) throws Exception {
        FilingIngest fi = ingests.findById(ingestId).orElseThrow();
        Company company = companies.findBySymbol(fi.getSymbol()).orElseThrow(
                () -> new IllegalStateException("Unknown symbol " + fi.getSymbol()));

        XbrlDocument doc;
        try (InputStream in = fetcher.open(fi.getXbrlUrl())) {
            doc = parser.parse(in);
        }

        FilingExtractor.Result res = extractor.extract(
                doc, fi.getQuarterEnd(), fi.isConsolidated(), fi.getXbrlUrl(), fi.getAudited());

        enrichCompany(company, res, fi.getQuarterEnd(), fi.getXbrlUrl());

        for (Financial f : res.rows) {
            f.setCompanyId(company.getId());
            f.setFiledAt(fi.getBroadcastAt());
            if (!res.warnings.isEmpty()) {
                f.setWarnings(JsonWarnings.arrayOf(res.warnings));
            }
            upsert(f);
        }

        deriveQuarterFromYtd(company.getId(), fi.getQuarterEnd(), fi.isConsolidated());

        fi.setStatus(IngestStatus.DONE);
        fi.setAttempts(fi.getAttempts() + 1);
        fi.setErrorMessage(res.warnings.isEmpty() ? null : String.join("; ", res.warnings));
    }

    /**
     * Parses one filing without saving anything, and reports what it found.
     *
     * <p>Exists for the common failure mode: a filing stores nulls because the facts sit on
     * a context this code did not pick. Rather than guessing, this shows every context in
     * the instance with its period, dimensions and fact count, plus which context was
     * actually chosen for each statement — enough to tell a date mismatch from a
     * dimensioned statement from a wrong concept name.
     */
    public Map<String, Object> inspect(String xbrlUrl, LocalDate quarterEnd,
                                      boolean consolidated) throws Exception {
        XbrlDocument doc;
        try (InputStream in = fetcher.open(xbrlUrl)) {
            doc = parser.parse(in);
        }

        Map<String, Object> out = new LinkedHashMap<>();
        out.put("url", xbrlUrl);
        out.put("expectedPeriodEnd", String.valueOf(quarterEnd));
        out.put("totalFacts", doc.facts.size());
        out.put("totalContexts", doc.contexts.size());

        Map<String, Integer> counts = doc.factCountByContext();
        List<Map<String, Object>> ctxs = new ArrayList<>();
        for (XbrlDocument.Context c : doc.orderedContexts()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("id", c.id);
            m.put("kind", c.isInstant() ? "instant" : "duration");
            m.put("start", String.valueOf(c.start));
            m.put("end", String.valueOf(c.isInstant() ? c.instant : c.end));
            m.put("months", c.months());
            m.put("dimensions", c.dimensionKey.isEmpty() ? null : c.dimensionKey);
            m.put("factCount", counts.getOrDefault(c.id, 0));
            ctxs.add(m);
        }
        out.put("contexts", ctxs);

        try {
            FilingExtractor.Result res =
                    extractor.extract(doc, quarterEnd, consolidated, xbrlUrl, null);
            out.put("roundingLevel", String.valueOf(res.roundingLevel));
            out.put("isin", res.isin);
            out.put("faceValue", res.faceValue);
            out.put("paidUpCapitalLakh", res.paidUpCapital);
            out.put("warnings", res.warnings);
            List<Map<String, Object>> rows = new ArrayList<>();
            for (Financial f : res.rows) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("periodType", String.valueOf(f.getPeriodType()));
                m.put("monthsCovered", f.getMonthsCovered());
                m.put("revenue", f.getRevenue());
                m.put("netProfit", f.getNetProfit());
                m.put("totalEquity", f.getTotalEquity());
                m.put("totalAssets", f.getTotalAssets());
                m.put("cashFromOperations", f.getCashFromOperations());
                rows.add(m);
            }
            out.put("extractedRows", rows);
        } catch (RuntimeException e) {
            // A missing rounding level throws here by design; surface it rather than hide it.
            out.put("extractionError", e.getClass().getSimpleName() + ": " + e.getMessage());
        }

        // Unmapped concepts ranked, so a wrong alias in xbrl-concepts.yml is obvious.
        List<String> unmapped = new ArrayList<>();
        for (XbrlDocument.Fact f : doc.facts) {
            if (!unmapped.contains(f.concept) && !conceptKnown(f.concept)) {
                unmapped.add(f.concept);
            }
        }
        out.put("unmappedConcepts", unmapped);
        return out;
    }

    private boolean conceptKnown(String concept) {
        return extractor.knowsConcept(concept);
    }

    @Transactional
    public void recordFailure(Long ingestId, Exception e) {
        ingests.findById(ingestId).ifPresent(fi -> {
            fi.setAttempts(fi.getAttempts() + 1);
            fi.setStatus(IngestStatus.FAILED);
            fi.setErrorMessage(e.getClass().getSimpleName() + ": " + e.getMessage());
        });
    }

    /**
     * Fills in company attributes the filing supplies.
     *
     * <p>The share count is derived rather than sourced: paid-up capital divided by face
     * value. That single division is what makes market cap, P/E and P/B possible from a
     * price alone, since the filings themselves carry no market data.
     *
     * <p>A jump big enough to break comparability of historical EPS (bonus, split,
     * buyback, ESOP allotment — or a reparse correcting an earlier extraction bug) is
     * handed to {@link CorporateActionService}, which classifies it, restates prior
     * {@code eps} rows when that classification says it is safe to, and can refuse the
     * new share count outright when the jump is too large to be a real corporate action.
     */
    private void enrichCompany(Company c, FilingExtractor.Result res,
                               LocalDate filingPeriodEnd, String sourceUrl) {
        if (res.isin != null && c.getIsin() == null) {
            c.setIsin(res.isin.trim());
        }
        BigDecimal facePrev = c.getFaceValue();
        if (isPlausibleFaceValue(res.faceValue)) {
            c.setFaceValue(res.faceValue);
        } else if (res.faceValue != null) {
            // Real face values top out around a few hundred rupees; anything past this
            // is the same class of concept-mismatch bug already fixed for paid-up
            // capital - most likely an aggregate capital figure tagged under the
            // per-share concept. Keeping the prior value avoids both a wrong ratio and
            // the DECIMAL(12,4) truncation this used to crash the filing with.
            log.warn("Rejecting implausible face value {} for {}; keeping {}",
                    res.faceValue, c.getSymbol(), facePrev);
        }
        if (res.paidUpCapital == null || c.getFaceValue() == null
                || c.getFaceValue().signum() <= 0) {
            return;
        }

        // paid-up capital is in lakh, so scale to rupees before dividing.
        BigDecimal shares = res.paidUpCapital.multiply(LAKH, Nums.MC)
                .divide(c.getFaceValue(), Nums.MC);
        BigDecimal sharesPrev = c.getSharesOutstanding();
        if (sharesPrev == null || sharesPrev.signum() <= 0) {
            c.setSharesOutstanding(shares);
            return;
        }

        BigDecimal change = shares.subtract(sharesPrev).abs().divide(sharesPrev, Nums.MC);
        if (change.compareTo(SIGNIFICANT_SHARE_CHANGE) <= 0) {
            c.setSharesOutstanding(shares);
            return;
        }

        LocalDate existingMax = financials.findMaxPeriodEnd(c.getId());
        boolean forwardInTime = existingMax == null || filingPeriodEnd.isAfter(existingMax);
        CorporateActionService.Outcome outcome = corporateActions.recordAndMaybeAdjust(
                c, facePrev, c.getFaceValue(), sharesPrev, shares, filingPeriodEnd, sourceUrl,
                forwardInTime);

        log.info("Share count for {} moved {}%; classified {} ({})", c.getSymbol(),
                change.multiply(Nums.HUNDRED).setScale(1, RoundingMode.HALF_UP),
                outcome.action().getActionType(), outcome.action().getNote());

        if (outcome.acceptNewShareCount()) {
            c.setSharesOutstanding(shares);
        }
    }

    private void upsert(Financial f) {
        Optional<Financial> existing =
                financials.findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
                        f.getCompanyId(), f.getPeriodEnd(), f.getPeriodType(),
                        f.isConsolidated());
        if (existing.isEmpty()) {
            financials.save(f);
            return;
        }
        Financial e = existing.get();
        // A revision supersedes what was stored, so overwrite rather than merge.
        e.setMonthsCovered(f.getMonthsCovered());
        e.setDerivation(f.getDerivation());
        e.setAudited(f.getAudited());
        e.setSourceUrl(f.getSourceUrl());
        e.setRoundingLevel(f.getRoundingLevel());
        e.setFiledAt(f.getFiledAt());
        e.setRevenue(f.getRevenue());
        e.setOtherIncome(f.getOtherIncome());
        e.setTotalExpenses(f.getTotalExpenses());
        e.setOperatingProfit(f.getOperatingProfit());
        e.setDepreciation(f.getDepreciation());
        e.setFinanceCosts(f.getFinanceCosts());
        e.setProfitBeforeTax(f.getProfitBeforeTax());
        e.setTaxExpense(f.getTaxExpense());
        e.setNetProfit(f.getNetProfit());
        e.setEps(f.getEps());
        e.setTotalEquity(f.getTotalEquity());
        e.setTotalBorrowings(f.getTotalBorrowings());
        e.setCashAndInvestments(f.getCashAndInvestments());
        e.setTotalAssets(f.getTotalAssets());
        e.setPaidUpCapital(f.getPaidUpCapital());
        e.setCashFromOperations(f.getCashFromOperations());
        e.setCapex(f.getCapex());
        e.setDividendsPaid(f.getDividendsPaid());
        e.setWarnings(f.getWarnings());
    }

    /**
     * Back-computes a three-month quarter from two cumulative figures.
     *
     * <p>Only applies when the filer omitted the three-month column. The subtraction is
     * restricted to the same fiscal year and the same basis, because crossing either
     * boundary produces a meaningless number.
     *
     * <p>Q4 deserves particular suspicion: it is commonly filed as audited full-year
     * figures only, so the derived quarter absorbs every year-end adjustment at once. The
     * row is still stored, but labelled {@link Derivation#YTD_DIFF} so nothing downstream
     * mistakes it for a clean reported quarter.
     */
    private void deriveQuarterFromYtd(Long companyId, java.time.LocalDate quarterEnd,
                                     boolean consolidated) {
        Optional<Financial> currentOpt =
                financials.findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
                        companyId, quarterEnd, PeriodType.Q, consolidated);
        if (currentOpt.isEmpty()) {
            return;
        }
        Financial current = currentOpt.get();
        if (current.getMonthsCovered() != null && current.getMonthsCovered() == 3) {
            return; // Already a real quarter.
        }

        int q = FiscalCalendar.fiscalQuarter(quarterEnd);
        if (q == 1) {
            // Q1 cumulative is the quarter.
            current.setMonthsCovered(3);
            return;
        }

        java.time.LocalDate prevEnd = FiscalCalendar.previousQuarterEnd(quarterEnd);
        Optional<Financial> prevOpt =
                financials.findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
                        companyId, prevEnd, PeriodType.Q, consolidated);
        if (prevOpt.isEmpty()) {
            return;
        }
        Financial prev = prevOpt.get();
        if (FiscalCalendar.fiscalYear(prevEnd) != FiscalCalendar.fiscalYear(quarterEnd)) {
            return;
        }
        Integer prevMonths = prev.getMonthsCovered();
        Integer curMonths = current.getMonthsCovered();
        if (prevMonths == null || curMonths == null || curMonths - prevMonths != 3) {
            return;
        }

        current.setRevenue(Nums.sub(current.getRevenue(), prev.getRevenue()));
        current.setOtherIncome(Nums.sub(current.getOtherIncome(), prev.getOtherIncome()));
        current.setTotalExpenses(Nums.sub(current.getTotalExpenses(), prev.getTotalExpenses()));
        current.setOperatingProfit(
                Nums.sub(current.getOperatingProfit(), prev.getOperatingProfit()));
        current.setDepreciation(Nums.sub(current.getDepreciation(), prev.getDepreciation()));
        current.setFinanceCosts(Nums.sub(current.getFinanceCosts(), prev.getFinanceCosts()));
        current.setProfitBeforeTax(
                Nums.sub(current.getProfitBeforeTax(), prev.getProfitBeforeTax()));
        current.setTaxExpense(Nums.sub(current.getTaxExpense(), prev.getTaxExpense()));
        current.setNetProfit(Nums.sub(current.getNetProfit(), prev.getNetProfit()));
        current.setEps(Nums.sub(current.getEps(), prev.getEps()));
        current.setMonthsCovered(3);
        current.setDerivation(Derivation.YTD_DIFF);

        String warn = q == 4 ? "q4_derived_from_fy_minus_9m" : "quarter_derived_from_ytd";
        current.setWarnings(JsonWarnings.append(current.getWarnings(), warn));
    }

    private static boolean isPlausibleFaceValue(BigDecimal faceValue) {
        return faceValue != null && faceValue.signum() > 0
                && faceValue.compareTo(MAX_PLAUSIBLE_FACE_VALUE) <= 0;
    }
}
