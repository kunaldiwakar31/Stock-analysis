package com.stockscreener.xbrl;

import com.stockscreener.common.RoundingLevel;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Reproduces the reported bug: {@code sharesOutstanding} stored 10<sup>7</sup> times too
 * large.
 *
 * <p>Root cause: the "Level of rounding used in financial results" governs the Financial
 * Results / Balance Sheet / Cash Flow tables, but does not reliably govern the "Details of
 * equity share capital" block. Face value is already read unscaled for this reason; paid-up
 * capital was not, and some preparers tag it in absolute rupees regardless of the declared
 * statement rounding.
 *
 * <p>The 10,000,000x figure is not arbitrary — it is exactly
 * {@code RoundingLevel.CRORES.factor() / RoundingLevel.UNITS.factor()} (100 / 0.00001). A
 * filing whose statements are in Crores but whose share-capital block is absolute rupees
 * produces precisely this distortion when the statement's factor is applied to it.
 */
class PaidUpCapitalScaleTest {

    private static final LocalDate Q_END = LocalDate.of(2025, 9, 30);

    private final FilingExtractor extractor = new FilingExtractor(new ConceptMap());

    private void fact(XbrlDocument doc, String concept, String ctxId, String value) {
        XbrlDocument.Fact f = new XbrlDocument.Fact();
        f.concept = concept;
        f.contextRef = ctxId;
        f.value = value;
        doc.facts.add(f);
    }

    /**
     * A minimal filing: one duration context carrying just enough profit-and-loss facts to
     * be selected as the quarter context, plus the general-info and share-capital facts
     * under test. Real filings carry far more, but context selection only needs enough
     * facts to win {@code factScore > 0}.
     */
    private XbrlDocument minimalFiling(String roundingLevelText, String faceValue,
                                       String paidUpCapitalRaw) {
        XbrlDocument doc = new XbrlDocument();

        XbrlDocument.Context ctx = new XbrlDocument.Context();
        ctx.id = "ThreeD";
        ctx.start = LocalDate.of(2025, 7, 1);
        ctx.end = Q_END;
        ctx.dimensionKey = "";
        doc.contexts.put(ctx.id, ctx);

        fact(doc, "LevelOfRoundingUsedInFinancialResults", "ThreeD", roundingLevelText);
        fact(doc, "RevenueFromOperations", "ThreeD", "20223");
        fact(doc, "ProfitLossForPeriod", "ThreeD", "4303");

        if (faceValue != null) {
            fact(doc, "FaceValueOfEquityShareCapital", "ThreeD", faceValue);
        }
        if (paidUpCapitalRaw != null) {
            fact(doc, "PaidUpValueOfEquityShareCapital", "ThreeD", paidUpCapitalRaw);
        }

        doc.index();
        return doc;
    }

    private FilingExtractor.Result extract(XbrlDocument doc) {
        return extractor.extract(doc, Q_END, false, "https://example/test.xml", Boolean.FALSE);
    }

    @Test
    @DisplayName("sanity: the reported distortion is exactly CRORES / UNITS")
    void distortionFactorIsExactlyTenMillion() {
        BigDecimal ratio = RoundingLevel.CRORES.factor()
                .divide(RoundingLevel.UNITS.factor());
        assertEquals(0, new BigDecimal("10000000").compareTo(ratio),
                "the bug report's '1e7 times too large' is this exact ratio");
    }

    @Test
    @DisplayName("reproduces the bug: absolute paid-up capital scaled as Crores inflates 1e7x")
    void reproducesTheReportedBug() {
        // Face value: 10 rupees, always absolute - this part was never wrong.
        // Paid-up capital: 529,900,000 rupees, tagged absolute in the share-capital block,
        // while the statement declares "Crores". Naively applying CRORES.toLakh() to this
        // raw value (multiply by 100) previously produced a paid-up-capital-in-lakh figure
        // that is 1e7x too large once divided back into shares.
        XbrlDocument doc = minimalFiling("Crores", "10", "529900000");

        FilingExtractor.Result res = extract(doc);

        assertNotNull(res.paidUpCapital, "the plausible absolute-rupee reading must be used");
        // 529,900,000 rupees read as absolute = 5,299 lakh - matches the Thyrocare fixture
        // used elsewhere in this project (paid-up capital 5,299 lakh, face value 10).
        assertEquals(0, new BigDecimal("5299").compareTo(res.paidUpCapital));
        assertTrue(res.warnings.stream()
                        .anyMatch(w -> w.contains("treated_as_absolute_not_CRORES")),
                "the override must be recorded, not applied silently: " + res.warnings);
    }

    @Test
    @DisplayName("does not touch a filing where the declared scale is actually correct")
    void leavesACorrectlyScaledFilingAlone() {
        // Same company, but here the share-capital block genuinely follows the statement's
        // declared rounding - this is the common case (e.g. the real Thyrocare filing) and
        // must not be second-guessed.
        XbrlDocument doc = minimalFiling("Lakhs", "10", "5299");

        FilingExtractor.Result res = extract(doc);

        assertEquals(0, new BigDecimal("5299").compareTo(res.paidUpCapital));
        assertTrue(res.warnings.stream().noneMatch(w -> w.contains("paid_up_capital")),
                "a correctly scaled filing should need no override: " + res.warnings);
    }

    @Test
    @DisplayName("refuses to guess when neither reading is plausible")
    void refusesToGuessWhenNeitherReadingFits() {
        // A number that is implausible whether read as Crores (0.01 lakh -> ~0 shares) or
        // as absolute rupees (1e-9 lakh -> effectively 0 shares) - e.g. a genuinely
        // corrupted or mis-tagged fact. The fix must not paper over this by picking
        // whichever of the two candidates happens to be less wrong.
        XbrlDocument doc = minimalFiling("Crores", "10", "0.0001");

        FilingExtractor.Result res = extract(doc);

        assertNull(res.paidUpCapital,
                "neither reading is plausible, so nothing should be stored");
        assertTrue(res.warnings.stream().anyMatch(w -> w.contains("scale_unresolved")),
                "the failure must be recorded for /admin/inspect-filing: " + res.warnings);
    }

    @Test
    @DisplayName("the same guard applies to the per-row paid-up capital, not only the share count")
    void appliesTheSameGuardToRowLevelData() {
        XbrlDocument doc = minimalFiling("Crores", "10", "529900000");

        FilingExtractor.Result res = extract(doc);

        Financial q = res.rows.stream()
                .filter(f -> f.getPeriodType() == PeriodType.Q)
                .findFirst().orElse(null);
        assertNotNull(q);
        assertNotNull(q.getPaidUpCapital(),
                "the row's own paid-up capital must use the same corrected reading");
        assertEquals(0, new BigDecimal("5299").compareTo(q.getPaidUpCapital()));
    }

    @Test
    @DisplayName("without a face value the oracle cannot run, so the declared scale is trusted")
    void trustsDeclaredScaleWhenFaceValueIsMissing() {
        XbrlDocument doc = minimalFiling("Crores", null, "529900000");

        FilingExtractor.Result res = extract(doc);

        // No face value means plausibleShareCount cannot be evaluated at all, so this falls
        // back to the pre-existing behaviour rather than guessing blind.
        assertEquals(0, RoundingLevel.CRORES.toLakh(new BigDecimal("529900000"))
                .compareTo(res.paidUpCapital));
    }
}
