package com.stockscreener.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Indian fiscal calendar, April to March.
 *
 * <p>Worth its own tests because an off-by-one here misaligns every year-on-year
 * comparison in the system, and the symptom is a plausible-looking wrong number.
 */
class FiscalCalendarTest {

    @Test
    @DisplayName("June 2026 quarter is Q1 of FY27")
    void mapsQuartersToFiscalYears() {
        LocalDate jun2026 = LocalDate.of(2026, 6, 30);
        assertEquals(2027, FiscalCalendar.fiscalYear(jun2026));
        assertEquals(1, FiscalCalendar.fiscalQuarter(jun2026));

        LocalDate sep2025 = LocalDate.of(2025, 9, 30);
        assertEquals(2026, FiscalCalendar.fiscalYear(sep2025));
        assertEquals(2, FiscalCalendar.fiscalQuarter(sep2025));

        LocalDate dec2025 = LocalDate.of(2025, 12, 31);
        assertEquals(2026, FiscalCalendar.fiscalYear(dec2025));
        assertEquals(3, FiscalCalendar.fiscalQuarter(dec2025));

        LocalDate mar2026 = LocalDate.of(2026, 3, 31);
        assertEquals(2026, FiscalCalendar.fiscalYear(mar2026));
        assertEquals(4, FiscalCalendar.fiscalQuarter(mar2026));
    }

    @Test
    void reportsCumulativeMonths() {
        assertEquals(3, FiscalCalendar.ytdMonths(LocalDate.of(2026, 6, 30)));
        assertEquals(6, FiscalCalendar.ytdMonths(LocalDate.of(2025, 9, 30)));
        assertEquals(9, FiscalCalendar.ytdMonths(LocalDate.of(2025, 12, 31)));
        assertEquals(12, FiscalCalendar.ytdMonths(LocalDate.of(2026, 3, 31)));
    }

    @Test
    @DisplayName("previous quarter end lands on the last day of the month")
    void walksBackAQuarter() {
        assertEquals(LocalDate.of(2026, 3, 31),
                FiscalCalendar.previousQuarterEnd(LocalDate.of(2026, 6, 30)));
        assertEquals(LocalDate.of(2025, 12, 31),
                FiscalCalendar.previousQuarterEnd(LocalDate.of(2026, 3, 31)));
        // September has 30 days, so a naive minusMonths would produce 30 June from 30 Sep
        // and 31 March would be lost entirely.
        assertEquals(LocalDate.of(2025, 6, 30),
                FiscalCalendar.previousQuarterEnd(LocalDate.of(2025, 9, 30)));
    }

    @Test
    void findsTheSameQuarterAYearEarlier() {
        assertEquals(LocalDate.of(2025, 6, 30),
                FiscalCalendar.sameQuarterLastYear(LocalDate.of(2026, 6, 30)));
    }

    @Test
    void identifiesFiscalYearEnds() {
        assertTrue(FiscalCalendar.isFiscalYearEnd(LocalDate.of(2026, 3, 31)));
        assertFalse(FiscalCalendar.isFiscalYearEnd(LocalDate.of(2026, 6, 30)));
    }
}
