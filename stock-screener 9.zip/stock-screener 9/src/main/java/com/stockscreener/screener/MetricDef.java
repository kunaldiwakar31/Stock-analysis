package com.stockscreener.screener;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * One whitelisted, queryable metric.
 *
 * <p>{@link #attribute()} is a fixed entity attribute name chosen by this codebase, never
 * anything derived from user input. That is what makes the query language safe: a user
 * identifier is either matched to a {@code MetricDef} or rejected, so no user-supplied
 * string ever reaches SQL.
 */
public class MetricDef {

    private final String key;
    private final Set<String> aliases;
    /** JPA attribute name on CompanyMetrics. */
    private final String attribute;
    private final Unit unit;
    private final String label;
    /** When the underlying data refreshes; surfaced so empty results are explicable. */
    private final Availability availability;

    public enum Availability {
        /** Refreshes with every quarterly filing. */
        QUARTERLY,
        /** Balance-sheet or cash-flow backed; SEBI requires those only half-yearly. */
        HALF_YEARLY,
        /** Requires the bhavcopy price feed. */
        NEEDS_PRICE,
        /** Requires the separate NSE shareholding-pattern filing. */
        NEEDS_SHAREHOLDING,
        /** Requires several years of annual history. */
        NEEDS_HISTORY,
        /** Requires an LLM pass. */
        NEEDS_ANALYSIS,
        STATIC
    }

    public MetricDef(String key, String attribute, Unit unit, Availability availability,
                     String label, String... aliases) {
        this.key = key;
        this.attribute = attribute;
        this.unit = unit;
        this.availability = availability;
        this.label = label;
        Set<String> a = new LinkedHashSet<>();
        a.add(key);
        a.addAll(Arrays.asList(aliases));
        this.aliases = Collections.unmodifiableSet(a);
    }

    public String key() {
        return key;
    }

    public Set<String> aliases() {
        return aliases;
    }

    public String attribute() {
        return attribute;
    }

    public Unit unit() {
        return unit;
    }

    public String label() {
        return label;
    }

    public Availability availability() {
        return availability;
    }

    public boolean isNumeric() {
        return unit != Unit.TEXT && unit != Unit.ENUM && unit != Unit.BOOL;
    }
}
