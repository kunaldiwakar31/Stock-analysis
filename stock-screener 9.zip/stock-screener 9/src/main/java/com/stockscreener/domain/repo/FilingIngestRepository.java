package com.stockscreener.domain.repo;

import com.stockscreener.domain.Enums.IngestStatus;
import com.stockscreener.domain.FilingIngest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FilingIngestRepository extends JpaRepository<FilingIngest, Long> {

    Optional<FilingIngest> findByXbrlUrl(String xbrlUrl);

    boolean existsByXbrlUrl(String xbrlUrl);

    List<FilingIngest> findByStatusOrderByQuarterEndDesc(IngestStatus status, Pageable page);

    long countByStatus(IngestStatus status);

    /**
     * All filings for one natural key, newest broadcast first.
     *
     * <p>Used to pick a winner when a revision supersedes an original: roughly 11% of
     * filings in the NSE index are revisions, and some of those correct the declared
     * denomination, so the latest is the only one that should be parsed.
     */
    List<FilingIngest> findBySymbolAndQuarterEndAndConsolidatedOrderByBroadcastAtDesc(
            String symbol, java.time.LocalDate quarterEnd, boolean consolidated);
}
