package com.stockscreener.corporateactions;

import com.stockscreener.common.Nums;

import java.math.BigDecimal;

/**
 * Classifies a share-count jump between two filings as a genuine, restatable corporate
 * action or something that must be left alone.
 *
 * <p>Pure function, no I/O, "null/implausible in, no-guess out" — same philosophy as
 * {@link com.stockscreener.metrics.RatioCalculator} and {@link
 * com.stockscreener.technicals.TechnicalIndicatorCalculator}: every decision here is
 * either backed by a real signal or it declines to decide.
 *
 * <p>The distinction that matters is not "did the share count move a lot" — buybacks,
 * ESOP allotments and preferential issues all do that too — it is "was this a pro-rata
 * event that makes every {@code eps} filed before it incomparable with every {@code eps}
 * filed after it." Two independent signals answer that:
 *
 * <ul>
 *   <li><b>Face value changed</b> (e.g. &#8377;10 &#8594; &#8377;5): a stock split or
 *       consolidation, confirmed by checking the share-count ratio against the face-value
 *       ratio directly — no denominator, no guessing, because the two numbers either
 *       agree or they do not.</li>
 *   <li><b>Face value unchanged, share count grew by a simple ratio</b> (1:1, 1:2, 5:1,
 *       1:10, ...): a bonus issue. A shrinking count with an unchanged face value is
 *       necessarily a buyback or forfeiture — real, but not pro-rata — and must never be
 *       restated even if the ratio happens to look "clean."</li>
 * </ul>
 *
 * <p>Anything outside a plausible magnitude (more than 20x up, or below 1/20th) is
 * flagged {@link Type#IMPLAUSIBLE} rather than accepted at face value: no real corporate
 * action moves a share count that far in one filing, so a jump that large is far more
 * likely the same class of extraction/scale bug already fixed for paid-up capital and
 * the document-wide rounding level.
 */
public final class ShareCountChangeClassifier {

    public enum Type {
        /** Confirmed via a matching face-value change. Always restate. */
        SPLIT,
        /** Flat face value, share count grew by a simple ratio. Always restate. */
        BONUS,
        /** A real change (buyback, ESOP allotment, preferential issue, or a ratio that
         *  doesn't resolve cleanly) that must not be restated. */
        MINOR_CHANGE,
        /** Outside any plausible corporate-action magnitude; likely a data/scale error. */
        IMPLAUSIBLE
    }

    public record Classification(BigDecimal ratio, Type type) {
        public boolean restatementRecommended() {
            return type == Type.SPLIT || type == Type.BONUS;
        }
    }

    private static final BigDecimal IMPLAUSIBLE_HIGH = BigDecimal.valueOf(20);
    private static final BigDecimal IMPLAUSIBLE_LOW = new BigDecimal("0.05");
    private static final BigDecimal TOLERANCE = new BigDecimal("0.005");
    private static final int MAX_DENOMINATOR = 10;

    private ShareCountChangeClassifier() {
    }

    public static Classification classify(BigDecimal facePrev, BigDecimal faceNew,
                                          BigDecimal sharesPrev, BigDecimal sharesNew) {
        BigDecimal ratio = Nums.div(sharesNew, sharesPrev);
        if (ratio == null || ratio.signum() <= 0
                || ratio.compareTo(IMPLAUSIBLE_HIGH) > 0
                || ratio.compareTo(IMPLAUSIBLE_LOW) < 0) {
            return new Classification(ratio, Type.IMPLAUSIBLE);
        }

        boolean faceValueChanged = Nums.isPositive(facePrev) && Nums.isPositive(faceNew)
                && facePrev.compareTo(faceNew) != 0;

        if (faceValueChanged) {
            BigDecimal impliedByFaceValue = Nums.div(facePrev, faceNew);
            if (impliedByFaceValue != null && withinTolerance(ratio, impliedByFaceValue)) {
                return new Classification(ratio, Type.SPLIT);
            }
            // Face value moved but the share count doesn't follow from it - something
            // else happened at the same time; don't guess which.
            return new Classification(ratio, Type.MINOR_CHANGE);
        }

        if (ratio.compareTo(BigDecimal.ONE) > 0 && isCleanRatio(ratio)) {
            return new Classification(ratio, Type.BONUS);
        }
        return new Classification(ratio, Type.MINOR_CHANGE);
    }

    private static boolean withinTolerance(BigDecimal a, BigDecimal b) {
        BigDecimal diff = a.subtract(b).abs();
        BigDecimal allowed = a.abs().multiply(TOLERANCE);
        return diff.compareTo(allowed) <= 0;
    }

    /**
     * True when {@code ratio} sits within {@link #TOLERANCE} of some p/q with a small
     * denominator - the signature of a genuine bonus ratio (1:1, 1:2, 5:1, 1:10, ...).
     *
     * <p>The denominator cap is deliberately small. Past a point, every real number is
     * "close" to some fraction (Dirichlet's approximation theorem guarantees it) - a
     * loose cap would rubber-stamp ordinary ESOP dilution (say, a 5% increase) as a
     * bonus issue just because some fraction with a large denominator happens to be
     * nearby. Capping small keeps this to ratios a filer would actually declare.
     */
    static boolean isCleanRatio(BigDecimal ratio) {
        double r = ratio.doubleValue();
        double tol = r * TOLERANCE.doubleValue();
        for (int q = 1; q <= MAX_DENOMINATOR; q++) {
            long p = Math.round(r * q);
            if (p < 1) {
                continue;
            }
            double candidate = (double) p / q;
            if (Math.abs(r - candidate) <= tol) {
                return true;
            }
        }
        return false;
    }
}
