package com.stockscreener.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Daily close from the NSE bhavcopy.
 *
 * <p>Exists only because the 52-week high and low need price history. Everything else
 * that is price-derived is computed once and lands in {@link CompanyMetrics}.
 */
@Entity
@Table(name = "daily_prices",
        uniqueConstraints = @UniqueConstraint(name = "uk_price",
                columnNames = {"company_id", "trade_date"}))
@Getter
@Setter
public class DailyPrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "company_id", nullable = false)
    private Long companyId;

    @Column(name = "trade_date", nullable = false)
    private LocalDate tradeDate;

    @Column(name = "close_price", nullable = false)
    private BigDecimal closePrice;

    @Column(name = "high_price")
    private BigDecimal highPrice;

    @Column(name = "low_price")
    private BigDecimal lowPrice;

    private Long volume;
}
