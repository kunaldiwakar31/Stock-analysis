package com.stockscreener.common;

import java.math.BigDecimal;

/**
 * The "Level of rounding used in financial results" declared by each filer.
 *
 * <p>This is a <b>per-filing</b> field, and it is the single most dangerous piece of
 * this dataset: the same XBRL concept arrives at 100x different magnitudes depending on
 * what the filer chose. Thyrocare reports in Lakhs; others use Thousands, Millions or
 * Crores. Getting this wrong doesn't throw — it silently produces a screener where a
 * small-cap looks like a conglomerate.
 *
 * <p>Everything is normalised to <b>rupees lakh</b> on write. There is deliberately no
 * default: an unrecognised or absent value must fail the filing rather than be guessed.
 */
public enum RoundingLevel {

    UNITS(new BigDecimal("0.00001")),
    HUNDREDS(new BigDecimal("0.001")),
    THOUSANDS(new BigDecimal("0.01")),
    LAKHS(BigDecimal.ONE),
    MILLIONS(BigDecimal.TEN),
    CRORES(BigDecimal.valueOf(100)),
    BILLIONS(BigDecimal.valueOf(10000));

    private final BigDecimal toLakhFactor;

    RoundingLevel(BigDecimal toLakhFactor) {
        this.toLakhFactor = toLakhFactor;
    }

    public BigDecimal factor() {
        return toLakhFactor;
    }

    public BigDecimal toLakh(BigDecimal raw) {
        return raw == null ? null : raw.multiply(toLakhFactor, Nums.MC);
    }

    /**
     * Parses the filer's free-text declaration.
     *
     * @throws IllegalArgumentException when the text is absent or unrecognised — callers
     *     must fail the filing. Defaulting here would be the worst possible choice.
     */
    public static RoundingLevel parse(String raw) {
        if (raw == null || raw.trim().isEmpty()) {
            throw new IllegalArgumentException("Rounding level absent; refusing to guess scale");
        }
        String s = raw.trim().toLowerCase();
        if (s.contains("lakh") || s.contains("lac")) {
            return LAKHS;
        }
        if (s.contains("crore") || s.contains("cr.")) {
            return CRORES;
        }
        if (s.contains("million") || s.equals("mn")) {
            return MILLIONS;
        }
        if (s.contains("billion") || s.equals("bn")) {
            return BILLIONS;
        }
        if (s.contains("thousand") || s.equals("'000") || s.equals("000")) {
            return THOUSANDS;
        }
        if (s.contains("hundred")) {
            return HUNDREDS;
        }
        if (s.contains("absolute") || s.contains("unit") || s.contains("actual")) {
            return UNITS;
        }
        throw new IllegalArgumentException("Unrecognised rounding level: '" + raw + "'");
    }

    /**
     * Independent cross-check on the scale decision.
     *
     * <p>{@code paid_up_capital / face_value} must give a plausible share count. If the
     * scale was misread by 100x this lands orders of magnitude away from anything real,
     * which catches the error before it reaches a ratio. Range is deliberately wide —
     * it is a sanity net, not a validation rule.
     *
     * @param paidUpCapitalLakh already normalised to lakh
     * @param faceValue rupees per share, as filed
     * @return true when the implied share count is plausible
     */
    public static boolean plausibleShareCount(BigDecimal paidUpCapitalLakh, BigDecimal faceValue) {
        if (!Nums.isPositive(paidUpCapitalLakh) || !Nums.isPositive(faceValue)) {
            return false;
        }
        // shares (in lakh) = paid-up capital (lakh) / face value
        BigDecimal sharesLakh = Nums.div(paidUpCapitalLakh, faceValue);
        if (sharesLakh == null) {
            return false;
        }
        double s = sharesLakh.doubleValue();
        // 10k shares to 500 billion shares, expressed in lakh
        return s >= 0.1 && s <= 5_000_000d;
    }
}
