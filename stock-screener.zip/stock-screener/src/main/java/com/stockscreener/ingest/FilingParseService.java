package com.stockscreener.ingest;

import com.stockscreener.common.FiscalCalendar;
import com.stockscreener.common.Nums;
import com.stockscreener.domain.Company;
import com.stockscreener.domain.Enums.Derivation;
import com.stockscreener.domain.Enums.IngestStatus;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import com.stockscreener.domain.FilingIngest;
import com.stockscreener.domain.repo.CompanyRepository;
import com.stockscreener.domain.repo.FilingIngestRepository;
import com.stockscreener.domain.repo.FinancialRepository;
import com.stockscreener.xbrl.FilingExtractor;
import com.stockscreener.xbrl.XbrlDocument;
import com.stockscreener.xbrl.XbrlFetcher;
import com.stockscreener.xbrl.XbrlStaxParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/** Downloads queued filings, parses them, and persists the line items. */
@Service
public class FilingParseService {

    private static final Logger log = LoggerFactory.getLogger(FilingParseService.class);
    private static final BigDecimal LAKH = BigDecimal.valueOf(100_000);

    private final FilingIngestRepository ingests;
    private final FinancialRepository financials;
    private final CompanyRepository companies;
    private final XbrlFetcher fetcher;
    private final FilingExtractor extractor;
    private final XbrlStaxParser parser = new XbrlStaxParser();

    /**
     * Self-reference through the Spring proxy.
     *
     * <p>Calling {@code this.processOne(...)} directly from the loop below would bypass the
     * proxy, so {@code @Transactional} would not apply and every mutation to a managed
     * entity — including marking the filing DONE — would be silently discarded. The filings
     * would then stay PENDING and be reprocessed forever.
     */
    private final ObjectProvider<FilingParseService> self;

    public FilingParseService(FilingIngestRepository ingests, FinancialRepository financials,
                              CompanyRepository companies, XbrlFetcher fetcher,
                              FilingExtractor extractor,
                              ObjectProvider<FilingParseService> self) {
        this.ingests = ingests;
        this.financials = financials;
        this.companies = companies;
        this.fetcher = fetcher;
        this.extractor = extractor;
        this.self = self;
    }

    /**
     * Processes up to {@code limit} pending filings.
     *
     * <p>One filing per transaction on purpose: a single malformed instance out of 23,000
     * must not roll back the rest of the batch.
     */
    public int processPending(int limit) {
        List<FilingIngest> batch = ingests.findByStatusOrderByQuarterEndDesc(
                IngestStatus.PENDING, PageRequest.of(0, limit));
        FilingParseService proxy = self.getObject();
        int ok = 0;
        for (FilingIngest fi : batch) {
            try {
                proxy.processOne(fi.getId());
                ok++;
            } catch (Exception e) {
                proxy.recordFailure(fi.getId(), e);
                log.warn("Filing {} failed: {}", fi.getXbrlUrl(), e.toString());
            }
        }
        return ok;
    }

    @Transactional
    public void processOne(Long ingestId) throws Exception {
        FilingIngest fi = ingests.findById(ingestId).orElseThrow();
        Company company = companies.findBySymbol(fi.getSymbol()).orElseThrow(
                () -> new IllegalStateException("Unknown symbol " + fi.getSymbol()));

        XbrlDocument doc;
        try (InputStream in = fetcher.open(fi.getXbrlUrl())) {
            doc = parser.parse(in);
        }

        FilingExtractor.Result res = extractor.extract(
                doc, fi.getQuarterEnd(), fi.isConsolidated(), fi.getXbrlUrl(), fi.getAudited());

        enrichCompany(company, res);

        for (Financial f : res.rows) {
            f.setCompanyId(company.getId());
            f.setFiledAt(fi.getBroadcastAt());
            if (!res.warnings.isEmpty()) {
                f.setWarnings(toJsonArray(res.warnings));
            }
            upsert(f);
        }

        deriveQuarterFromYtd(company.getId(), fi.getQuarterEnd(), fi.isConsolidated());

        fi.setStatus(IngestStatus.DONE);
        fi.setAttempts(fi.getAttempts() + 1);
        fi.setErrorMessage(res.warnings.isEmpty() ? null : String.join("; ", res.warnings));
    }

    @Transactional
    public void recordFailure(Long ingestId, Exception e) {
        ingests.findById(ingestId).ifPresent(fi -> {
            fi.setAttempts(fi.getAttempts() + 1);
            fi.setStatus(IngestStatus.FAILED);
            fi.setErrorMessage(e.getClass().getSimpleName() + ": " + e.getMessage());
        });
    }

    /**
     * Fills in company attributes the filing supplies.
     *
     * <p>The share count is derived rather than sourced: paid-up capital divided by face
     * value. That single division is what makes market cap, P/E and P/B possible from a
     * price alone, since the filings themselves carry no market data.
     */
    private void enrichCompany(Company c, FilingExtractor.Result res) {
        if (res.isin != null && c.getIsin() == null) {
            c.setIsin(res.isin.trim());
        }
        if (res.faceValue != null && res.faceValue.signum() > 0) {
            c.setFaceValue(res.faceValue);
        }
        if (res.paidUpCapital != null && c.getFaceValue() != null
                && c.getFaceValue().signum() > 0) {
            // paid-up capital is in lakh, so scale to rupees before dividing.
            BigDecimal shares = res.paidUpCapital.multiply(LAKH, Nums.MC)
                    .divide(c.getFaceValue(), Nums.MC);
            BigDecimal prev = c.getSharesOutstanding();
            if (prev != null && prev.signum() > 0) {
                BigDecimal change = shares.subtract(prev).abs()
                        .divide(prev, Nums.MC);
                if (change.compareTo(new BigDecimal("0.05")) > 0) {
                    // A jump this large means a bonus, split, buyback or ESOP allotment,
                    // all of which break comparability of historical per-share figures.
                    log.info("Share count for {} moved {}%; historical EPS is not comparable",
                            c.getSymbol(), change.multiply(Nums.HUNDRED).setScale(1,
                                    java.math.RoundingMode.HALF_UP));
                }
            }
            c.setSharesOutstanding(shares);
        }
    }

    private void upsert(Financial f) {
        Optional<Financial> existing =
                financials.findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
                        f.getCompanyId(), f.getPeriodEnd(), f.getPeriodType(),
                        f.isConsolidated());
        if (existing.isEmpty()) {
            financials.save(f);
            return;
        }
        Financial e = existing.get();
        // A revision supersedes what was stored, so overwrite rather than merge.
        e.setMonthsCovered(f.getMonthsCovered());
        e.setDerivation(f.getDerivation());
        e.setAudited(f.getAudited());
        e.setSourceUrl(f.getSourceUrl());
        e.setRoundingLevel(f.getRoundingLevel());
        e.setFiledAt(f.getFiledAt());
        e.setRevenue(f.getRevenue());
        e.setOtherIncome(f.getOtherIncome());
        e.setTotalExpenses(f.getTotalExpenses());
        e.setOperatingProfit(f.getOperatingProfit());
        e.setDepreciation(f.getDepreciation());
        e.setFinanceCosts(f.getFinanceCosts());
        e.setProfitBeforeTax(f.getProfitBeforeTax());
        e.setTaxExpense(f.getTaxExpense());
        e.setNetProfit(f.getNetProfit());
        e.setEps(f.getEps());
        e.setTotalEquity(f.getTotalEquity());
        e.setTotalBorrowings(f.getTotalBorrowings());
        e.setCashAndInvestments(f.getCashAndInvestments());
        e.setTotalAssets(f.getTotalAssets());
        e.setPaidUpCapital(f.getPaidUpCapital());
        e.setCashFromOperations(f.getCashFromOperations());
        e.setCapex(f.getCapex());
        e.setDividendsPaid(f.getDividendsPaid());
        e.setWarnings(f.getWarnings());
    }

    /**
     * Back-computes a three-month quarter from two cumulative figures.
     *
     * <p>Only applies when the filer omitted the three-month column. The subtraction is
     * restricted to the same fiscal year and the same basis, because crossing either
     * boundary produces a meaningless number.
     *
     * <p>Q4 deserves particular suspicion: it is commonly filed as audited full-year
     * figures only, so the derived quarter absorbs every year-end adjustment at once. The
     * row is still stored, but labelled {@link Derivation#YTD_DIFF} so nothing downstream
     * mistakes it for a clean reported quarter.
     */
    private void deriveQuarterFromYtd(Long companyId, java.time.LocalDate quarterEnd,
                                     boolean consolidated) {
        Optional<Financial> currentOpt =
                financials.findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
                        companyId, quarterEnd, PeriodType.Q, consolidated);
        if (currentOpt.isEmpty()) {
            return;
        }
        Financial current = currentOpt.get();
        if (current.getMonthsCovered() != null && current.getMonthsCovered() == 3) {
            return; // Already a real quarter.
        }

        int q = FiscalCalendar.fiscalQuarter(quarterEnd);
        if (q == 1) {
            // Q1 cumulative is the quarter.
            current.setMonthsCovered(3);
            return;
        }

        java.time.LocalDate prevEnd = FiscalCalendar.previousQuarterEnd(quarterEnd);
        Optional<Financial> prevOpt =
                financials.findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
                        companyId, prevEnd, PeriodType.Q, consolidated);
        if (prevOpt.isEmpty()) {
            return;
        }
        Financial prev = prevOpt.get();
        if (FiscalCalendar.fiscalYear(prevEnd) != FiscalCalendar.fiscalYear(quarterEnd)) {
            return;
        }
        Integer prevMonths = prev.getMonthsCovered();
        Integer curMonths = current.getMonthsCovered();
        if (prevMonths == null || curMonths == null || curMonths - prevMonths != 3) {
            return;
        }

        current.setRevenue(Nums.sub(current.getRevenue(), prev.getRevenue()));
        current.setOtherIncome(Nums.sub(current.getOtherIncome(), prev.getOtherIncome()));
        current.setTotalExpenses(Nums.sub(current.getTotalExpenses(), prev.getTotalExpenses()));
        current.setOperatingProfit(
                Nums.sub(current.getOperatingProfit(), prev.getOperatingProfit()));
        current.setDepreciation(Nums.sub(current.getDepreciation(), prev.getDepreciation()));
        current.setFinanceCosts(Nums.sub(current.getFinanceCosts(), prev.getFinanceCosts()));
        current.setProfitBeforeTax(
                Nums.sub(current.getProfitBeforeTax(), prev.getProfitBeforeTax()));
        current.setTaxExpense(Nums.sub(current.getTaxExpense(), prev.getTaxExpense()));
        current.setNetProfit(Nums.sub(current.getNetProfit(), prev.getNetProfit()));
        current.setEps(Nums.sub(current.getEps(), prev.getEps()));
        current.setMonthsCovered(3);
        current.setDerivation(Derivation.YTD_DIFF);

        String warn = q == 4 ? "q4_derived_from_fy_minus_9m" : "quarter_derived_from_ytd";
        current.setWarnings(appendWarning(current.getWarnings(), warn));
    }

    // ------------------------------------------------------------------

    private static String toJsonArray(List<String> items) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(items.get(i).replace("\"", "'")).append('"');
        }
        return sb.append(']').toString();
    }

    private static String appendWarning(String json, String warning) {
        if (json == null || json.isBlank() || "[]".equals(json.trim())) {
            return "[\"" + warning + "\"]";
        }
        String trimmed = json.trim();
        if (trimmed.endsWith("]")) {
            return trimmed.substring(0, trimmed.length() - 1) + ",\"" + warning + "\"]";
        }
        return "[\"" + warning + "\"]";
    }
}
