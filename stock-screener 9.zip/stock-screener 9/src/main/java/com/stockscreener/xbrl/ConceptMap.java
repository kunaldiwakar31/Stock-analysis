package com.stockscreener.xbrl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;
import org.yaml.snakeyaml.Yaml;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Maps XBRL concept names onto target fields.
 *
 * <p>Deliberately external configuration rather than a hard-coded switch. Exact taxonomy
 * element names differ between SEBI taxonomy revisions and between preparers, so the
 * mapping is a list of candidate aliases per field, resolved in order. Correcting a name
 * is a config edit, not a code change and redeploy.
 *
 * <p>Unmapped concepts are counted rather than ignored. Without that count you cannot
 * know what the parser is silently dropping — so {@link #unmappedByFrequency()} backs an
 * admin endpoint that turns coverage gaps into a prioritised worklist.
 */
@Component
public class ConceptMap {

    private static final Logger log = LoggerFactory.getLogger(ConceptMap.class);
    private static final String RESOURCE = "xbrl-concepts.yml";

    /** field name to ordered candidate concepts. */
    private final Map<String, List<String>> fieldToConcepts = new LinkedHashMap<>();
    /** lowercased concept to field name. */
    private final Map<String, String> conceptToField = new LinkedHashMap<>();
    private final Set<String> knownConcepts = new LinkedHashSet<>();

    private final Map<String, AtomicLong> unmapped = new ConcurrentHashMap<>();

    public ConceptMap() {
        load();
    }

    @SuppressWarnings("unchecked")
    private void load() {
        try (InputStream in = new ClassPathResource(RESOURCE).getInputStream()) {
            Map<String, Object> root = new Yaml().load(in);
            if (root == null) {
                throw new IllegalStateException(RESOURCE + " is empty");
            }
            Map<String, Object> fields = (Map<String, Object>) root.get("fields");
            if (fields == null) {
                throw new IllegalStateException(RESOURCE + " has no 'fields' section");
            }
            for (Map.Entry<String, Object> e : fields.entrySet()) {
                List<String> aliases = new ArrayList<>();
                Object v = e.getValue();
                if (v instanceof List) {
                    for (Object o : (List<Object>) v) {
                        aliases.add(String.valueOf(o));
                    }
                } else if (v != null) {
                    aliases.add(String.valueOf(v));
                }
                fieldToConcepts.put(e.getKey(), aliases);
                for (String a : aliases) {
                    String k = a.toLowerCase(Locale.ENGLISH);
                    conceptToField.put(k, e.getKey());
                    knownConcepts.add(k);
                }
            }
            log.info("Loaded {} XBRL field mappings covering {} concepts",
                    fieldToConcepts.size(), knownConcepts.size());
        } catch (IOException e) {
            throw new IllegalStateException("Cannot read " + RESOURCE, e);
        }
    }

    /** Candidate concept names for a field, in priority order. */
    public List<String> conceptsFor(String field) {
        return fieldToConcepts.getOrDefault(field, List.of());
    }

    public boolean isKnown(String concept) {
        return concept != null && knownConcepts.contains(concept.toLowerCase(Locale.ENGLISH));
    }

    /** Records a concept seen in a filing that no field claims. */
    public void noteUnmapped(String concept) {
        if (concept == null || concept.isEmpty()) {
            return;
        }
        unmapped.computeIfAbsent(concept, k -> new AtomicLong()).incrementAndGet();
    }

    /** Unmapped concepts ranked by how often they appear, most frequent first. */
    public List<Map<String, Object>> unmappedByFrequency() {
        List<Map<String, Object>> out = new ArrayList<>();
        unmapped.entrySet().stream()
                .sorted((a, b) -> Long.compare(b.getValue().get(), a.getValue().get()))
                .forEach(e -> {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("concept", e.getKey());
                    m.put("occurrences", e.getValue().get());
                    out.add(m);
                });
        return out;
    }

    public Set<String> fields() {
        return fieldToConcepts.keySet();
    }
}
