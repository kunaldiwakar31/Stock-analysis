package com.stockscreener.ingest;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Index CSV reader.
 *
 * <p>The fixture reproduces both real quirks of the NSE file: a UTF-8 byte-order mark
 * before the first header, and header names that contain trailing spaces and newlines
 * ({@code "SYMBOL \n"}). Either one silently breaks column lookup, so both are asserted
 * rather than assumed away.
 */
class IndexCsvReaderTest {

    private static final String BOM = "﻿";

    /** Header row exactly as it appears in the downloaded file. */
    private static final String HEADER =
            "\"SYMBOL \n\",\"COMPANY NAME \n\",\"QUARTER END DATE \n\","
                    + "\"TYPE OF SUBMISSION \n\",\"AUDITED / UNAUDITED \n\","
                    + "\"CONSOLIDATED / STANDALONE \n\",\"DETAILS \n\",\"XBRL \n\","
                    + "\"BROADCAST DATE/TIME \n\",\"REVISED DATE/TIME \n\","
                    + "\"REVISION REMARKS \n\",\"EXCHANGE DISSEMINATION TIME \n\","
                    + "\"TIME TAKEN \n\"\n";

    private List<IndexRow> read(String body) throws IOException {
        String csv = BOM + HEADER + body;
        return new IndexCsvReader()
                .read(new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8)));
    }

    @Test
    @DisplayName("reads a real row through the BOM and newline-laden headers")
    void readsRealRow() throws IOException {
        List<IndexRow> rows = read(
                "\"THYROCARE\",\"Thyrocare Technologies Limited\",\"30-SEP-2025\","
                        + "\"Revision\",\"Un-Audited\",\"Standalone\","
                        + "\"https://x/INTEGRATED_FILING_INDAS_181932_iXBRL_WEB.html\","
                        + "\"https://x/INTEGRATED_FILING_INDAS_1707271_WEB.xml\",,"
                        + "\"03-AUG-2026 20:53:28\",\"Updated the denomination\","
                        + "\"03-Aug-2026 20:53:28\",\"00:00:00\"\n");

        assertEquals(1, rows.size());
        IndexRow r = rows.get(0);
        assertEquals("THYROCARE", r.symbol);
        assertEquals("Thyrocare Technologies Limited", r.companyName);
        assertEquals(LocalDate.of(2025, 9, 30), r.quarterEnd);
        assertEquals("REVISION", r.submissionType);
        assertEquals(Boolean.FALSE, r.audited);
        assertFalse(r.consolidated);
        assertTrue(r.xbrlUrl.endsWith(".xml"));
        assertNotNull(r.htmlUrl);
        assertEquals("Updated the denomination", r.revisionRemarks);
    }

    @Test
    @DisplayName("parses upper and mixed case month names")
    void parsesBothDateCasings() throws IOException {
        List<IndexRow> rows = read(
                "\"A\",\"A Ltd\",\"30-JUN-2026\",\"Original\",\"Un-Audited\",\"Consolidated\","
                        + ",\"https://x/a.xml\",\"03-Aug-2026 23:12:13\",,,,\n"
                        + "\"B\",\"B Ltd\",\"31-Mar-2026\",\"Original\",\"Audited\",\"Standalone\","
                        + ",\"https://x/b.xml\",\"28-May-2026 18:19:29\",,,,\n");

        assertEquals(2, rows.size());
        assertEquals(LocalDate.of(2026, 6, 30), rows.get(0).quarterEnd);
        assertEquals(LocalDate.of(2026, 3, 31), rows.get(1).quarterEnd);
        assertTrue(rows.get(0).consolidated);
        assertEquals(Boolean.TRUE, rows.get(1).audited);
    }

    @Test
    @DisplayName("treats Un-Audited and Unaudited alike")
    void normalisesAuditedWording() throws IOException {
        List<IndexRow> rows = read(
                "\"A\",\"A Ltd\",\"30-JUN-2026\",\"Original\",\"Unaudited\",\"Consolidated\","
                        + ",\"https://x/a.xml\",\"03-Aug-2026 23:12:13\",,,,\n");
        assertEquals(Boolean.FALSE, rows.get(0).audited);
    }

    @Test
    @DisplayName("skips rows with no symbol or nothing to download")
    void skipsUnusableRows() throws IOException {
        List<IndexRow> rows = read(
                // No XBRL link: nothing can be extracted from it.
                "\"A\",\"A Ltd\",\"30-JUN-2026\",\"Original\",\"Un-Audited\",\"Consolidated\","
                        + "\"https://x/a.html\",,\"03-Aug-2026 23:12:13\",,,,\n"
                        // No symbol: cannot be attributed to a company.
                        + ",\"B Ltd\",\"30-JUN-2026\",\"Original\",\"Un-Audited\",\"Standalone\","
                        + ",\"https://x/b.xml\",\"03-Aug-2026 23:12:13\",,,,\n");
        assertTrue(rows.isEmpty());
    }

    @Test
    @DisplayName("a revision timestamp outranks the broadcast timestamp")
    void revisionTimestampWins() throws IOException {
        List<IndexRow> rows = read(
                "\"A\",\"A Ltd\",\"30-SEP-2025\",\"Revision\",\"Un-Audited\",\"Standalone\","
                        + ",\"https://x/a.xml\",,\"03-AUG-2026 20:53:28\",\"fix\",,\n");
        IndexRow r = rows.get(0);
        assertNull(r.broadcastAt);
        assertNotNull(r.revisedAt);
        // One comparable ordering across originals and revisions.
        assertEquals(r.revisedAt, r.effectiveAt());
    }
}
