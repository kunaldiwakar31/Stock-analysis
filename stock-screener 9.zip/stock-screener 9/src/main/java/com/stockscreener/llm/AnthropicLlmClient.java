package com.stockscreener.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Anthropic Messages API implementation of {@link LlmClient}. */
@Component
public class AnthropicLlmClient implements LlmClient {

    private final HttpClient http = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private final ObjectMapper json = new ObjectMapper();

    private final String apiKey;
    private final String model;
    private final String baseUrl;

    public AnthropicLlmClient(@Value("${app.llm.api-key:}") String apiKey,
                              @Value("${app.llm.model:claude-sonnet-5}") String model,
                              @Value("${app.llm.base-url:https://api.anthropic.com/v1/messages}")
                              String baseUrl) {
        this.apiKey = apiKey;
        this.model = model;
        this.baseUrl = baseUrl;
    }

    @Override
    public String complete(String systemPrompt, String userPrompt) {
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException("app.llm.api-key is not configured");
        }
        try {
            ObjectNode body = json.createObjectNode();
            body.put("model", model);
            body.put("max_tokens", 1200);
            // Deterministic: the same financial input should not produce a different verdict
            // on a rerun, or the cached-result contract becomes a lie.
            body.put("temperature", 0);
            body.put("system", systemPrompt);
            var messages = body.putArray("messages");
            ObjectNode msg = messages.addObject();
            msg.put("role", "user");
            msg.put("content", userPrompt);

            HttpRequest req = HttpRequest.newBuilder(URI.create(baseUrl))
                    .timeout(Duration.ofSeconds(90))
                    .header("content-type", "application/json")
                    .header("x-api-key", apiKey)
                    .header("anthropic-version", "2023-06-01")
                    .POST(HttpRequest.BodyPublishers.ofString(json.writeValueAsString(body)))
                    .build();

            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) {
                throw new IllegalStateException(
                        "LLM HTTP " + resp.statusCode() + ": " + resp.body());
            }
            JsonNode root = json.readTree(resp.body());
            JsonNode content = root.path("content");
            if (content.isArray() && content.size() > 0) {
                return content.get(0).path("text").asText("");
            }
            return "";
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("LLM call interrupted", e);
        } catch (Exception e) {
            throw new IllegalStateException("LLM call failed: " + e.getMessage(), e);
        }
    }

    @Override
    public String modelName() {
        return model;
    }

    @Override
    public String providerName() {
        return "ANTHROPIC";
    }
}
