package com.stockscreener.domain.repo;

/**
 * Marker for the repository package.
 *
 * <p>Each repository lives in its own file alongside this one; this type exists only so
 * the package has javadoc attached to something.
 */
public final class Repositories {

    private Repositories() {
    }
}
