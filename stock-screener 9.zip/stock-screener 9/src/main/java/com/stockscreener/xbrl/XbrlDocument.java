package com.stockscreener.xbrl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** A parsed XBRL instance: contexts plus the facts that reference them. */
public class XbrlDocument {

    /** A reporting period. Durations have start and end; instants have only {@link #instant}. */
    public static class Context {
        public String id;
        public LocalDate start;
        public LocalDate end;
        public LocalDate instant;
        /** Non-empty when the context is dimensionally qualified, e.g. per segment. */
        public String dimensionKey = "";

        public boolean isInstant() {
            return instant != null;
        }

        /** No dimensional qualifiers: the consolidated total rather than a breakdown. */
        public boolean isPlain() {
            return dimensionKey.isEmpty();
        }

        /**
         * Number of dimensional qualifiers.
         *
         * <p>Used as a ranking signal rather than a filter. Rejecting every dimensioned
         * context outright is what made this fragile: some preparers tag the primary
         * statement on an axis (a consolidated/standalone member, say), and those filings
         * then yielded nothing at all.
         */
        public int dimensionCount() {
            if (dimensionKey.isEmpty()) {
                return 0;
            }
            int n = 1;
            for (int i = 0; i < dimensionKey.length(); i++) {
                if (dimensionKey.charAt(i) == '|') {
                    n++;
                }
            }
            return n;
        }

        /** Months covered, rounded to the nearest whole month. */
        public int months() {
            if (start == null || end == null) {
                return 0;
            }
            long days = java.time.temporal.ChronoUnit.DAYS.between(start, end) + 1;
            return (int) Math.round(days / 30.4375);
        }

        /** The period end for a duration, or the instant date. */
        public LocalDate anchor() {
            return isInstant() ? instant : end;
        }

        /** One-line form for diagnostics. */
        public String describe() {
            if (isInstant()) {
                return id + " [instant " + instant + "]"
                        + (dimensionKey.isEmpty() ? "" : " dims=" + dimensionKey);
            }
            return id + " [" + start + " .. " + end + " = " + months() + "m]"
                    + (dimensionKey.isEmpty() ? "" : " dims=" + dimensionKey);
        }
    }

    public static class Fact {
        public String concept;
        public String contextRef;
        public String unitRef;
        public String value;
    }

    public final Map<String, Context> contexts = new HashMap<>();
    public final List<Fact> facts = new ArrayList<>();

    /** Lowercased concept name to the facts that carry it, for cheap lookup. */
    private final Map<String, List<Fact>> byConcept = new HashMap<>();

    public void index() {
        byConcept.clear();
        for (Fact f : facts) {
            byConcept.computeIfAbsent(f.concept.toLowerCase(Locale.ENGLISH),
                    k -> new ArrayList<>()).add(f);
        }
    }

    public List<Fact> facts(String concept) {
        List<Fact> l = byConcept.get(concept.toLowerCase(Locale.ENGLISH));
        return l == null ? List.of() : l;
    }

    public Context context(String ref) {
        return contexts.get(ref);
    }

    /**
     * All contexts in a stable order.
     *
     * <p>{@link #contexts} is a HashMap, so iterating it directly makes selection
     * non-deterministic when two contexts tie — the same file could then parse differently
     * on different runs. Sorting by id removes that.
     */
    public List<Context> orderedContexts() {
        List<Context> out = new ArrayList<>(contexts.values());
        out.sort(Comparator.comparing(c -> c.id == null ? "" : c.id));
        return out;
    }

    /** How many facts reference each context, for diagnostics. */
    public Map<String, Integer> factCountByContext() {
        Map<String, Integer> counts = new HashMap<>();
        for (Fact f : facts) {
            counts.merge(f.contextRef, 1, Integer::sum);
        }
        return counts;
    }
}
