package com.stockscreener.metrics;

import com.stockscreener.common.FiscalCalendar;
import com.stockscreener.common.Nums;
import com.stockscreener.domain.Company;
import com.stockscreener.domain.CompanyMetrics;
import com.stockscreener.domain.DailyPrice;
import com.stockscreener.domain.Enums.Basis;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import com.stockscreener.domain.repo.CompanyMetricsRepository;
import com.stockscreener.domain.repo.CompanyRepository;
import com.stockscreener.domain.repo.DailyPriceRepository;
import com.stockscreener.domain.repo.FinancialRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Assembles {@link RatioInputs} from stored rows, runs the calculator, and writes the flat
 * {@code company_metrics} row that every screener query reads.
 *
 * <p>All the awkward period-alignment decisions live here rather than in the calculator, so
 * the calculator stays a pure function of its inputs and can be tested against a filing
 * checked by hand.
 */
@Service
public class MetricsService {

    private static final Logger log = LoggerFactory.getLogger(MetricsService.class);

    private final CompanyRepository companies;
    private final FinancialRepository financials;
    private final DailyPriceRepository prices;
    private final CompanyMetricsRepository metrics;
    private final RatioCalculator calculator = new RatioCalculator();

    /**
     * Self-reference through the Spring proxy.
     *
     * <p>Needed because {@code this.recompute(...)} from an untransacted loop would bypass
     * the proxy and silently lose {@code @Transactional} entirely.
     */
    private final ObjectProvider<MetricsService> self;

    public MetricsService(CompanyRepository companies, FinancialRepository financials,
                          DailyPriceRepository prices, CompanyMetricsRepository metrics,
                          ObjectProvider<MetricsService> self) {
        this.companies = companies;
        this.financials = financials;
        this.prices = prices;
        this.metrics = metrics;
        this.self = self;
    }

    /** Recomputes every company that has at least one stored period. */
    public int recomputeAll() {
        List<Long> ids = financials.findCompanyIdsWithData();
        MetricsService proxy = self.getObject();
        int done = 0;
        for (Long id : ids) {
            try {
                // One transaction per company: a single bad row must not roll back the rest.
                proxy.recompute(id);
                done++;
            } catch (Exception e) {
                log.warn("Metrics for company {} failed: {}", id, e.toString());
            }
        }
        return done;
    }

    @Transactional
    public Optional<CompanyMetrics> recompute(Long companyId) {
        Company company = companies.findById(companyId).orElse(null);
        if (company == null) {
            return Optional.empty();
        }

        // Prefer consolidated: standalone accounts hide subsidiary debt and losses.
        // The basis is only switched when the other one actually has rows, so a company
        // filing consolidated annuals but no clean quarters isn't stranded on standalone.
        Basis basis = Basis.CONSOLIDATED;
        List<Financial> quarters = quarterRows(companyId, true);
        List<Financial> annuals =
                financials.findSeriesForBasis(companyId, PeriodType.FY, true);

        if (quarters.isEmpty() && annuals.isEmpty()) {
            quarters = quarterRows(companyId, false);
            annuals = financials.findSeriesForBasis(companyId, PeriodType.FY, false);
            basis = Basis.STANDALONE;
        }
        boolean consolidated = basis == Basis.CONSOLIDATED;

        if (quarters.isEmpty() && annuals.isEmpty()) {
            return Optional.empty();
        }

        RatioInputs in = new RatioInputs();
        in.financialCompany = company.isFinancialCo();
        in.sharesOutstanding = company.getSharesOutstanding();

        LocalDate asOf = buildFlows(in, quarters, annuals);
        attachBalanceSheet(in, companyId, consolidated);
        attachCashFlow(in, annuals);
        attachAnnualSeries(in, annuals);
        attachQuarterYoy(in, quarters);
        attachPrices(in, companyId);

        RatioOutputs out = calculator.compute(in);

        CompanyMetrics m = metrics.findById(companyId).orElseGet(CompanyMetrics::new);
        m.setCompanyId(companyId);
        // Profile fields are copied in rather than joined; see CompanyMetrics.
        m.setSymbol(company.getSymbol());
        m.setCompanyName(company.getCompanyName());
        m.setSector(company.getSector());
        m.setFinancialCo(company.isFinancialCo());
        m.setAsOfDate(asOf != null ? asOf : LocalDate.now());
        m.setBasis(basis.name());
        copy(out, m);
        metrics.save(m);
        return Optional.of(m);
    }

    // ------------------------------------------------------------------

    /** Three-month quarters only, newest first. */
    private List<Financial> quarterRows(Long companyId, boolean consolidated) {
        List<Financial> all =
                financials.findSeriesForBasis(companyId, PeriodType.Q, consolidated);
        List<Financial> out = new ArrayList<>();
        for (Financial f : all) {
            if (f.getMonthsCovered() != null && f.getMonthsCovered() == 3) {
                out.add(f);
            }
        }
        return out;
    }

    /**
     * Sums the trailing window.
     *
     * <p>Takes the newest run of consecutive quarters, up to four. Stopping at the first
     * gap matters: summing Q1 with Q3 and calling it a half-year would quietly invent
     * revenue that was never reported.
     */
    private LocalDate buildFlows(RatioInputs in, List<Financial> quarters,
                                 List<Financial> annuals) {
        if (quarters.isEmpty()) {
            // Fall back to the latest full year when no clean quarters exist.
            if (annuals.isEmpty()) {
                return null;
            }
            Financial fy = annuals.get(0);
            in.windowMonths = 12;
            in.quartersUsed = 0;
            in.revenue = fy.getRevenue();
            in.otherIncome = fy.getOtherIncome();
            in.ebitda = fy.getOperatingProfit();
            in.depreciation = fy.getDepreciation();
            in.financeCosts = fy.getFinanceCosts();
            in.profitBeforeTax = fy.getProfitBeforeTax();
            in.taxExpense = fy.getTaxExpense();
            in.netProfit = fy.getNetProfit();
            in.reportedEpsSum = fy.getEps();
            return fy.getPeriodEnd();
        }

        List<Financial> run = new ArrayList<>();
        run.add(quarters.get(0));
        for (int i = 1; i < quarters.size() && run.size() < 4; i++) {
            LocalDate expected =
                    FiscalCalendar.previousQuarterEnd(run.get(run.size() - 1).getPeriodEnd());
            if (quarters.get(i).getPeriodEnd().equals(expected)) {
                run.add(quarters.get(i));
            } else {
                break;
            }
        }

        in.quartersUsed = run.size();
        in.windowMonths = run.size() * 3;
        for (Financial f : run) {
            in.revenue = Nums.addLenient(in.revenue, f.getRevenue());
            in.otherIncome = Nums.addLenient(in.otherIncome, f.getOtherIncome());
            in.ebitda = Nums.addLenient(in.ebitda, f.getOperatingProfit());
            in.depreciation = Nums.addLenient(in.depreciation, f.getDepreciation());
            in.financeCosts = Nums.addLenient(in.financeCosts, f.getFinanceCosts());
            in.profitBeforeTax = Nums.addLenient(in.profitBeforeTax, f.getProfitBeforeTax());
            in.taxExpense = Nums.addLenient(in.taxExpense, f.getTaxExpense());
            in.netProfit = Nums.addLenient(in.netProfit, f.getNetProfit());
            in.reportedEpsSum = Nums.addLenient(in.reportedEpsSum, f.getEps());
        }
        return run.get(0).getPeriodEnd();
    }

    /**
     * Latest balance sheet plus the one before it, for averaged denominators.
     *
     * <p>Searched across both quarterly and annual rows because SEBI requires the statement
     * of assets and liabilities only half-yearly, so most quarters simply do not carry one.
     */
    private void attachBalanceSheet(RatioInputs in, Long companyId, boolean consolidated) {
        List<Financial> withBs = new ArrayList<>();
        for (Financial f : financials.findSeriesForBasis(companyId, PeriodType.Q, consolidated)) {
            if (f.getTotalEquity() != null || f.getTotalAssets() != null) {
                withBs.add(f);
            }
        }
        for (Financial f : financials.findSeriesForBasis(companyId, PeriodType.FY, consolidated)) {
            if (f.getTotalEquity() != null || f.getTotalAssets() != null) {
                withBs.add(f);
            }
        }
        withBs.sort((a, b) -> b.getPeriodEnd().compareTo(a.getPeriodEnd()));
        if (withBs.isEmpty()) {
            return;
        }

        Financial latest = withBs.get(0);
        in.totalEquity = latest.getTotalEquity();
        in.totalBorrowings = latest.getTotalBorrowings();
        in.cashAndInvestments = latest.getCashAndInvestments();
        in.totalAssets = latest.getTotalAssets();

        for (int i = 1; i < withBs.size(); i++) {
            Financial prev = withBs.get(i);
            if (prev.getPeriodEnd().equals(latest.getPeriodEnd())) {
                continue;
            }
            in.prevTotalEquity = prev.getTotalEquity();
            in.prevTotalAssets = prev.getTotalAssets();
            break;
        }

        // The trailing profit window is what gets divided by these stocks.
        in.balanceSheetWindowMonths = in.windowMonths;
    }

    /**
     * Cash flow from the latest full year.
     *
     * <p>Deliberately annual. The cash flow statement is filed half-yearly at best, and
     * pairing a six-month operating cash flow with a twelve-month profit would make OCF/PAT
     * read as roughly half its real value — a metric that wrong is worse than absent.
     */
    private void attachCashFlow(RatioInputs in, List<Financial> annuals) {
        for (Financial fy : annuals) {
            if (fy.getCashFromOperations() != null) {
                in.cashFromOperations = fy.getCashFromOperations();
                in.capex = fy.getCapex();
                in.dividendsPaid = fy.getDividendsPaid();
                return;
            }
        }
    }

    private void attachAnnualSeries(RatioInputs in, List<Financial> annuals) {
        for (Financial fy : annuals) {
            int year = FiscalCalendar.fiscalYear(fy.getPeriodEnd());
            if (fy.getRevenue() != null) {
                in.annualRevenue.put(year, fy.getRevenue());
            }
            if (fy.getNetProfit() != null) {
                in.annualNetProfit.put(year, fy.getNetProfit());
            }
            if (fy.getEps() != null) {
                in.annualEps.put(year, fy.getEps());
            }
        }
    }

    /** Same quarter one year earlier, which is the only valid base for a seasonal business. */
    private void attachQuarterYoy(RatioInputs in, List<Financial> quarters) {
        if (quarters.isEmpty()) {
            return;
        }
        Financial latest = quarters.get(0);
        in.latestQuarterRevenue = latest.getRevenue();
        in.latestQuarterNetProfit = latest.getNetProfit();

        LocalDate target = FiscalCalendar.sameQuarterLastYear(latest.getPeriodEnd());
        for (Financial f : quarters) {
            if (f.getPeriodEnd().equals(target)) {
                in.yearAgoQuarterRevenue = f.getRevenue();
                in.yearAgoQuarterNetProfit = f.getNetProfit();
                return;
            }
        }
    }

    private void attachPrices(RatioInputs in, Long companyId) {
        Optional<DailyPrice> latest = prices.findFirstByCompanyIdOrderByTradeDateDesc(companyId);
        if (latest.isEmpty()) {
            return;
        }
        in.currentPrice = latest.get().getClosePrice();
        LocalDate from = latest.get().getTradeDate().minusDays(365);
        in.high52w = prices.findHigh(companyId, from);
        in.low52w = prices.findLow(companyId, from);
    }

    // ------------------------------------------------------------------

    private void copy(RatioOutputs o, CompanyMetrics m) {
        m.setCurrentPrice(o.currentPrice);
        m.setMarketCapCr(scale(o.marketCapCr, 2));
        m.setHigh52w(o.high52w);
        m.setLow52w(o.low52w);
        m.setPctFromHigh(scale(o.pctFromHigh, 4));

        m.setPeRatio(scale(o.peRatio, 4));
        m.setPbRatio(scale(o.pbRatio, 4));
        m.setBookValue(scale(o.bookValue, 4));
        m.setEvToEbitda(scale(o.evToEbitda, 4));
        m.setDividendYieldPct(scale(o.dividendYieldPct, 4));
        m.setEarningsYieldPct(scale(o.earningsYieldPct, 4));

        m.setRoePct(scale(o.roePct, 4));
        m.setRocePct(scale(o.rocePct, 4));
        m.setRoaPct(scale(o.roaPct, 4));

        m.setOperatingMarginPct(scale(o.operatingMarginPct, 4));
        m.setNetProfitMarginPct(scale(o.netProfitMarginPct, 4));

        m.setDebtToEquity(scale(o.debtToEquity, 4));
        m.setInterestCoverage(scale(o.interestCoverage, 4));

        m.setSalesTtmCr(scale(o.salesTtmCr, 2));
        m.setEbitdaTtmCr(scale(o.ebitdaTtmCr, 2));
        m.setNetProfitTtmCr(scale(o.netProfitTtmCr, 2));
        m.setEpsTtm(scale(o.epsTtm, 4));
        m.setCfoTtmCr(scale(o.cfoTtmCr, 2));
        m.setFcfTtmCr(scale(o.fcfTtmCr, 2));
        m.setOcfToNetProfit(scale(o.ocfToNetProfit, 4));

        m.setSalesGrowth1yPct(scale(o.salesGrowth1yPct, 4));
        m.setSalesGrowth2yPct(scale(o.salesGrowth2yPct, 4));
        m.setSalesGrowth3yPct(scale(o.salesGrowth3yPct, 4));
        m.setSalesGrowth5yPct(scale(o.salesGrowth5yPct, 4));
        m.setProfitGrowth1yPct(scale(o.profitGrowth1yPct, 4));
        m.setProfitGrowth2yPct(scale(o.profitGrowth2yPct, 4));
        m.setProfitGrowth3yPct(scale(o.profitGrowth3yPct, 4));
        m.setProfitGrowth5yPct(scale(o.profitGrowth5yPct, 4));
        m.setEpsGrowth3yPct(scale(o.epsGrowth3yPct, 4));

        m.setQtrSalesYoyPct(scale(o.qtrSalesYoyPct, 4));
        m.setQtrProfitYoyPct(scale(o.qtrProfitYoyPct, 4));

        m.setDataCompletenessPct(scale(o.dataCompletenessPct, 2));
        m.setWarnings(toJsonArray(o.warnings));
    }

    private BigDecimal scale(BigDecimal v, int places) {
        return Nums.scale(v, places);
    }

    static String toJsonArray(List<String> items) {
        if (items == null || items.isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(items.get(i).replace("\"", "'")).append('"');
        }
        return sb.append(']').toString();
    }
}
