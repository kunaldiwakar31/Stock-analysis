package com.stockscreener.technicals;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * One day of OHLCV plus delivery percentage — exactly what {@link TechnicalIndicatorCalculator}
 * needs, and nothing tied to JPA. Kept separate from {@link com.stockscreener.domain.DailyPrice}
 * for the same reason {@code RatioInputs} is separate from {@code Financial}: the calculator
 * stays a pure function that a hand-built series can exercise, with no entity or database in
 * the way.
 *
 * @param date         trade date, ascending order is the caller's responsibility
 * @param close        required — every indicator here is close-based except ATR and Bollinger
 * @param high         used only by ATR
 * @param low          used only by ATR
 * @param volume       used only by the volume SMA
 * @param deliveryPct  passed through unchanged into the result row; not computed here
 */
public record PricePoint(LocalDate date, BigDecimal close, BigDecimal high, BigDecimal low,
                         Long volume, BigDecimal deliveryPct) {
}
