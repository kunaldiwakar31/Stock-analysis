package com.stockscreener.screener;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Recursive-descent parser for the screener query language.
 *
 * <pre>
 * query      := orExpr
 * orExpr     := andExpr ( ("OR" | "||") andExpr )*
 * andExpr    := notExpr ( ("AND" | "&amp;&amp;" | ",") notExpr )*
 * notExpr    := "NOT"? primary
 * primary    := "(" orExpr ")" | comparison
 * comparison := metric op value
 *             | metric "BETWEEN" value "AND" value
 *             | metric "IN" "(" value ("," value)* ")"
 *             | metric "IS" "NOT"? "NULL"
 * op         := "&gt;" | "&gt;=" | "&lt;" | "&lt;=" | "=" | "!=" | "~"
 * </pre>
 *
 * <p>Comma binds as AND so the Screener-style shorthand
 * {@code roe > 18%, roce > 20%, marketcap > 1000cr} works without extra typing.
 *
 * <p>Hand-written rather than generated: the grammar is small enough that a parser
 * generator would add a build step and a dependency without buying anything.
 */
public class QueryParser {

    private final List<Token> tokens;
    private final String source;
    private int pos;
    private final int maxPredicates;
    private int predicateCount;

    public QueryParser(String source) {
        this(source, 20);
    }

    public QueryParser(String source, int maxPredicates) {
        this.source = source == null ? "" : source;
        this.tokens = new Lexer(this.source).tokenize();
        this.maxPredicates = maxPredicates;
    }

    public Ast.Node parse() {
        if (peek().is(Token.Type.EOF)) {
            throw new QueryException("EMPTY_QUERY", 0, "", "Query is empty");
        }
        Ast.Node n = orExpr();
        if (!peek().is(Token.Type.EOF)) {
            Token t = peek();
            throw new QueryException("UNEXPECTED_TOKEN", t.position, t.text,
                    "Unexpected '" + t.text + "'");
        }
        return n;
    }

    // ---- grammar ----

    private Ast.Node orExpr() {
        List<Ast.Node> parts = new ArrayList<>();
        parts.add(andExpr());
        while (peek().is(Token.Type.OR)) {
            next();
            parts.add(andExpr());
        }
        return parts.size() == 1 ? parts.get(0) : new Ast.Or(parts);
    }

    private Ast.Node andExpr() {
        List<Ast.Node> parts = new ArrayList<>();
        parts.add(notExpr());
        while (peek().is(Token.Type.AND) || peek().is(Token.Type.COMMA)) {
            next();
            parts.add(notExpr());
        }
        return parts.size() == 1 ? parts.get(0) : new Ast.And(parts);
    }

    private Ast.Node notExpr() {
        if (peek().is(Token.Type.NOT)) {
            next();
            return new Ast.Not(notExpr());
        }
        return primary();
    }

    private Ast.Node primary() {
        if (peek().is(Token.Type.LPAREN)) {
            next();
            Ast.Node inner = orExpr();
            expect(Token.Type.RPAREN, ")");
            return inner;
        }
        return comparison();
    }

    private Ast.Node comparison() {
        Token nameTok = peek();
        if (!nameTok.is(Token.Type.IDENT)) {
            throw new QueryException("EXPECTED_METRIC", nameTok.position, nameTok.text,
                    "Expected a metric name but found '" + nameTok.text + "'");
        }
        next();
        MetricDef metric = MetricRegistry.resolve(nameTok.text, nameTok.position);
        countPredicate(nameTok.position);

        if (peek().is(Token.Type.BETWEEN)) {
            next();
            NormalizedValue lo = numericValue(metric);
            expect(Token.Type.AND, "AND");
            NormalizedValue hi = numericValue(metric);
            if (lo.value.compareTo(hi.value) > 0) {
                throw new QueryException("BAD_RANGE", nameTok.position, nameTok.text,
                        "BETWEEN lower bound is greater than the upper bound");
            }
            return new Ast.Between(metric, lo, hi, nameTok.position);
        }

        if (peek().is(Token.Type.IN)) {
            next();
            expect(Token.Type.LPAREN, "(");
            List<Object> vals = new ArrayList<>();
            while (true) {
                vals.add(anyValue(metric));
                if (peek().is(Token.Type.COMMA)) {
                    next();
                    continue;
                }
                break;
            }
            expect(Token.Type.RPAREN, ")");
            return new Ast.In(metric, vals, nameTok.position);
        }

        if (peek().is(Token.Type.IS)) {
            next();
            boolean negated = false;
            if (peek().is(Token.Type.NOT)) {
                next();
                negated = true;
            }
            expect(Token.Type.NULL, "NULL");
            return new Ast.IsNull(metric, negated, nameTok.position);
        }

        Token opTok = peek();
        if (!opTok.is(Token.Type.OP)) {
            throw new QueryException("EXPECTED_OPERATOR", opTok.position, opTok.text,
                    "Expected a comparison operator after '" + nameTok.text + "'");
        }
        next();
        String op = opTok.text;

        if ("~".equals(op)) {
            if (metric.unit() != Unit.TEXT) {
                throw new QueryException("TYPE_MISMATCH", opTok.position, op,
                        "'~' (contains) only applies to text metrics like symbol, name, sector");
            }
            Object v = anyValue(metric);
            return new Ast.Cmp(metric, "~", v, null, nameTok.position);
        }

        if (metric.isNumeric()) {
            NormalizedValue nv = numericValue(metric);
            return new Ast.Cmp(metric, op, nv.value, nv, nameTok.position);
        }

        if (!"=".equals(op) && !"!=".equals(op)) {
            throw new QueryException("TYPE_MISMATCH", opTok.position, op,
                    "Metric '" + metric.key() + "' supports only '=', '!=', 'IN' and '~'");
        }
        Object v = anyValue(metric);
        return new Ast.Cmp(metric, op, v, null, nameTok.position);
    }

    // ---- values ----

    private NormalizedValue numericValue(MetricDef metric) {
        Token t = peek();
        if (!t.is(Token.Type.NUMBER)) {
            throw new QueryException("EXPECTED_NUMBER", t.position, t.text,
                    "Expected a number for '" + metric.key() + "' but found '" + t.text + "'");
        }
        next();
        return ValueNormalizer.normalize(metric, t);
    }

    private Object anyValue(MetricDef metric) {
        Token t = peek();
        if (t.is(Token.Type.NUMBER)) {
            next();
            if (metric.isNumeric()) {
                return ValueNormalizer.normalize(metric, t).value;
            }
            return new BigDecimal(t.text);
        }
        if (t.is(Token.Type.STRING) || t.is(Token.Type.IDENT)) {
            next();
            return t.text;
        }
        if (t.is(Token.Type.BOOL)) {
            next();
            return Boolean.valueOf("true".equalsIgnoreCase(t.text));
        }
        throw new QueryException("EXPECTED_VALUE", t.position, t.text,
                "Expected a value for '" + metric.key() + "'");
    }

    // ---- plumbing ----

    private void countPredicate(int position) {
        predicateCount++;
        if (predicateCount > maxPredicates) {
            throw new QueryException("TOO_MANY_PREDICATES", position, "",
                    "Query has more than " + maxPredicates + " conditions");
        }
    }

    private Token peek() {
        return tokens.get(pos);
    }

    private Token next() {
        return tokens.get(pos++);
    }

    private void expect(Token.Type type, String what) {
        Token t = peek();
        if (!t.is(type)) {
            throw new QueryException("EXPECTED_TOKEN", t.position, t.text,
                    "Expected '" + what + "' but found '"
                            + (t.is(Token.Type.EOF) ? "end of query" : t.text) + "'");
        }
        next();
    }

    public String source() {
        return source;
    }
}
