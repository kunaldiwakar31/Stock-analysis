package com.stockscreener.prices;

import com.stockscreener.domain.Company;
import com.stockscreener.domain.DailyPrice;
import com.stockscreener.domain.repo.CompanyRepository;
import com.stockscreener.domain.repo.DailyPriceRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

/**
 * Loads the NSE daily bhavcopy into {@code daily_prices}.
 *
 * <p>Small job, large payoff. The filings contain no market data at all, so without this
 * ten metrics are permanently null: market cap, price, 52-week high and low, distance from
 * high, P/E, P/B, EV/EBITDA, dividend yield and earnings yield. Since the share count is
 * already derived from the filing's paid-up capital and face value, a single close price
 * per symbol unlocks the entire valuation family.
 *
 * <p>Column names differ between the legacy and current bhavcopy formats, so headers are
 * matched by a list of candidates rather than a fixed position.
 */
@Service
public class BhavcopyLoader {

    private static final Logger log = LoggerFactory.getLogger(BhavcopyLoader.class);

    private static final String[] SYMBOL_COLS = {"SYMBOL", "TCKRSYMB"};
    private static final String[] SERIES_COLS = {"SERIES", "SCTYSRS"};
    private static final String[] CLOSE_COLS = {"CLOSE", "CLSPRIC", "LAST_PRICE"};
    private static final String[] HIGH_COLS = {"HIGH", "HGHPRIC"};
    private static final String[] LOW_COLS = {"LOW", "LWPRIC"};
    private static final String[] VOLUME_COLS = {"TOTTRDQTY", "TTLTRADGVOL", "VOLUME"};
    // Delivery data is best-effort: present in the legacy "full bhavcopy" report and in
    // some UDiFF variants, absent from others. Missing means null, not zero.
    private static final String[] DELIV_QTY_COLS = {"DELIV_QTY", "DELIVQTY", "DELIVERYQTY"};
    private static final String[] DELIV_PER_COLS = {"DELIV_PER", "DELIVPER", "DELIVERYPCT"};

    private final CompanyRepository companies;
    private final DailyPriceRepository prices;

    public BhavcopyLoader(CompanyRepository companies, DailyPriceRepository prices) {
        this.companies = companies;
        this.prices = prices;
    }

    public static class LoadSummary {
        public int rowsRead;
        public int saved;
        public int unknownSymbols;
        public int skippedNonEquity;
    }

    @Transactional
    public LoadSummary load(InputStream csv, LocalDate tradeDate) throws IOException {
        LoadSummary s = new LoadSummary();

        Map<String, Company> bySymbol = new HashMap<>();
        for (Company c : companies.findAll()) {
            // Uppercased on both sides, or a stored lower-case symbol never matches.
            bySymbol.put(c.getSymbol().toUpperCase(Locale.ENGLISH), c);
        }

        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(csv, StandardCharsets.UTF_8))) {

            CSVFormat fmt = CSVFormat.DEFAULT.builder()
                    .setHeader()
                    .setSkipHeaderRecord(true)
                    .setIgnoreSurroundingSpaces(true)
                    .setIgnoreEmptyLines(true)
                    // The legacy bhavcopy ends each line with a trailing comma, producing an
                    // empty final header. Without this the parser throws before reading a row.
                    .setAllowMissingColumnNames(true)
                    .build();

            try (CSVParser p = new CSVParser(r, fmt)) {
                Map<String, Integer> headers = new HashMap<>();
                for (Map.Entry<String, Integer> e : p.getHeaderMap().entrySet()) {
                    headers.put(e.getKey().trim().toUpperCase(Locale.ENGLISH), e.getValue());
                }

                for (CSVRecord rec : p) {
                    s.rowsRead++;

                    String series = first(rec, headers, SERIES_COLS);
                    if (series != null && !series.trim().isEmpty()
                            && !"EQ".equalsIgnoreCase(series.trim())
                            && !"BE".equalsIgnoreCase(series.trim())) {
                        // Only ordinary equity series. Debt and ETF rows would otherwise
                        // overwrite a company's price with an unrelated instrument.
                        s.skippedNonEquity++;
                        continue;
                    }

                    String symbol = first(rec, headers, SYMBOL_COLS);
                    if (symbol == null) {
                        continue;
                    }
                    Company c = bySymbol.get(symbol.trim().toUpperCase(Locale.ENGLISH));
                    if (c == null) {
                        s.unknownSymbols++;
                        continue;
                    }

                    BigDecimal close = decimal(first(rec, headers, CLOSE_COLS));
                    if (close == null || close.signum() <= 0) {
                        continue;
                    }

                    DailyPrice dp = prices
                            .findByCompanyIdAndTradeDate(c.getId(), tradeDate)
                            .orElseGet(DailyPrice::new);
                    dp.setCompanyId(c.getId());
                    dp.setTradeDate(tradeDate);
                    dp.setClosePrice(close);
                    dp.setHighPrice(decimal(first(rec, headers, HIGH_COLS)));
                    dp.setLowPrice(decimal(first(rec, headers, LOW_COLS)));
                    dp.setVolume(longValue(first(rec, headers, VOLUME_COLS)));
                    dp.setDeliveryQty(longValue(first(rec, headers, DELIV_QTY_COLS)));
                    dp.setDeliveryPct(decimal(first(rec, headers, DELIV_PER_COLS)));
                    prices.save(dp);
                    s.saved++;
                }
            }
        }
        log.info("Bhavcopy {}: {} rows, {} saved, {} unknown symbols",
                tradeDate, s.rowsRead, s.saved, s.unknownSymbols);
        return s;
    }

    /** Retention: only the trailing 52-week window plus a margin is useful. */
    @Transactional
    public int prune(LocalDate before) {
        return prices.deleteOlderThan(before);
    }

    public Optional<DailyPrice> latest(Long companyId) {
        return prices.findFirstByCompanyIdOrderByTradeDateDesc(companyId);
    }

    // ------------------------------------------------------------------

    private String first(CSVRecord rec, Map<String, Integer> headers, String[] candidates) {
        for (String name : candidates) {
            Integer idx = headers.get(name);
            if (idx != null && idx < rec.size()) {
                return rec.get(idx);
            }
        }
        return null;
    }

    private BigDecimal decimal(String s) {
        if (s == null) {
            return null;
        }
        String v = s.trim().replace(",", "");
        if (v.isEmpty() || "-".equals(v)) {
            return null;
        }
        try {
            return new BigDecimal(v);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private Long longValue(String s) {
        BigDecimal d = decimal(s);
        return d == null ? null : d.longValue();
    }
}
