-- Audit trail for share-count jumps large enough to break historical EPS comparability.
-- One row per detected jump, whatever was concluded about it (restated, left alone, or
-- rejected as an implausible/scale-bug value) - see ShareCountChangeClassifier and
-- CorporateActionService.

CREATE TABLE corporate_actions (
  id                    BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id            BIGINT UNSIGNED NOT NULL,
  symbol                VARCHAR(30) NULL,
  effective_period_end  DATE NOT NULL,
  source_url            VARCHAR(700) NULL,

  shares_before         DECIMAL(24,4) NULL,
  shares_after          DECIMAL(24,4) NULL,
  ratio                 DECIMAL(14,6) NULL,

  action_type           VARCHAR(20) NOT NULL,   -- SPLIT | BONUS | MINOR_CHANGE | IMPLAUSIBLE
  applied_restatement   BOOLEAN NOT NULL DEFAULT FALSE,
  rows_restated         INT NULL,
  note                  VARCHAR(60) NULL,

  created_at            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY idx_ca_company (company_id, effective_period_end DESC),
  CONSTRAINT fk_ca_company FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;
