package com.stockscreener.ingest;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Reads the NSE integrated-filing index CSV.
 *
 * <p>Two quirks in the real file that this handles explicitly:
 * <ol>
 *   <li>A UTF-8 byte-order mark before the first header, which otherwise becomes part of
 *       the {@code SYMBOL} header name and makes every lookup miss.</li>
 *   <li>Header names containing trailing newlines and spaces, literally {@code "SYMBOL \n"}.
 *       Headers are therefore normalised before mapping rather than matched verbatim.</li>
 * </ol>
 */
public class IndexCsvReader {

    /** Dates arrive as either 04-Aug-2026 or 04-AUG-2026, so month parsing is case-insensitive. */
    private static final DateTimeFormatter DATE = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .appendPattern("dd-MMM-yyyy")
            .toFormatter(Locale.ENGLISH);

    private static final DateTimeFormatter DATE_TIME = new DateTimeFormatterBuilder()
            .parseCaseInsensitive()
            .appendPattern("dd-MMM-yyyy HH:mm:ss")
            .toFormatter(Locale.ENGLISH);

    private static final DateTimeFormatter ISO_DATE_TIME = new DateTimeFormatterBuilder()
            .appendPattern("yyyy-MM-dd HH:mm:ss")
            .toFormatter(Locale.ENGLISH);

    public List<IndexRow> read(InputStream in) throws IOException {
        List<IndexRow> rows = new ArrayList<>();
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(stripBom(in), StandardCharsets.UTF_8))) {

            CSVFormat fmt = CSVFormat.DEFAULT.builder()
                    .setHeader()
                    .setSkipHeaderRecord(true)
                    .setIgnoreSurroundingSpaces(true)
                    .setIgnoreEmptyLines(true)
                    // NSE exports sometimes carry a trailing comma, yielding an unnamed
                    // final column. Tolerated rather than treated as a fatal header error.
                    .setAllowMissingColumnNames(true)
                    .build();

            try (CSVParser p = new CSVParser(r, fmt)) {
                Map<String, Integer> headers = normalisedHeaders(p.getHeaderMap());
                for (CSVRecord rec : p) {
                    IndexRow row = map(rec, headers);
                    if (row != null) {
                        rows.add(row);
                    }
                }
            }
        }
        return rows;
    }

    /** Maps a cleaned header name to its column index. */
    private Map<String, Integer> normalisedHeaders(Map<String, Integer> raw) {
        Map<String, Integer> out = new java.util.HashMap<>();
        for (Map.Entry<String, Integer> e : raw.entrySet()) {
            out.put(clean(e.getKey()), e.getValue());
        }
        return out;
    }

    private String clean(String h) {
        if (h == null) {
            return "";
        }
        return h.replace("﻿", "")
                .replaceAll("\\s+", " ")
                .trim()
                .toUpperCase(Locale.ENGLISH);
    }

    private IndexRow map(CSVRecord rec, Map<String, Integer> h) {
        String symbol = get(rec, h, "SYMBOL");
        String xbrl = get(rec, h, "XBRL");
        String qEnd = get(rec, h, "QUARTER END DATE");
        if (isBlank(symbol) || isBlank(xbrl) || isBlank(qEnd)) {
            // No identifier or nothing to download: nothing useful can be done with it.
            return null;
        }

        IndexRow row = new IndexRow();
        row.symbol = symbol.trim().toUpperCase(Locale.ENGLISH);
        row.companyName = get(rec, h, "COMPANY NAME");
        row.quarterEnd = LocalDate.parse(qEnd.trim(), DATE);
        row.submissionType = "Revision".equalsIgnoreCase(nz(get(rec, h, "TYPE OF SUBMISSION")))
                ? "REVISION" : "ORIGINAL";

        String aud = nz(get(rec, h, "AUDITED / UNAUDITED"));
        if (!aud.isEmpty()) {
            // "Un-Audited" and "Unaudited" both appear in the wild.
            row.audited = aud.toLowerCase(Locale.ENGLISH).replace("-", "").startsWith("un")
                    ? Boolean.FALSE : Boolean.TRUE;
        }

        row.consolidated = "Consolidated".equalsIgnoreCase(
                nz(get(rec, h, "CONSOLIDATED / STANDALONE")));
        row.htmlUrl = trimToNull(get(rec, h, "DETAILS"));
        row.xbrlUrl = xbrl.trim();
        row.broadcastAt = parseDateTime(get(rec, h, "BROADCAST DATE/TIME"));
        row.revisedAt = parseDateTime(get(rec, h, "REVISED DATE/TIME"));
        row.revisionRemarks = trimToNull(get(rec, h, "REVISION REMARKS"));
        return row;
    }

    private LocalDateTime parseDateTime(String s) {
        String v = nz(s).trim();
        if (v.isEmpty()) {
            return null;
        }
        try {
            return LocalDateTime.parse(v, DATE_TIME);
        } catch (RuntimeException ignored) {
            // The RECEIPT column uses ISO form; tolerate it wherever it turns up.
        }
        try {
            return LocalDateTime.parse(v, ISO_DATE_TIME);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private String get(CSVRecord rec, Map<String, Integer> h, String name) {
        Integer idx = h.get(name);
        if (idx == null || idx >= rec.size()) {
            return null;
        }
        return rec.get(idx);
    }

    private static InputStream stripBom(InputStream in) throws IOException {
        java.io.PushbackInputStream pb = new java.io.PushbackInputStream(in, 3);
        byte[] bom = new byte[3];
        int read = pb.read(bom, 0, 3);
        if (read == 3 && (bom[0] & 0xFF) == 0xEF && (bom[1] & 0xFF) == 0xBB
                && (bom[2] & 0xFF) == 0xBF) {
            return pb;
        }
        if (read > 0) {
            pb.unread(bom, 0, read);
        }
        return pb;
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }

    private static String trimToNull(String s) {
        if (isBlank(s)) {
            return null;
        }
        return s.trim();
    }
}
