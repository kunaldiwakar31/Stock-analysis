package com.stockscreener.api;

import com.stockscreener.screener.QueryException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Turns query and ingestion failures into responses the caller can act on.
 *
 * <p>A bad query returns 400 with the offending character position and the nearest valid
 * metric names, never an empty result set. A screener that silently matches nothing when
 * someone types {@code roec} instead of {@code roce} trains users to distrust it.
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(QueryException.class)
    public ResponseEntity<Map<String, Object>> onQueryError(QueryException e) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("error", e.getCode());
        body.put("message", e.getMessage());
        body.put("position", e.getPosition());
        body.put("token", e.getToken());
        if (!e.getSuggestions().isEmpty()) {
            body.put("suggestions", e.getSuggestions());
        }
        return ResponseEntity.badRequest().body(body);
    }

    /**
     * Notably raised when a filing declares no rounding level.
     *
     * <p>That case is a deliberate hard failure: guessing the scale risks a hundredfold
     * error in every figure from that filing, which is the worst outcome this system can
     * produce.
     */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> onBadArgument(IllegalArgumentException e) {
        return ResponseEntity.badRequest().body(Map.of(
                "error", "BAD_REQUEST",
                "message", String.valueOf(e.getMessage())));
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<Map<String, Object>> onBadState(IllegalStateException e) {
        log.warn("Request failed: {}", e.getMessage());
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
                "error", "CONFLICT",
                "message", String.valueOf(e.getMessage())));
    }
}
