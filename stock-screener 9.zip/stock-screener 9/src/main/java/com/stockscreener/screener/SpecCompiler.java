package com.stockscreener.screener;

import com.stockscreener.domain.CompanyMetrics;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Expression;
import jakarta.persistence.criteria.Path;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Compiles a parsed query into a JPA {@link Specification}.
 *
 * <p>No SQL text is ever assembled. Column references come from the metric whitelist and
 * literals become bound Criteria parameters, so injection is structurally impossible
 * rather than filtered for.
 *
 * <p><b>NULL semantics.</b> Comparisons deliberately exclude nulls: a company with no
 * computable ROE must not satisfy {@code roe > 18}. SQL three-valued logic already does
 * this, but the consequence worth stating is that {@code NOT (roe > 18)} excludes it too.
 * That is intentional — with balance sheets filed half-yearly, plenty of cells are
 * legitimately empty, and quietly treating "unknown" as "fails the filter" is the only
 * defensible reading.
 */
public class SpecCompiler {

    /** Metric keys that are meaningless for banks and NBFCs. */
    private static final List<String> FINANCIAL_CO_INAPPLICABLE =
            List.of("roce", "de", "ev_ebitda");

    private final boolean strict;
    private final boolean includeFinancials;

    public SpecCompiler(boolean strict, boolean includeFinancials) {
        this.strict = strict;
        this.includeFinancials = includeFinancials;
    }

    public Specification<CompanyMetrics> compile(Ast.Node root) {
        return (rt, q, cb) -> {
            List<Predicate> all = new ArrayList<>();
            all.add(build(root, rt, cb));

            if (!includeFinancials && touchesFinancialCoInapplicable(root)) {
                // Emitting a debt/equity ranking that mixes banks with manufacturers is
                // worse than excluding them, so they are dropped unless asked for.
                all.add(cb.isFalse(rt.<Boolean>get("financialCo")));
            }

            if (strict) {
                // Strict mode drops rows whose ratios carry a calculation warning —
                // an ROE of 412% from near-zero equity should not top a quality screen.
                Path<String> warnings = rt.get("warnings");
                all.add(cb.or(cb.isNull(warnings), cb.equal(warnings, "[]")));
            }
            return cb.and(all.toArray(new Predicate[0]));
        };
    }

    // ------------------------------------------------------------------

    private Predicate build(Ast.Node n, Root<CompanyMetrics> rt, CriteriaBuilder cb) {
        if (n instanceof Ast.And) {
            Ast.And a = (Ast.And) n;
            List<Predicate> kids = new ArrayList<>();
            for (Ast.Node c : a.children) {
                kids.add(build(c, rt, cb));
            }
            return cb.and(kids.toArray(new Predicate[0]));
        }
        if (n instanceof Ast.Or) {
            Ast.Or o = (Ast.Or) n;
            List<Predicate> kids = new ArrayList<>();
            for (Ast.Node c : o.children) {
                kids.add(build(c, rt, cb));
            }
            return cb.or(kids.toArray(new Predicate[0]));
        }
        if (n instanceof Ast.Not) {
            return cb.not(build(((Ast.Not) n).child, rt, cb));
        }
        if (n instanceof Ast.Cmp) {
            return comparison((Ast.Cmp) n, rt, cb);
        }
        if (n instanceof Ast.Between) {
            Ast.Between b = (Ast.Between) n;
            Expression<BigDecimal> p = numeric(b.metric, rt);
            return cb.between(p, b.lo.value, b.hi.value);
        }
        if (n instanceof Ast.In) {
            Ast.In in = (Ast.In) n;
            Path<Object> p = path(in.metric, rt);
            return p.in(in.values);
        }
        if (n instanceof Ast.IsNull) {
            Ast.IsNull isn = (Ast.IsNull) n;
            Path<Object> p = path(isn.metric, rt);
            return isn.negated ? cb.isNotNull(p) : cb.isNull(p);
        }
        throw new IllegalStateException("Unhandled node: " + n.getClass().getName());
    }

    private Predicate comparison(Ast.Cmp c, Root<CompanyMetrics> rt, CriteriaBuilder cb) {
        if ("~".equals(c.op)) {
            Expression<String> p = text(c.metric, rt);
            String needle = String.valueOf(c.value).toLowerCase();
            // Escape LIKE wildcards so a user's '%' matches a literal percent sign.
            needle = needle.replace("!", "!!").replace("%", "!%").replace("_", "!_");
            return cb.like(cb.lower(p), "%" + needle + "%", '!');
        }

        if (c.metric.isNumeric()) {
            Expression<BigDecimal> p = numeric(c.metric, rt);
            BigDecimal v = (BigDecimal) c.value;
            switch (c.op) {
                case ">":
                    return cb.greaterThan(p, v);
                case ">=":
                    return cb.greaterThanOrEqualTo(p, v);
                case "<":
                    return cb.lessThan(p, v);
                case "<=":
                    return cb.lessThanOrEqualTo(p, v);
                case "=":
                    return cb.equal(p, v);
                case "!=":
                    // notEqual alone would also match NULL rows in some dialects;
                    // requiring non-null keeps "unknown" out of the result set.
                    return cb.and(cb.isNotNull(p), cb.notEqual(p, v));
                default:
                    throw new QueryException("BAD_OPERATOR", c.position, c.op,
                            "Operator '" + c.op + "' is not valid here");
            }
        }

        Path<Object> p = path(c.metric, rt);
        if ("=".equals(c.op)) {
            return cb.equal(p, c.value);
        }
        return cb.and(cb.isNotNull(p), cb.notEqual(p, c.value));
    }

    // ------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    private Expression<BigDecimal> numeric(MetricDef m, Root<CompanyMetrics> rt) {
        return (Expression<BigDecimal>) (Expression<?>) path(m, rt);
    }

    @SuppressWarnings("unchecked")
    private Expression<String> text(MetricDef m, Root<CompanyMetrics> rt) {
        return (Expression<String>) (Expression<?>) path(m, rt);
    }

    /**
     * Resolves a whitelisted attribute to a Criteria path.
     *
     * <p>Always a direct attribute of the read model — every queryable field lives on
     * {@code company_metrics}, so no query ever needs a join.
     */
    private Path<Object> path(MetricDef m, Root<CompanyMetrics> rt) {
        return rt.get(m.attribute());
    }

    private boolean touchesFinancialCoInapplicable(Ast.Node n) {
        if (n instanceof Ast.And) {
            for (Ast.Node c : ((Ast.And) n).children) {
                if (touchesFinancialCoInapplicable(c)) {
                    return true;
                }
            }
            return false;
        }
        if (n instanceof Ast.Or) {
            for (Ast.Node c : ((Ast.Or) n).children) {
                if (touchesFinancialCoInapplicable(c)) {
                    return true;
                }
            }
            return false;
        }
        if (n instanceof Ast.Not) {
            return touchesFinancialCoInapplicable(((Ast.Not) n).child);
        }
        String key = null;
        if (n instanceof Ast.Cmp) {
            key = ((Ast.Cmp) n).metric.key();
        } else if (n instanceof Ast.Between) {
            key = ((Ast.Between) n).metric.key();
        } else if (n instanceof Ast.In) {
            key = ((Ast.In) n).metric.key();
        } else if (n instanceof Ast.IsNull) {
            key = ((Ast.IsNull) n).metric.key();
        }
        return key != null && FINANCIAL_CO_INAPPLICABLE.contains(key);
    }

    /**
     * Matches rows where any filtered metric has no value.
     *
     * <p>Used to report a truthful {@code excludedForMissingData} count. Without it a screen
     * returning 6 of 2,337 companies looks like a bug, when the real explanation is usually
     * that most rows have no computable ROE yet because the balance sheet is filed only
     * half-yearly.
     */
    public Specification<CompanyMetrics> anyFilteredMetricMissing(List<Ast.Node> leaves) {
        return (rt, q, cb) -> {
            List<Predicate> nulls = new ArrayList<>();
            for (Ast.Node n : leaves) {
                MetricDef m = metricOf(n);
                if (m != null && m.isNumeric()) {
                    nulls.add(cb.isNull(path(m, rt)));
                }
            }
            if (nulls.isEmpty()) {
                return cb.disjunction();
            }
            return cb.or(nulls.toArray(new Predicate[0]));
        };
    }

    private static MetricDef metricOf(Ast.Node n) {
        if (n instanceof Ast.Cmp) {
            return ((Ast.Cmp) n).metric;
        }
        if (n instanceof Ast.Between) {
            return ((Ast.Between) n).metric;
        }
        if (n instanceof Ast.In) {
            return ((Ast.In) n).metric;
        }
        if (n instanceof Ast.IsNull) {
            return ((Ast.IsNull) n).metric;
        }
        return null;
    }

    /** Flattens the tree for the interpretation block echoed back with results. */
    public static void collect(Ast.Node n, List<Ast.Node> into) {
        if (n instanceof Ast.And) {
            for (Ast.Node c : ((Ast.And) n).children) {
                collect(c, into);
            }
        } else if (n instanceof Ast.Or) {
            for (Ast.Node c : ((Ast.Or) n).children) {
                collect(c, into);
            }
        } else if (n instanceof Ast.Not) {
            collect(((Ast.Not) n).child, into);
        } else {
            into.add(n);
        }
    }
}
