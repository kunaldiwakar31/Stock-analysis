package com.stockscreener.metrics;

import com.stockscreener.common.Nums;

import java.math.BigDecimal;
import java.util.Map;
import java.util.NavigableMap;

/**
 * The ratio engine. Pure functions, no Spring, no database, no I/O.
 *
 * <p>That isolation is deliberate and worth protecting: it is the only way to unit-test
 * these formulas against a filing checked by hand. A scale or annualisation bug here is
 * invisible to every test above it and makes the entire screener confidently wrong, so
 * this class must stay trivially testable.
 *
 * <p>Design rules, all of which exist because of a specific failure mode:
 * <ol>
 *   <li>Null in, null out. Zero is never substituted for missing data.</li>
 *   <li>Flows are annualised before being divided by a balance-sheet stock. A six-month
 *       profit over point-in-time equity otherwise reads as half the true ROE.</li>
 *   <li>CAGR is null when the base is non-positive: an n-th root across a sign flip is
 *       meaningless.</li>
 *   <li>Nothing is clamped. An ROE of 412% is reported as 412% with a warning, and the
 *       screener's strict mode excludes it — silently capping it would hide the problem.</li>
 *   <li>Bank/NBFC-inapplicable ratios are skipped, not approximated.</li>
 * </ol>
 */
public class RatioCalculator {

    /** Rupees in one lakh. */
    private static final BigDecimal LAKH = BigDecimal.valueOf(100_000);
    /** Rupees in one crore. */
    private static final BigDecimal CRORE = BigDecimal.valueOf(10_000_000);

    private static final BigDecimal ROE_SANITY_LIMIT = BigDecimal.valueOf(200);

    /** Fields counted for {@link RatioOutputs#dataCompletenessPct}. */
    private static final int COMPLETENESS_FIELD_COUNT = 20;

    public RatioOutputs compute(RatioInputs in) {
        RatioOutputs out = new RatioOutputs();

        if (in.quartersUsed > 0 && in.quartersUsed < 4) {
            out.warn("ttm_incomplete_" + in.quartersUsed + "q");
        }
        if (in.windowMonths != 12) {
            out.warn("annualised_from_" + in.windowMonths + "m");
        }
        if (in.financialCompany) {
            out.warn("financial_co_leverage_ratios_skipped");
        }

        BigDecimal ebitda = resolveEbitda(in, out);
        BigDecimal ebit = Nums.add(in.profitBeforeTax, in.financeCosts);

        absolutes(in, out, ebitda);
        margins(in, out, ebitda);
        returns(in, out, ebit);
        leverage(in, out, ebit);
        perShareAndValuation(in, out, ebitda);
        growth(in, out);
        quarterYoy(in, out);

        out.dataCompletenessPct = completeness(out);
        return out;
    }

    // ------------------------------------------------------------------
    // Derived inputs
    // ------------------------------------------------------------------

    /**
     * EBITDA = PBT + finance costs + depreciation - other income.
     *
     * <p>Other income is excluded on purpose so the margin describes the operating
     * business. At a cash-rich company treasury income would otherwise inflate
     * "operating" performance. The convention is recorded here so it isn't mistaken
     * for an omission.
     */
    private BigDecimal resolveEbitda(RatioInputs in, RatioOutputs out) {
        if (in.ebitda != null) {
            return in.ebitda;
        }
        BigDecimal base = Nums.add(in.profitBeforeTax, in.financeCosts, in.depreciation);
        if (base == null) {
            return null;
        }
        if (in.otherIncome == null) {
            out.warn("ebitda_excludes_unknown_other_income");
            return base;
        }
        return Nums.sub(base, in.otherIncome);
    }

    // ------------------------------------------------------------------
    // Absolutes
    // ------------------------------------------------------------------

    private void absolutes(RatioInputs in, RatioOutputs out, BigDecimal ebitda) {
        int m = in.windowMonths;
        out.salesTtmCr = Nums.lakhToCrore(Nums.annualise(in.revenue, m));
        out.ebitdaTtmCr = Nums.lakhToCrore(Nums.annualise(ebitda, m));
        out.netProfitTtmCr = Nums.lakhToCrore(Nums.annualise(in.netProfit, m));
        out.cfoTtmCr = Nums.lakhToCrore(Nums.annualise(in.cashFromOperations, m));

        BigDecimal fcf = Nums.sub(in.cashFromOperations, in.capex);
        out.fcfTtmCr = Nums.lakhToCrore(Nums.annualise(fcf, m));

        // Same window on both sides, so no annualisation needed.
        out.ocfToNetProfit = Nums.div(in.cashFromOperations, in.netProfit);
    }

    // ------------------------------------------------------------------
    // Margins — numerator and denominator share the same window
    // ------------------------------------------------------------------

    private void margins(RatioInputs in, RatioOutputs out, BigDecimal ebitda) {
        out.operatingMarginPct = Nums.pct(ebitda, in.revenue);
        out.netProfitMarginPct = Nums.pct(in.netProfit, in.revenue);
    }

    // ------------------------------------------------------------------
    // Returns — flow annualised, stock averaged
    // ------------------------------------------------------------------

    private void returns(RatioInputs in, RatioOutputs out, BigDecimal ebit) {
        int m = (in.balanceSheetWindowMonths != null)
                ? in.balanceSheetWindowMonths
                : in.windowMonths;

        if (in.totalEquity == null) {
            out.warn("no_balance_sheet");
        }

        BigDecimal annualProfit = Nums.annualise(in.netProfit, m);
        BigDecimal avgEquity = Nums.avg(in.totalEquity, in.prevTotalEquity);
        if (in.prevTotalEquity == null && in.totalEquity != null) {
            out.warn("equity_not_averaged");
        }

        if (avgEquity != null && avgEquity.signum() <= 0) {
            out.warn("non_positive_equity");
        } else {
            out.roePct = Nums.pct(annualProfit, avgEquity);
            if (out.roePct != null && out.roePct.abs().compareTo(ROE_SANITY_LIMIT) > 0) {
                out.warn("near_zero_equity_roe_unreliable");
            }
        }

        BigDecimal avgAssets = Nums.avg(in.totalAssets, in.prevTotalAssets);
        out.roaPct = Nums.pct(annualProfit, avgAssets);

        if (!in.financialCompany) {
            BigDecimal capitalEmployed = capitalEmployed(in, out);
            if (capitalEmployed != null && capitalEmployed.signum() > 0) {
                out.rocePct = Nums.pct(Nums.annualise(ebit, m), capitalEmployed);
            }
        }
    }

    /**
     * Capital employed = total equity + total borrowings.
     *
     * <p><b>Cash is deliberately not netted off.</b> Both conventions are defensible, but
     * they diverge sharply for a cash-rich company: on Thyrocare's H1 FY26 figures, netting
     * roughly 15,000 lakh of cash and investments moves ROCE from 43.8% to 62.0%. The
     * unnetted form is what Indian screeners report, so it is used here to keep numbers
     * comparable with what a user sees elsewhere. Netting is reserved for enterprise value.
     *
     * <p>Equity is required. Borrowings are treated leniently, because in Ind-AS filings a
     * debt-free company frequently tags borrowings as an explicit nil and an absent tag
     * means the same thing — but the substitution is recorded so strict screens can exclude
     * the row.
     */
    private BigDecimal capitalEmployed(RatioInputs in, RatioOutputs out) {
        if (in.totalEquity == null) {
            return null;
        }
        if (in.totalBorrowings == null) {
            out.warn("borrowings_absent_treated_as_nil");
            return in.totalEquity;
        }
        return in.totalEquity.add(in.totalBorrowings, Nums.MC);
    }

    // ------------------------------------------------------------------
    // Leverage
    // ------------------------------------------------------------------

    private void leverage(RatioInputs in, RatioOutputs out, BigDecimal ebit) {
        if (!in.financialCompany) {
            out.debtToEquity = Nums.div(in.totalBorrowings, in.totalEquity);
        }
        // Both sides share the window, so annualisation cancels out.
        if (in.financeCosts != null && in.financeCosts.signum() == 0) {
            out.warn("no_finance_cost_interest_coverage_undefined");
        } else {
            out.interestCoverage = Nums.div(ebit, in.financeCosts);
        }
    }

    // ------------------------------------------------------------------
    // Per-share figures and valuation
    // ------------------------------------------------------------------

    private void perShareAndValuation(RatioInputs in, RatioOutputs out, BigDecimal ebitda) {
        out.currentPrice = in.currentPrice;
        out.high52w = in.high52w;
        out.low52w = in.low52w;
        out.pctFromHigh = Nums.changePct(in.high52w, in.currentPrice);

        BigDecimal shares = in.sharesOutstanding;
        if (shares == null || shares.signum() <= 0) {
            out.warn("no_share_count");
            return;
        }

        // Market cap in crore: shares * price (rupees) / 1e7
        if (in.currentPrice != null) {
            out.marketCapCr = Nums.div(Nums.mul(shares, in.currentPrice), CRORE);
        } else {
            out.warn("no_price_feed");
        }

        out.bookValue = perShareFromLakh(in.totalEquity, shares);

        // Derive EPS from net profit rather than trusting a sum of reported quarterly
        // EPS, which breaks whenever the share count changed mid-year.
        BigDecimal annualProfit = Nums.annualise(in.netProfit, in.windowMonths);
        out.epsTtm = perShareFromLakh(annualProfit, shares);
        if (out.epsTtm == null && in.reportedEpsSum != null) {
            out.epsTtm = Nums.annualise(in.reportedEpsSum, in.windowMonths);
            out.warn("eps_from_reported_sum");
        }

        if (in.currentPrice == null) {
            return;
        }

        if (Nums.isPositive(out.epsTtm)) {
            out.peRatio = Nums.div(in.currentPrice, out.epsTtm);
            out.earningsYieldPct = Nums.pct(out.epsTtm, in.currentPrice);
        } else if (out.epsTtm != null) {
            out.warn("non_positive_eps_pe_undefined");
        }

        if (Nums.isPositive(out.bookValue)) {
            out.pbRatio = Nums.div(in.currentPrice, out.bookValue);
        }

        if (!in.financialCompany) {
            BigDecimal netDebtCr = Nums.lakhToCrore(
                    Nums.sub(in.totalBorrowings, in.cashAndInvestments));
            BigDecimal ev = Nums.add(out.marketCapCr, netDebtCr);
            BigDecimal annualEbitdaCr = Nums.lakhToCrore(
                    Nums.annualise(ebitda, in.windowMonths));
            if (Nums.isPositive(annualEbitdaCr)) {
                out.evToEbitda = Nums.div(ev, annualEbitdaCr);
            }
        }

        BigDecimal annualDividendCr = Nums.lakhToCrore(
                Nums.annualise(in.dividendsPaid, in.windowMonths));
        out.dividendYieldPct = Nums.pct(annualDividendCr, out.marketCapCr);
    }

    /** Converts a lakh-denominated total into a per-share rupee figure. */
    private BigDecimal perShareFromLakh(BigDecimal lakhValue, BigDecimal shares) {
        if (lakhValue == null || shares == null || shares.signum() <= 0) {
            return null;
        }
        return lakhValue.multiply(LAKH, Nums.MC).divide(shares, Nums.MC);
    }

    // ------------------------------------------------------------------
    // Growth
    // ------------------------------------------------------------------

    private void growth(RatioInputs in, RatioOutputs out) {
        out.salesGrowth1yPct = cagr(in.annualRevenue, 1);
        out.salesGrowth2yPct = cagr(in.annualRevenue, 2);
        out.salesGrowth3yPct = cagr(in.annualRevenue, 3);
        out.salesGrowth5yPct = cagr(in.annualRevenue, 5);

        out.profitGrowth1yPct = cagr(in.annualNetProfit, 1);
        out.profitGrowth2yPct = cagr(in.annualNetProfit, 2);
        out.profitGrowth3yPct = cagr(in.annualNetProfit, 3);
        out.profitGrowth5yPct = cagr(in.annualNetProfit, 5);

        out.epsGrowth3yPct = cagr(in.annualEps, 3);

        // Warn only when the 3-year figure genuinely could not be produced, not merely
        // because the series is short — two endpoints three years apart are enough.
        if (out.salesGrowth3yPct == null && out.profitGrowth3yPct == null) {
            out.warn("insufficient_annual_history_for_3y_cagr");
        }
    }

    /**
     * CAGR between the latest fiscal year present and the one n years earlier.
     *
     * <p>Returns null unless <em>both</em> endpoints exist. Falling back to the nearest
     * available year would silently relabel 2-year growth as 5-year growth, which is a
     * worse outcome than an empty cell.
     */
    private BigDecimal cagr(NavigableMap<Integer, BigDecimal> series, int years) {
        if (series == null || series.isEmpty()) {
            return null;
        }
        Map.Entry<Integer, BigDecimal> last = series.lastEntry();
        Integer endFy = last.getKey();
        BigDecimal endVal = last.getValue();
        BigDecimal beginVal = series.get(endFy - years);
        return Nums.cagrPct(beginVal, endVal, years);
    }

    private void quarterYoy(RatioInputs in, RatioOutputs out) {
        out.qtrSalesYoyPct = Nums.changePct(in.yearAgoQuarterRevenue, in.latestQuarterRevenue);
        out.qtrProfitYoyPct = Nums.changePct(in.yearAgoQuarterNetProfit, in.latestQuarterNetProfit);
    }

    // ------------------------------------------------------------------
    // Data quality
    // ------------------------------------------------------------------

    private BigDecimal completeness(RatioOutputs o) {
        BigDecimal[] tracked = {
                o.marketCapCr, o.peRatio, o.pbRatio, o.bookValue,
                o.roePct, o.rocePct, o.roaPct,
                o.operatingMarginPct, o.netProfitMarginPct,
                o.debtToEquity, o.interestCoverage,
                o.salesTtmCr, o.ebitdaTtmCr, o.netProfitTtmCr, o.epsTtm,
                o.cfoTtmCr, o.fcfTtmCr, o.ocfToNetProfit,
                o.salesGrowth1yPct, o.qtrSalesYoyPct
        };
        int present = 0;
        for (BigDecimal v : tracked) {
            if (v != null) {
                present++;
            }
        }
        return BigDecimal.valueOf(present)
                .multiply(Nums.HUNDRED)
                .divide(BigDecimal.valueOf(COMPLETENESS_FIELD_COUNT), Nums.MC);
    }
}
