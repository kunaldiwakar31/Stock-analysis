package com.stockscreener.domain.repo;

import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface FinancialRepository extends JpaRepository<Financial, Long> {

    Optional<Financial> findByCompanyIdAndPeriodEndAndPeriodTypeAndConsolidated(
            Long companyId, LocalDate periodEnd, PeriodType periodType, boolean consolidated);

    /**
     * Newest first, consolidated ahead of standalone.
     *
     * <p>The ordering encodes the "prefer consolidated, fall back to standalone" rule in
     * one place. Standalone accounts hide subsidiary debt and losses, so consolidated is
     * the correct default whenever both exist.
     */
    @Query("select f from Financial f where f.companyId = :companyId "
            + "and f.periodType = :periodType "
            + "order by f.consolidated desc, f.periodEnd desc")
    List<Financial> findSeries(@Param("companyId") Long companyId,
                               @Param("periodType") PeriodType periodType);

    @Query("select f from Financial f where f.companyId = :companyId "
            + "and f.periodType = :periodType and f.consolidated = :consolidated "
            + "order by f.periodEnd desc")
    List<Financial> findSeriesForBasis(@Param("companyId") Long companyId,
                                       @Param("periodType") PeriodType periodType,
                                       @Param("consolidated") boolean consolidated);

    /** Distinct company ids that have at least one row, for driving the compute job. */
    @Query("select distinct f.companyId from Financial f")
    List<Long> findCompanyIdsWithData();

    /**
     * Latest period already on file for a company, or {@code null} if none.
     *
     * <p>Used to tell a genuinely new reporting period from a reparse/backfill of a
     * period already seen — see {@code FilingParseService.enrichCompany}. A share-count
     * jump against a period that isn't actually new yet is a correction, not an event.
     */
    @Query("select max(f.periodEnd) from Financial f where f.companyId = :companyId")
    LocalDate findMaxPeriodEnd(@Param("companyId") Long companyId);

    /** Every row strictly before {@code periodEnd}, the set a corporate action restates. */
    List<Financial> findByCompanyIdAndPeriodEndLessThan(Long companyId, LocalDate periodEnd);
}
