package com.stockscreener.xbrl;

import com.stockscreener.common.FiscalCalendar;
import com.stockscreener.common.Nums;
import com.stockscreener.common.RoundingLevel;
import com.stockscreener.domain.Enums.Derivation;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Turns a parsed XBRL instance into {@link Financial} rows.
 *
 * <p>Three things make this less mechanical than it looks, and each is handled explicitly:
 *
 * <ol>
 *   <li><b>Scale.</b> Every filer declares its own rounding level. Values are normalised
 *       to rupees lakh here, and a filing with no declared level is rejected rather than
 *       guessed at — a silent 100x error is the worst outcome this system can produce.</li>
 *   <li><b>Comparatives.</b> An instance contains prior-period figures alongside current
 *       ones. Contexts are therefore selected by matching the period end to the filing's
 *       own quarter end, never by taking the first duration found.</li>
 *   <li><b>Quarter versus year-to-date.</b> Filings carry both a three-month and a
 *       cumulative column, and some filers populate only the latter. Both are emitted
 *       when present; deriving the missing quarter needs the previous filing and so
 *       happens one layer up.</li>
 * </ol>
 */
@Component
public class FilingExtractor {

    private static final Logger log = LoggerFactory.getLogger(FilingExtractor.class);

    private final ConceptMap concepts;

    public FilingExtractor(ConceptMap concepts) {
        this.concepts = concepts;
    }

    /** What one filing yields. */
    public static class Result {
        public RoundingLevel roundingLevel;
        public String isin;
        public BigDecimal faceValue;
        public BigDecimal paidUpCapital;
        /** Rupees lakh. */
        public final List<Financial> rows = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public int factsParsed;
        public int factsUnmapped;
    }

    public Result extract(XbrlDocument doc, LocalDate quarterEnd, boolean consolidated,
                          String sourceUrl, Boolean audited) {
        Result res = new Result();

        // 1. Scale. No default: an unreadable rounding level fails the filing.
        String levelText = text("roundingLevel", doc);
        res.roundingLevel = RoundingLevel.parse(levelText);

        res.isin = text("isin", doc);
        res.factsParsed = doc.facts.size();
        countUnmapped(doc, res);

        // 2. Contexts that belong to this filing period.
        XbrlDocument.Context quarterCtx = durationEndingAt(doc, quarterEnd, 3, 3);
        XbrlDocument.Context ytdCtx = ytdContext(doc, quarterEnd);
        XbrlDocument.Context instantCtx = instantAt(doc, quarterEnd);

        // Face value and paid-up capital sit on whichever period context exists.
        XbrlDocument.Context anyCtx = firstNonNull(quarterCtx, ytdCtx, instantCtx);
        res.faceValue = raw("faceValue", doc, anyCtx);
        BigDecimal paidUpRaw = raw("paidUpCapital", doc, anyCtx);
        if (paidUpRaw == null && instantCtx != null) {
            paidUpRaw = raw("equityShareCapitalBs", doc, instantCtx);
        }
        res.paidUpCapital = res.roundingLevel.toLakh(paidUpRaw);

        if (res.paidUpCapital != null && res.faceValue != null
                && !RoundingLevel.plausibleShareCount(res.paidUpCapital, res.faceValue)) {
            // Independent cross-check on the scale decision: if the implied share count is
            // absurd, the declared rounding level was probably misread.
            res.warnings.add("implausible_share_count_check_scale");
        }

        if (quarterCtx == null && ytdCtx == null) {
            res.warnings.add("no_period_context_matching_" + quarterEnd);
            log.warn("No usable duration context ending {} in {}", quarterEnd, sourceUrl);
            return res;
        }

        // 3. Rows.
        if (quarterCtx != null) {
            Financial q = row(doc, res, quarterCtx, instantCtx, quarterEnd, consolidated,
                    sourceUrl, audited, PeriodType.Q, 3);
            res.rows.add(q);
        }

        if (ytdCtx != null) {
            int months = ytdCtx.months();
            if (months == 12 && FiscalCalendar.isFiscalYearEnd(quarterEnd)) {
                // A March filing's cumulative column is the full fiscal year, which is what
                // multi-year growth is computed from.
                Financial fy = row(doc, res, ytdCtx, instantCtx, quarterEnd, consolidated,
                        sourceUrl, audited, PeriodType.FY, 12);
                res.rows.add(fy);
            } else if (quarterCtx == null) {
                // Only cumulative figures were filed. Keep them so the quarter can be
                // derived later as YTD(n) - YTD(n-1); dropping them loses the period.
                Financial ytd = row(doc, res, ytdCtx, instantCtx, quarterEnd, consolidated,
                        sourceUrl, audited, PeriodType.Q, months);
                ytd.setDerivation(Derivation.REPORTED);
                ytd.setMonthsCovered(months);
                res.warnings.add("only_ytd_reported_" + months + "m");
                res.rows.add(ytd);
            }
        }

        return res;
    }

    // ------------------------------------------------------------------
    // Row assembly
    // ------------------------------------------------------------------

    private Financial row(XbrlDocument doc, Result res,
                          XbrlDocument.Context flowCtx, XbrlDocument.Context instantCtx,
                          LocalDate periodEnd, boolean consolidated, String sourceUrl,
                          Boolean audited, PeriodType type, int months) {

        RoundingLevel lvl = res.roundingLevel;
        Financial f = new Financial();
        f.setPeriodEnd(periodEnd);
        f.setPeriodType(type);
        f.setConsolidated(consolidated);
        f.setMonthsCovered(months);
        f.setDerivation(Derivation.REPORTED);
        f.setAudited(audited);
        f.setSourceUrl(sourceUrl);
        f.setRoundingLevel(lvl.name());

        // ---- P&L, from the flow context ----
        f.setRevenue(money("revenue", doc, flowCtx, lvl));
        f.setOtherIncome(money("otherIncome", doc, flowCtx, lvl));
        f.setTotalExpenses(money("totalExpenses", doc, flowCtx, lvl));
        f.setDepreciation(money("depreciation", doc, flowCtx, lvl));
        f.setFinanceCosts(money("financeCosts", doc, flowCtx, lvl));
        f.setProfitBeforeTax(money("profitBeforeTax", doc, flowCtx, lvl));
        f.setTaxExpense(money("taxExpense", doc, flowCtx, lvl));

        BigDecimal netProfit = money("netProfit", doc, flowCtx, lvl);
        if (netProfit == null) {
            netProfit = money("netProfitContinuing", doc, flowCtx, lvl);
        }
        f.setNetProfit(netProfit);

        // EPS is per share, so it must not be scaled.
        f.setEps(raw("epsBasic", doc, flowCtx));

        f.setPaidUpCapital(money("paidUpCapital", doc, flowCtx, lvl));

        // Operating profit is derived, not tagged: PBT + finance costs + depreciation,
        // less other income so the margin describes the operating business rather than
        // treasury returns.
        BigDecimal base = Nums.add(f.getProfitBeforeTax(), f.getFinanceCosts(),
                f.getDepreciation());
        if (base != null) {
            f.setOperatingProfit(f.getOtherIncome() == null
                    ? base : Nums.sub(base, f.getOtherIncome()));
        }

        // ---- Balance sheet, from the instant context ----
        if (instantCtx != null) {
            BigDecimal equity = money("totalEquity", doc, instantCtx, lvl);
            if (equity == null) {
                // Reserves are frequently left blank in the P&L block, so build equity
                // from the balance sheet instead of trusting that field.
                equity = Nums.addLenient(
                        money("equityShareCapitalBs", doc, instantCtx, lvl),
                        money("otherEquity", doc, instantCtx, lvl));
            }
            f.setTotalEquity(equity);
            f.setTotalAssets(money("totalAssets", doc, instantCtx, lvl));

            f.setTotalBorrowings(Nums.addLenient(
                    money("borrowingsCurrent", doc, instantCtx, lvl),
                    money("borrowingsNonCurrent", doc, instantCtx, lvl)));

            f.setCashAndInvestments(Nums.addLenient(
                    money("cashAndCashEquivalents", doc, instantCtx, lvl),
                    money("otherBankBalances", doc, instantCtx, lvl),
                    money("currentInvestments", doc, instantCtx, lvl)));

            balanceCheck(doc, instantCtx, lvl, f, res);
        }

        // ---- Cash flow ----
        // Attached only when its window matches this row's. The cash flow statement is
        // filed half-yearly, so pairing a six-month operating cash flow with a three-month
        // profit would make OCF/PAT read as roughly double. In practice this means cash
        // flow lands on the full-year rows, which is where cash-quality ratios are computed.
        XbrlDocument.Context cfCtx = cashFlowContext(doc, periodEnd);
        if (cfCtx != null) {
            if (cfCtx.months() == months) {
                f.setCashFromOperations(money("cashFromOperations", doc, cfCtx, lvl));
                f.setCapex(Nums.addLenient(
                        money("purchaseOfPpe", doc, cfCtx, lvl),
                        money("purchaseOfIntangibles", doc, cfCtx, lvl)));
                f.setDividendsPaid(money("dividendsPaid", doc, cfCtx, lvl));
            } else {
                res.warnings.add("cash_flow_window_" + cfCtx.months()
                        + "m_not_matching_row_" + months + "m");
            }
        }

        return f;
    }

    /**
     * Assets must equal equity plus liabilities.
     *
     * <p>A free integrity test on the concept mapping. If this does not hold, a mapping is
     * wrong, and every ratio derived from the row is wrong in a way no downstream test will
     * catch — so the deviation is recorded rather than allowed to pass quietly.
     */
    private void balanceCheck(XbrlDocument doc, XbrlDocument.Context ctx, RoundingLevel lvl,
                             Financial f, Result res) {
        BigDecimal assets = f.getTotalAssets();
        BigDecimal liabilities = money("totalLiabilities", doc, ctx, lvl);
        BigDecimal equity = f.getTotalEquity();
        if (assets == null || liabilities == null || equity == null) {
            return;
        }
        BigDecimal diff = assets.subtract(equity.add(liabilities, Nums.MC), Nums.MC).abs();
        BigDecimal tolerance = assets.abs().multiply(new BigDecimal("0.005"), Nums.MC);
        if (diff.compareTo(tolerance.max(BigDecimal.ONE)) > 0) {
            res.warnings.add("balance_sheet_does_not_balance_by_" + diff.setScale(0,
                    java.math.RoundingMode.HALF_UP) + "_lakh");
        }
    }

    // ------------------------------------------------------------------
    // Context selection
    // ------------------------------------------------------------------

    /** Plain duration context ending exactly at {@code end}, within a month range. */
    private XbrlDocument.Context durationEndingAt(XbrlDocument doc, LocalDate end,
                                                  int minMonths, int maxMonths) {
        XbrlDocument.Context best = null;
        for (XbrlDocument.Context c : doc.contexts.values()) {
            if (c.isInstant() || !c.isPlain() || c.end == null || !c.end.equals(end)) {
                continue;
            }
            int m = c.months();
            if (m < minMonths || m > maxMonths) {
                continue;
            }
            if (best == null || m < best.months()) {
                best = c;
            }
        }
        return best;
    }

    /**
     * The cumulative context for this filing: the longest plain duration ending at the
     * period end. For Q1 that is the same three months as the quarter itself.
     */
    private XbrlDocument.Context ytdContext(XbrlDocument doc, LocalDate end) {
        XbrlDocument.Context best = null;
        for (XbrlDocument.Context c : doc.contexts.values()) {
            if (c.isInstant() || !c.isPlain() || c.end == null || !c.end.equals(end)) {
                continue;
            }
            int m = c.months();
            if (m < 3 || m > 12) {
                continue;
            }
            if (best == null || m > best.months()) {
                best = c;
            }
        }
        return best;
    }

    private XbrlDocument.Context instantAt(XbrlDocument doc, LocalDate at) {
        for (XbrlDocument.Context c : doc.contexts.values()) {
            if (c.isInstant() && c.isPlain() && at.equals(c.instant)) {
                return c;
            }
        }
        return null;
    }

    /**
     * Context carrying the cash flow statement.
     *
     * <p>Prefers whichever duration ending at the period end actually has an operating
     * cash flow fact, because the statement's window (half-year or full year) frequently
     * differs from the profit window being reported.
     */
    private XbrlDocument.Context cashFlowContext(XbrlDocument doc, LocalDate end) {
        for (String concept : concepts.conceptsFor("cashFromOperations")) {
            for (XbrlDocument.Fact fact : doc.facts(concept)) {
                XbrlDocument.Context c = doc.context(fact.contextRef);
                if (c != null && !c.isInstant() && c.isPlain()
                        && end.equals(c.end)) {
                    return c;
                }
            }
        }
        return null;
    }

    private XbrlDocument.Context firstNonNull(XbrlDocument.Context... cs) {
        for (XbrlDocument.Context c : cs) {
            if (c != null) {
                return c;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Fact lookup
    // ------------------------------------------------------------------

    /** Numeric value scaled to rupees lakh. */
    private BigDecimal money(String field, XbrlDocument doc, XbrlDocument.Context ctx,
                             RoundingLevel lvl) {
        return lvl.toLakh(raw(field, doc, ctx));
    }

    /** Numeric value exactly as filed, unscaled. Use for per-share and ratio fields. */
    private BigDecimal raw(String field, XbrlDocument doc, XbrlDocument.Context ctx) {
        if (ctx == null) {
            return null;
        }
        for (String concept : concepts.conceptsFor(field)) {
            for (XbrlDocument.Fact f : doc.facts(concept)) {
                if (!ctx.id.equals(f.contextRef)) {
                    continue;
                }
                BigDecimal v = number(f.value);
                if (v != null) {
                    return v;
                }
            }
        }
        return null;
    }

    private String text(String field, XbrlDocument doc) {
        for (String concept : concepts.conceptsFor(field)) {
            for (XbrlDocument.Fact f : doc.facts(concept)) {
                if (f.value != null && !f.value.isEmpty()) {
                    return f.value;
                }
            }
        }
        return null;
    }

    /** Parses a filed number, tolerating grouping and accounting-style negatives. */
    static BigDecimal number(String s) {
        if (s == null) {
            return null;
        }
        String v = s.trim();
        if (v.isEmpty() || "-".equals(v)) {
            return null;
        }
        boolean negative = false;
        if (v.startsWith("(") && v.endsWith(")")) {
            negative = true;
            v = v.substring(1, v.length() - 1);
        }
        v = v.replace(",", "").replace("₹", "").replace("%", "").trim();
        if (v.isEmpty()) {
            return null;
        }
        try {
            BigDecimal d = new BigDecimal(v);
            return negative ? d.negate() : d;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void countUnmapped(XbrlDocument doc, Result res) {
        int unmapped = 0;
        for (XbrlDocument.Fact f : doc.facts) {
            if (!concepts.isKnown(f.concept)) {
                concepts.noteUnmapped(f.concept);
                unmapped++;
            }
        }
        res.factsUnmapped = unmapped;
    }
}
