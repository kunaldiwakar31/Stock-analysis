package com.stockscreener.metrics;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Computed ratios, mapping 1:1 onto the {@code company_metrics} table.
 *
 * <p>Money here is in rupees <b>crore</b> — this is the query/display layer, so the
 * units match what a user types into the screener. Percentages are plain numbers
 * (18.5 means 18.5%).
 *
 * <p>A null field means "not computable from available data", never zero. {@link #warnings}
 * explains why, and {@link #dataCompletenessPct} quantifies how much was derivable — both
 * are load-bearing, because with balance sheets arriving half-yearly a great many cells
 * are legitimately empty and the screener must distinguish that from a genuine miss.
 */
public class RatioOutputs {

    // Price and size
    public BigDecimal currentPrice;
    public BigDecimal marketCapCr;
    public BigDecimal high52w;
    public BigDecimal low52w;
    public BigDecimal pctFromHigh;

    // Valuation
    public BigDecimal peRatio;
    public BigDecimal pbRatio;
    public BigDecimal bookValue;
    public BigDecimal evToEbitda;
    public BigDecimal dividendYieldPct;
    public BigDecimal earningsYieldPct;

    // Returns
    public BigDecimal roePct;
    public BigDecimal rocePct;
    public BigDecimal roaPct;

    // Margins
    public BigDecimal operatingMarginPct;
    public BigDecimal netProfitMarginPct;

    // Leverage
    public BigDecimal debtToEquity;
    public BigDecimal interestCoverage;

    // Trailing absolutes (crore)
    public BigDecimal salesTtmCr;
    public BigDecimal ebitdaTtmCr;
    public BigDecimal netProfitTtmCr;
    public BigDecimal epsTtm;
    public BigDecimal cfoTtmCr;
    public BigDecimal fcfTtmCr;
    public BigDecimal ocfToNetProfit;

    // Growth (CAGR %)
    public BigDecimal salesGrowth1yPct;
    public BigDecimal salesGrowth2yPct;
    public BigDecimal salesGrowth3yPct;
    public BigDecimal salesGrowth5yPct;
    public BigDecimal profitGrowth1yPct;
    public BigDecimal profitGrowth2yPct;
    public BigDecimal profitGrowth3yPct;
    public BigDecimal profitGrowth5yPct;
    public BigDecimal epsGrowth3yPct;

    // Latest quarter
    public BigDecimal qtrSalesYoyPct;
    public BigDecimal qtrProfitYoyPct;

    // Data quality
    public BigDecimal dataCompletenessPct;
    public final List<String> warnings = new ArrayList<>();

    void warn(String code) {
        if (!warnings.contains(code)) {
            warnings.add(code);
        }
    }
}
