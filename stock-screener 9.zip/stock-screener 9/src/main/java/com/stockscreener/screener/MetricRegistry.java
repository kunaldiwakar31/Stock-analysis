package com.stockscreener.screener;

import com.stockscreener.screener.MetricDef.Availability;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The whitelist. Every metric a query may reference is declared here, and nothing else
 * is reachable.
 *
 * <p>This is the security boundary of the query language. A metric name is resolved to a
 * {@link MetricDef} or the query is rejected outright, so a user-supplied identifier can
 * never become part of a SQL statement. Combined with bound parameters for literals in
 * {@link SpecCompiler}, injection is structurally impossible rather than filtered against.
 *
 * <p>Adding a metric is one entry here — no parser change, no endpoint change.
 */
public final class MetricRegistry {

    private static final Map<String, MetricDef> BY_ALIAS = new LinkedHashMap<>();
    private static final List<MetricDef> ALL = new ArrayList<>();

    private MetricRegistry() {
    }

    private static void reg(MetricDef d) {
        ALL.add(d);
        for (String a : d.aliases()) {
            BY_ALIAS.put(a.toLowerCase(), d);
        }
    }

    static {
        // ---- Price and size ----
        reg(new MetricDef("marketcap", "marketCapCr", Unit.CRORE, Availability.NEEDS_PRICE,
                "Market Cap", "market_cap", "mcap"));
        reg(new MetricDef("price", "currentPrice", Unit.RUPEE, Availability.NEEDS_PRICE,
                "Current Price", "current_price", "cmp"));
        reg(new MetricDef("high_52w", "high52w", Unit.RUPEE, Availability.NEEDS_PRICE,
                "52 Week High", "high", "week_high"));
        reg(new MetricDef("low_52w", "low52w", Unit.RUPEE, Availability.NEEDS_PRICE,
                "52 Week Low", "low", "week_low"));
        reg(new MetricDef("pct_from_high", "pctFromHigh", Unit.PERCENT, Availability.NEEDS_PRICE,
                "Percent from 52w High", "from_high", "off_high"));

        // ---- Valuation ----
        reg(new MetricDef("pe", "peRatio", Unit.RATIO, Availability.NEEDS_PRICE,
                "Stock P/E", "pe_ratio", "price_to_earnings"));
        reg(new MetricDef("pb", "pbRatio", Unit.RATIO, Availability.NEEDS_PRICE,
                "Price to Book", "pb_ratio", "price_to_book"));
        reg(new MetricDef("book_value", "bookValue", Unit.RUPEE, Availability.HALF_YEARLY,
                "Book Value per Share", "bv", "bvps"));
        reg(new MetricDef("ev_ebitda", "evToEbitda", Unit.RATIO, Availability.NEEDS_PRICE,
                "EV / EBITDA", "ev_to_ebitda"));
        reg(new MetricDef("div_yield", "dividendYieldPct", Unit.PERCENT, Availability.NEEDS_PRICE,
                "Dividend Yield", "dividend_yield"));
        reg(new MetricDef("earnings_yield", "earningsYieldPct", Unit.PERCENT,
                Availability.NEEDS_PRICE, "Earnings Yield"));

        // ---- Returns ----
        reg(new MetricDef("roe", "roePct", Unit.PERCENT, Availability.HALF_YEARLY,
                "Return on Equity", "roe_pct", "return_on_equity"));
        reg(new MetricDef("roce", "rocePct", Unit.PERCENT, Availability.HALF_YEARLY,
                "Return on Capital Employed", "roce_pct", "return_on_capital"));
        reg(new MetricDef("roa", "roaPct", Unit.PERCENT, Availability.HALF_YEARLY,
                "Return on Assets", "roa_pct"));

        // ---- Margins ----
        reg(new MetricDef("opm", "operatingMarginPct", Unit.PERCENT, Availability.QUARTERLY,
                "Operating Margin", "operating_margin", "ebitda_margin"));
        reg(new MetricDef("net_margin", "netProfitMarginPct", Unit.PERCENT,
                Availability.QUARTERLY, "Net Profit Margin", "npm", "net_profit_margin"));

        // ---- Leverage ----
        reg(new MetricDef("de", "debtToEquity", Unit.RATIO, Availability.HALF_YEARLY,
                "Debt to Equity", "debt_to_equity", "debt_equity"));
        reg(new MetricDef("interest_coverage", "interestCoverage", Unit.RATIO,
                Availability.HALF_YEARLY, "Interest Coverage", "icr"));

        // ---- Trailing absolutes ----
        reg(new MetricDef("sales", "salesTtmCr", Unit.CRORE, Availability.QUARTERLY,
                "Sales (TTM)", "revenue", "sales_ttm"));
        reg(new MetricDef("ebitda", "ebitdaTtmCr", Unit.CRORE, Availability.QUARTERLY,
                "EBITDA (TTM)", "ebitda_ttm", "operating_profit"));
        reg(new MetricDef("net_profit", "netProfitTtmCr", Unit.CRORE, Availability.QUARTERLY,
                "Net Profit (TTM)", "profit", "pat"));
        reg(new MetricDef("eps", "epsTtm", Unit.RUPEE, Availability.QUARTERLY,
                "EPS (TTM)", "eps_ttm"));
        reg(new MetricDef("cfo", "cfoTtmCr", Unit.CRORE, Availability.HALF_YEARLY,
                "Cash from Operations", "cash_flow", "operating_cash_flow"));
        reg(new MetricDef("fcf", "fcfTtmCr", Unit.CRORE, Availability.HALF_YEARLY,
                "Free Cash Flow", "free_cash_flow"));
        reg(new MetricDef("ocf_to_pat", "ocfToNetProfit", Unit.RATIO, Availability.HALF_YEARLY,
                "Operating Cash Flow / Net Profit", "cfo_to_pat", "cash_conversion"));

        // ---- Growth ----
        reg(new MetricDef("sales_growth_1y", "salesGrowth1yPct", Unit.PERCENT,
                Availability.QUARTERLY, "Sales Growth 1Y", "sales_growth"));
        reg(new MetricDef("sales_growth_2y", "salesGrowth2yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "Sales CAGR 2Y"));
        reg(new MetricDef("sales_growth_3y", "salesGrowth3yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "Sales CAGR 3Y"));
        reg(new MetricDef("sales_growth_5y", "salesGrowth5yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "Sales CAGR 5Y"));
        reg(new MetricDef("profit_growth_1y", "profitGrowth1yPct", Unit.PERCENT,
                Availability.QUARTERLY, "Profit Growth 1Y", "profit_growth"));
        reg(new MetricDef("profit_growth_2y", "profitGrowth2yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "Profit CAGR 2Y"));
        reg(new MetricDef("profit_growth_3y", "profitGrowth3yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "Profit CAGR 3Y"));
        reg(new MetricDef("profit_growth_5y", "profitGrowth5yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "Profit CAGR 5Y"));
        reg(new MetricDef("eps_growth_3y", "epsGrowth3yPct", Unit.PERCENT,
                Availability.NEEDS_HISTORY, "EPS CAGR 3Y"));

        // ---- Latest quarter ----
        reg(new MetricDef("qtr_sales_yoy", "qtrSalesYoyPct", Unit.PERCENT,
                Availability.QUARTERLY, "Quarterly Sales YoY", "sales_yoy"));
        reg(new MetricDef("qtr_profit_yoy", "qtrProfitYoyPct", Unit.PERCENT,
                Availability.QUARTERLY, "Quarterly Profit YoY", "profit_yoy"));

        // ---- Shareholding ----
        reg(new MetricDef("promoter_holding", "promoterHoldingPct", Unit.PERCENT,
                Availability.NEEDS_SHAREHOLDING, "Promoter Holding", "promoter"));
        reg(new MetricDef("promoter_pledge", "promoterPledgePct", Unit.PERCENT,
                Availability.NEEDS_SHAREHOLDING, "Pledged Percentage", "pledge", "pledged"));
        reg(new MetricDef("fii_holding", "fiiHoldingPct", Unit.PERCENT,
                Availability.NEEDS_SHAREHOLDING, "FII Holding", "fii"));
        reg(new MetricDef("dii_holding", "diiHoldingPct", Unit.PERCENT,
                Availability.NEEDS_SHAREHOLDING, "DII Holding", "dii"));
        reg(new MetricDef("public_holding", "publicHoldingPct", Unit.PERCENT,
                Availability.NEEDS_SHAREHOLDING, "Public Holding", "public"));

        // ---- LLM ----
        reg(new MetricDef("verdict", "llmVerdict", Unit.ENUM, Availability.NEEDS_ANALYSIS,
                "LLM Verdict"));
        reg(new MetricDef("llm_score", "llmScore", Unit.INT, Availability.NEEDS_ANALYSIS,
                "LLM Fundamental Score", "fundamental_score"));

        // ---- Data quality and profile ----
        reg(new MetricDef("data_completeness", "dataCompletenessPct", Unit.PERCENT,
                Availability.STATIC, "Data Completeness"));
        reg(new MetricDef("basis", "basis", Unit.ENUM, Availability.STATIC,
                "Consolidated or Standalone"));
        // Profile fields are denormalised onto company_metrics, so screening never joins.
        reg(new MetricDef("symbol", "symbol", Unit.TEXT, Availability.STATIC,
                "NSE Symbol", "ticker"));
        reg(new MetricDef("name", "companyName", Unit.TEXT, Availability.STATIC,
                "Company Name", "company_name"));
        reg(new MetricDef("sector", "sector", Unit.TEXT, Availability.STATIC,
                "Sector", "industry"));
        reg(new MetricDef("is_financial_co", "financialCo", Unit.BOOL,
                Availability.STATIC, "Is Bank or NBFC", "is_bank"));
    }

    /** Resolves a user-typed name, or throws with the nearest valid alternatives. */
    public static MetricDef resolve(String rawName, int position) {
        String k = rawName == null ? "" : rawName.trim().toLowerCase();
        MetricDef d = BY_ALIAS.get(k);
        if (d == null) {
            throw new QueryException("UNKNOWN_METRIC", position, rawName,
                    "Unknown metric '" + rawName + "'", suggest(k, 4));
        }
        return d;
    }

    public static boolean exists(String rawName) {
        return rawName != null && BY_ALIAS.containsKey(rawName.trim().toLowerCase());
    }

    public static Collection<MetricDef> all() {
        return ALL;
    }

    /** Closest known aliases by edit distance, for a helpful error message. */
    public static List<String> suggest(String input, int limit) {
        List<String> keys = new ArrayList<>(BY_ALIAS.keySet());
        keys.sort(Comparator.comparingInt(a -> distance(input, a)));
        List<String> out = new ArrayList<>();
        for (String k : keys) {
            if (out.size() >= limit) {
                break;
            }
            if (distance(input, k) <= Math.max(2, input.length() / 2)) {
                out.add(k);
            }
        }
        return out;
    }

    static int distance(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) {
            prev[j] = j;
        }
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = (a.charAt(i - 1) == b.charAt(j - 1)) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
