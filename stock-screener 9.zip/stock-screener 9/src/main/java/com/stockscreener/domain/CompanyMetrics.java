package com.stockscreener.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * The screener table: one flat row per company.
 *
 * <p>Wide and denormalised on purpose. Every screener query resolves against this single
 * table with no joins, which is what makes a filter like
 * {@code roe > 18% AND pe < 25 AND marketcap > 1000cr} a single indexed scan.
 *
 * <p><b>Money is rupees crore</b> here, not lakh — this is the query and display layer,
 * so units match what a user types. Percentages are plain numbers.
 *
 * <p>Explicit {@code @Column} names throughout: fields such as {@code high52w} and
 * {@code salesGrowth1yPct} do not round-trip through Hibernate's default camel-case
 * strategy the way the SQL is written, so they are pinned rather than inferred.
 *
 * <p>There is deliberately <b>no association to {@link Company}</b>. The profile fields are
 * copied in instead. A lazy association would blow up during JSON serialisation once the
 * session closed (open-in-view is off), and an eager one would add a select per row on
 * every page of screener results. Copying four columns into a read model avoids both.
 */
@Entity
@Table(name = "company_metrics")
@Getter
@Setter
public class CompanyMetrics {

    @Id
    @Column(name = "company_id")
    private Long companyId;

    @Column(nullable = false, length = 30)
    private String symbol;

    @Column(name = "company_name", nullable = false)
    private String companyName;

    @Column(length = 100)
    private String sector;

    @Column(name = "is_financial_co", nullable = false)
    private boolean financialCo;

    @Column(name = "as_of_date", nullable = false)
    private LocalDate asOfDate;

    @Column(nullable = false, length = 12)
    private String basis;

    // ---- Price and size ----
    @Column(name = "current_price")
    private BigDecimal currentPrice;
    @Column(name = "market_cap_cr")
    private BigDecimal marketCapCr;
    @Column(name = "high_52w")
    private BigDecimal high52w;
    @Column(name = "low_52w")
    private BigDecimal low52w;
    @Column(name = "pct_from_high")
    private BigDecimal pctFromHigh;

    // ---- Valuation ----
    @Column(name = "pe_ratio")
    private BigDecimal peRatio;
    @Column(name = "pb_ratio")
    private BigDecimal pbRatio;
    @Column(name = "book_value")
    private BigDecimal bookValue;
    @Column(name = "ev_to_ebitda")
    private BigDecimal evToEbitda;
    @Column(name = "dividend_yield_pct")
    private BigDecimal dividendYieldPct;
    @Column(name = "earnings_yield_pct")
    private BigDecimal earningsYieldPct;

    // ---- Returns ----
    @Column(name = "roe_pct")
    private BigDecimal roePct;
    @Column(name = "roce_pct")
    private BigDecimal rocePct;
    @Column(name = "roa_pct")
    private BigDecimal roaPct;

    // ---- Margins ----
    @Column(name = "operating_margin_pct")
    private BigDecimal operatingMarginPct;
    @Column(name = "net_profit_margin_pct")
    private BigDecimal netProfitMarginPct;

    // ---- Leverage ----
    @Column(name = "debt_to_equity")
    private BigDecimal debtToEquity;
    @Column(name = "interest_coverage")
    private BigDecimal interestCoverage;

    // ---- Trailing absolutes (crore) ----
    @Column(name = "sales_ttm_cr")
    private BigDecimal salesTtmCr;
    @Column(name = "ebitda_ttm_cr")
    private BigDecimal ebitdaTtmCr;
    @Column(name = "net_profit_ttm_cr")
    private BigDecimal netProfitTtmCr;
    @Column(name = "eps_ttm")
    private BigDecimal epsTtm;
    @Column(name = "cfo_ttm_cr")
    private BigDecimal cfoTtmCr;
    @Column(name = "fcf_ttm_cr")
    private BigDecimal fcfTtmCr;
    @Column(name = "ocf_to_net_profit")
    private BigDecimal ocfToNetProfit;

    // ---- Growth ----
    @Column(name = "sales_growth_1y_pct")
    private BigDecimal salesGrowth1yPct;
    @Column(name = "sales_growth_2y_pct")
    private BigDecimal salesGrowth2yPct;
    @Column(name = "sales_growth_3y_pct")
    private BigDecimal salesGrowth3yPct;
    @Column(name = "sales_growth_5y_pct")
    private BigDecimal salesGrowth5yPct;
    @Column(name = "profit_growth_1y_pct")
    private BigDecimal profitGrowth1yPct;
    @Column(name = "profit_growth_2y_pct")
    private BigDecimal profitGrowth2yPct;
    @Column(name = "profit_growth_3y_pct")
    private BigDecimal profitGrowth3yPct;
    @Column(name = "profit_growth_5y_pct")
    private BigDecimal profitGrowth5yPct;
    @Column(name = "eps_growth_3y_pct")
    private BigDecimal epsGrowth3yPct;

    // ---- Latest quarter ----
    @Column(name = "qtr_sales_yoy_pct")
    private BigDecimal qtrSalesYoyPct;
    @Column(name = "qtr_profit_yoy_pct")
    private BigDecimal qtrProfitYoyPct;

    // ---- Shareholding ----
    @Column(name = "promoter_holding_pct")
    private BigDecimal promoterHoldingPct;
    @Column(name = "promoter_pledge_pct")
    private BigDecimal promoterPledgePct;
    @Column(name = "fii_holding_pct")
    private BigDecimal fiiHoldingPct;
    @Column(name = "dii_holding_pct")
    private BigDecimal diiHoldingPct;
    @Column(name = "public_holding_pct")
    private BigDecimal publicHoldingPct;

    // ---- LLM ----
    @Column(name = "llm_verdict", length = 20)
    private String llmVerdict;
    @Column(name = "llm_score")
    private Integer llmScore;
    @Column(name = "llm_summary", columnDefinition = "text")
    private String llmSummary;
    @Column(name = "llm_analyzed_at")
    private LocalDateTime llmAnalyzedAt;

    // ---- Data quality ----
    @Column(name = "data_completeness_pct")
    private BigDecimal dataCompletenessPct;
    @Column(columnDefinition = "json")
    private String warnings;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
