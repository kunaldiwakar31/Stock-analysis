package com.stockscreener.ingest;

import java.time.LocalDate;
import java.time.LocalDateTime;

/** One row of the NSE integrated-filing index CSV. */
public class IndexRow {

    public String symbol;
    public String companyName;
    public LocalDate quarterEnd;
    public String submissionType;
    public Boolean audited;
    public boolean consolidated;
    public String htmlUrl;
    public String xbrlUrl;
    public LocalDateTime broadcastAt;
    public LocalDateTime revisedAt;
    public String revisionRemarks;

    /**
     * Ranking timestamp for supersession.
     *
     * <p>A revision carries its own timestamp; originals only have the broadcast time.
     * Taking whichever exists gives one comparable ordering across both.
     */
    public LocalDateTime effectiveAt() {
        return revisedAt != null ? revisedAt : broadcastAt;
    }
}
