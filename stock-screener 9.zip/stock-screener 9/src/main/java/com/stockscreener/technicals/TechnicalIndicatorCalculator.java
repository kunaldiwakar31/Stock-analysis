package com.stockscreener.technicals;

import com.stockscreener.common.Nums;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * The technical indicator engine. Pure function, no Spring, no database — same isolation
 * rule as {@code RatioCalculator} and for the same reason: a scale or off-by-one bug here is
 * invisible to everything above it, so this class has to be trivially testable against a
 * series checked by hand.
 *
 * <p>Design rules:
 * <ol>
 *   <li><b>No lookahead.</b> The value at index {@code i} is computed only from
 *       {@code points[0..i]}. A backtest or a live screener that used a value computed with
 *       future prices baked in would be worthless without knowing it.</li>
 *   <li><b>Null in, null out.</b> Fewer than {@code period} days of history means the field
 *       is null, never a value computed over a shorter, silently-different window.</li>
 *   <li><b>One pass, not one query per day.</b> {@link #computeSeries} produces the whole
 *       aligned series in a handful of linear passes, so backfilling a year of history costs
 *       the same per-day work as computing just today.</li>
 * </ol>
 *
 * <p>Formulas: EMA uses the standard smoothing constant {@code 2/(period+1)}, seeded with the
 * simple average of the first {@code period} values — the conventional definition, and the
 * one every charting platform uses, so numbers here should match what a user sees elsewhere.
 * RSI and ATR use Wilder's smoothing ({@code alpha = 1/period}), which is Wilder's original
 * definition of both and the industry-standard convention, distinct from the EMA constant
 * above despite both being exponential moving averages under the hood.
 */
public class TechnicalIndicatorCalculator {

    private static final MathContext MC = Nums.MC;
    private static final BigDecimal TWO = BigDecimal.valueOf(2);
    private static final BigDecimal HUNDRED = Nums.HUNDRED;

    public List<TechnicalIndicatorResult> computeSeries(List<PricePoint> points) {
        int n = points.size();
        List<BigDecimal> closes = new ArrayList<>(n);
        List<BigDecimal> highs = new ArrayList<>(n);
        List<BigDecimal> lows = new ArrayList<>(n);
        for (PricePoint p : points) {
            closes.add(p.close());
            highs.add(p.high());
            lows.add(p.low());
        }

        BigDecimal[] ema20 = emaSeries(closes, 20);
        BigDecimal[] ema50 = emaSeries(closes, 50);
        BigDecimal[] ema200 = emaSeries(closes, 200);
        BigDecimal[] sma20 = smaSeries(closes, 20);
        BigDecimal[] sma50 = smaSeries(closes, 50);
        BigDecimal[] sma200 = smaSeries(closes, 200);

        BigDecimal[] rsi14 = rsiSeries(closes, 14);
        BigDecimal[] atr14 = atrSeries(highs, lows, closes, 14);
        BigDecimal[][] macd = macdSeries(closes, 12, 26, 9); // [0]=macd [1]=signal [2]=histogram
        BigDecimal[][] boll = bollingerSeries(closes, 20, 2); // [0]=upper [1]=middle [2]=lower

        BigDecimal[] volumeSma20 = smaSeries(volumesAsDecimal(points), 20);

        List<TechnicalIndicatorResult> out = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            PricePoint p = points.get(i);
            TechnicalIndicatorResult r = new TechnicalIndicatorResult();
            r.date = p.date();
            r.close = p.close();
            r.volume = p.volume();
            r.deliveryPct = p.deliveryPct();

            r.ema20 = ema20[i];
            r.ema50 = ema50[i];
            r.ema200 = ema200[i];
            r.sma20 = sma20[i];
            r.sma50 = sma50[i];
            r.sma200 = sma200[i];
            r.rsi14 = rsi14[i];
            r.atr14 = atr14[i];
            r.macd = macd[0][i];
            r.macdSignal = macd[1][i];
            r.macdHistogram = macd[2][i];
            r.bollingerUpper = boll[0][i];
            r.bollingerMiddle = boll[1][i];
            r.bollingerLower = boll[2][i];
            r.volumeSma20 = volumeSma20[i];

            if (r.ema200 == null || r.sma200 == null) {
                r.warn("insufficient_history_for_200d_average_" + (i + 1) + "_of_200_days");
            }
            out.add(r);
        }
        return out;
    }

    // ------------------------------------------------------------------
    // Core smoothing primitive — shared by EMA (alpha = 2/(n+1)) and Wilder's
    // smoothing (alpha = 1/n), which differ only in that constant.
    // ------------------------------------------------------------------

    /**
     * Seeds index {@code period - 1} with the simple average of the first {@code period}
     * values, then recursively blends each later value in with weight {@code alpha}. Every
     * index before the seed is null — there is no shorter-window fallback.
     */
    private BigDecimal[] smoothedSeries(List<BigDecimal> values, int period, BigDecimal alpha) {
        int n = values.size();
        BigDecimal[] out = new BigDecimal[n];
        if (n < period || period <= 0) {
            return out;
        }
        BigDecimal oneMinusAlpha = BigDecimal.ONE.subtract(alpha, MC);

        BigDecimal seedSum = BigDecimal.ZERO;
        for (int i = 0; i < period; i++) {
            seedSum = seedSum.add(values.get(i), MC);
        }
        out[period - 1] = seedSum.divide(BigDecimal.valueOf(period), MC);

        for (int i = period; i < n; i++) {
            out[i] = values.get(i).multiply(alpha, MC)
                    .add(out[i - 1].multiply(oneMinusAlpha, MC), MC);
        }
        return out;
    }

    private BigDecimal[] emaSeries(List<BigDecimal> values, int period) {
        BigDecimal alpha = TWO.divide(BigDecimal.valueOf(period + 1), MC);
        return smoothedSeries(values, period, alpha);
    }

    private BigDecimal[] wilderSeries(List<BigDecimal> values, int period) {
        BigDecimal alpha = BigDecimal.ONE.divide(BigDecimal.valueOf(period), MC);
        return smoothedSeries(values, period, alpha);
    }

    /**
     * Plain rolling average — independent of history before the window, unlike EMA/Wilder.
     * A window containing even one null (e.g. a day with no recorded volume) yields null
     * rather than an average silently computed over fewer than {@code period} values.
     */
    private BigDecimal[] smaSeries(List<BigDecimal> values, int period) {
        int n = values.size();
        BigDecimal[] out = new BigDecimal[n];
        for (int i = period - 1; i < n; i++) {
            BigDecimal sum = BigDecimal.ZERO;
            boolean complete = true;
            for (int j = i - period + 1; j <= i; j++) {
                if (values.get(j) == null) {
                    complete = false;
                    break;
                }
                sum = sum.add(values.get(j), MC);
            }
            out[i] = complete ? sum.divide(BigDecimal.valueOf(period), MC) : null;
        }
        return out;
    }

    private List<BigDecimal> volumesAsDecimal(List<PricePoint> points) {
        List<BigDecimal> out = new ArrayList<>(points.size());
        for (PricePoint p : points) {
            out.add(p.volume() == null ? null : BigDecimal.valueOf(p.volume()));
        }
        return out;
    }

    // ------------------------------------------------------------------
    // RSI-14 (Wilder)
    // ------------------------------------------------------------------

    private BigDecimal[] rsiSeries(List<BigDecimal> closes, int period) {
        int n = closes.size();
        BigDecimal[] out = new BigDecimal[n];
        if (n < 2) {
            return out;
        }
        List<BigDecimal> gains = new ArrayList<>(n - 1);
        List<BigDecimal> losses = new ArrayList<>(n - 1);
        for (int i = 1; i < n; i++) {
            BigDecimal delta = closes.get(i).subtract(closes.get(i - 1), MC);
            gains.add(delta.signum() > 0 ? delta : BigDecimal.ZERO);
            losses.add(delta.signum() < 0 ? delta.negate() : BigDecimal.ZERO);
        }
        BigDecimal[] avgGain = wilderSeries(gains, period);
        BigDecimal[] avgLoss = wilderSeries(losses, period);

        for (int i = 0; i < gains.size(); i++) {
            if (avgGain[i] == null) {
                continue;
            }
            BigDecimal ag = avgGain[i];
            BigDecimal al = avgLoss[i];
            BigDecimal rsi;
            if (al.signum() == 0 && ag.signum() == 0) {
                rsi = BigDecimal.valueOf(50); // flat prices: neither overbought nor oversold
            } else if (al.signum() == 0) {
                rsi = HUNDRED;
            } else {
                BigDecimal rs = ag.divide(al, MC);
                rsi = HUNDRED.subtract(
                        HUNDRED.divide(BigDecimal.ONE.add(rs, MC), MC), MC);
            }
            out[i + 1] = rsi; // aligned back to the closes index the delta ended on
        }
        return out;
    }

    // ------------------------------------------------------------------
    // ATR-14 (Wilder)
    // ------------------------------------------------------------------

    private BigDecimal[] atrSeries(List<BigDecimal> highs, List<BigDecimal> lows,
                                   List<BigDecimal> closes, int period) {
        int n = closes.size();
        BigDecimal[] out = new BigDecimal[n];
        if (n < 2) {
            return out;
        }
        List<BigDecimal> trueRange = new ArrayList<>(n - 1);
        for (int i = 1; i < n; i++) {
            if (highs.get(i) == null || lows.get(i) == null) {
                trueRange.add(null);
                continue;
            }
            BigDecimal highLow = highs.get(i).subtract(lows.get(i), MC);
            BigDecimal highPrevClose = highs.get(i).subtract(closes.get(i - 1), MC).abs();
            BigDecimal lowPrevClose = lows.get(i).subtract(closes.get(i - 1), MC).abs();
            BigDecimal tr = highLow.max(highPrevClose).max(lowPrevClose);
            trueRange.add(tr);
        }
        // A null in the middle of the window (a day with no high/low on file) would silently
        // corrupt every ATR from that point on if fed through the recursive smoother, so this
        // is rejected rather than papered over with a zero.
        if (trueRange.stream().anyMatch(Objects::isNull)) {
            return out;
        }
        BigDecimal[] atr = wilderSeries(trueRange, period);
        for (int i = 0; i < atr.length; i++) {
            out[i + 1] = atr[i];
        }
        return out;
    }

    // ------------------------------------------------------------------
    // MACD(12,26,9)
    // ------------------------------------------------------------------

    /** Returns {macd, signal, histogram}, each aligned to the input closes. */
    private BigDecimal[][] macdSeries(List<BigDecimal> closes, int fast, int slow, int signalP) {
        int n = closes.size();
        BigDecimal[] macd = new BigDecimal[n];
        BigDecimal[] signal = new BigDecimal[n];
        BigDecimal[] histogram = new BigDecimal[n];

        BigDecimal[] emaFast = emaSeries(closes, fast);
        BigDecimal[] emaSlow = emaSeries(closes, slow);
        int firstMacd = -1;
        for (int i = 0; i < n; i++) {
            if (emaFast[i] != null && emaSlow[i] != null) {
                macd[i] = emaFast[i].subtract(emaSlow[i], MC);
                if (firstMacd < 0) {
                    firstMacd = i;
                }
            }
        }
        if (firstMacd >= 0) {
            List<BigDecimal> macdTail = new ArrayList<>(macd.length - firstMacd);
            for (int i = firstMacd; i < n; i++) {
                macdTail.add(macd[i]);
            }
            BigDecimal[] signalTail = emaSeries(macdTail, signalP);
            for (int i = 0; i < signalTail.length; i++) {
                if (signalTail[i] != null) {
                    signal[firstMacd + i] = signalTail[i];
                    histogram[firstMacd + i] = macd[firstMacd + i].subtract(signalTail[i], MC);
                }
            }
        }
        return new BigDecimal[][]{macd, signal, histogram};
    }

    // ------------------------------------------------------------------
    // Bollinger Bands(20, 2 sigma)
    // ------------------------------------------------------------------

    /** Returns {upper, middle, lower}, each aligned to the input closes. */
    private BigDecimal[][] bollingerSeries(List<BigDecimal> closes, int period, int numStdDev) {
        int n = closes.size();
        BigDecimal[] middle = smaSeries(closes, period);
        BigDecimal[] upper = new BigDecimal[n];
        BigDecimal[] lower = new BigDecimal[n];

        for (int i = period - 1; i < n; i++) {
            BigDecimal mean = middle[i];
            BigDecimal sumSq = BigDecimal.ZERO;
            for (int j = i - period + 1; j <= i; j++) {
                BigDecimal diff = closes.get(j).subtract(mean, MC);
                sumSq = sumSq.add(diff.multiply(diff, MC), MC);
            }
            BigDecimal variance = sumSq.divide(BigDecimal.valueOf(period), MC);
            BigDecimal stdDev = variance.sqrt(MC);
            BigDecimal band = stdDev.multiply(BigDecimal.valueOf(numStdDev), MC);
            upper[i] = mean.add(band, MC);
            lower[i] = mean.subtract(band, MC);
        }
        return new BigDecimal[][]{upper, middle, lower};
    }
}
