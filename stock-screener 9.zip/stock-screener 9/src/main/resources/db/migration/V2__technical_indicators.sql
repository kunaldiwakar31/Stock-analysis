-- Technical indicators, computed daily from daily_prices.
-- One row per company per trading day, mirroring daily_prices' own granularity.

ALTER TABLE daily_prices
  ADD COLUMN deliv_qty BIGINT NULL AFTER volume,
  ADD COLUMN deliv_pct DECIMAL(8,4) NULL AFTER deliv_qty;

CREATE TABLE technical_indicators (
  id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  company_id     BIGINT UNSIGNED NOT NULL,
  trade_date     DATE NOT NULL,
  close_price    DECIMAL(14,4) NOT NULL,

  ema_20         DECIMAL(14,4) NULL,
  ema_50         DECIMAL(14,4) NULL,
  ema_200        DECIMAL(14,4) NULL,
  sma_20         DECIMAL(14,4) NULL,
  sma_50         DECIMAL(14,4) NULL,
  sma_200        DECIMAL(14,4) NULL,

  rsi_14         DECIMAL(8,4)  NULL,

  macd           DECIMAL(14,4) NULL,
  macd_signal    DECIMAL(14,4) NULL,
  macd_histogram DECIMAL(14,4) NULL,

  atr_14         DECIMAL(14,4) NULL,

  bollinger_upper  DECIMAL(14,4) NULL,
  bollinger_middle DECIMAL(14,4) NULL,
  bollinger_lower  DECIMAL(14,4) NULL,

  volume         BIGINT NULL,
  volume_sma_20  DECIMAL(20,2) NULL,

  -- Carried through from daily_prices for one-stop screening; see DailyPrice.deliveryPct.
  delivery_pct   DECIMAL(8,4)  NULL,

  warnings       JSON NULL,
  computed_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                   ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uk_ti (company_id, trade_date),
  KEY idx_ti_date (trade_date DESC),
  KEY idx_ti_rsi (rsi_14),
  CONSTRAINT fk_ti_company FOREIGN KEY (company_id) REFERENCES companies(id)
) ENGINE=InnoDB;
