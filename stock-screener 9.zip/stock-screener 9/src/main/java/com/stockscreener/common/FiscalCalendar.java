package com.stockscreener.common;

import java.time.LocalDate;

/**
 * Indian fiscal calendar: April to March.
 *
 * <p>FY27 runs 01-Apr-2026 to 31-Mar-2027, so the quarter ending 30-Jun-2026 is
 * Q1 FY27. Getting this off by one silently misaligns every year-on-year comparison,
 * which is why it lives in one tested place instead of being inlined.
 */
public final class FiscalCalendar {

    private FiscalCalendar() {
    }

    /** Fiscal year label: the calendar year in which the fiscal year ends. */
    public static int fiscalYear(LocalDate periodEnd) {
        int m = periodEnd.getMonthValue();
        int y = periodEnd.getYear();
        return (m >= 4) ? y + 1 : y;
    }

    /** 1..4, where Q1 is the June quarter. */
    public static int fiscalQuarter(LocalDate periodEnd) {
        int m = periodEnd.getMonthValue();
        if (m >= 4 && m <= 6) {
            return 1;
        }
        if (m >= 7 && m <= 9) {
            return 2;
        }
        if (m >= 10 && m <= 12) {
            return 3;
        }
        return 4;
    }

    /** Months elapsed in the fiscal year at this period end: 3, 6, 9 or 12. */
    public static int ytdMonths(LocalDate periodEnd) {
        return fiscalQuarter(periodEnd) * 3;
    }

    /** Same quarter, previous fiscal year — the correct base for year-on-year. */
    public static LocalDate sameQuarterLastYear(LocalDate periodEnd) {
        return periodEnd.minusYears(1);
    }

    /** Previous quarter end, used to derive a quarter from two YTD figures. */
    public static LocalDate previousQuarterEnd(LocalDate periodEnd) {
        LocalDate d = periodEnd.minusMonths(3);
        return d.withDayOfMonth(d.lengthOfMonth());
    }

    public static boolean isFiscalYearEnd(LocalDate periodEnd) {
        return periodEnd.getMonthValue() == 3;
    }
}
