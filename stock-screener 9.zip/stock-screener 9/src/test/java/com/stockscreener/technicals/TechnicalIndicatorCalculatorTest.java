package com.stockscreener.technicals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Every expected value here was independently computed in Python from the same closes/
 * highs/lows/volumes, mirroring this class's exact algorithm (seed-then-blend smoothing,
 * same alignment rules) rather than trusting a third-party library's conventions, which
 * vary at the edges (seeding method, Wilder vs. plain EMA) enough to disagree with each
 * other. Cross-checking two independent implementations of the same spec is what makes
 * this a real test rather than a tautology.
 */
class TechnicalIndicatorCalculatorTest {

    private final TechnicalIndicatorCalculator calc = new TechnicalIndicatorCalculator();

    // A deterministic, wiggly 40-day series: v(i) = 100 + 0.5i + 5*sin(i/3). Wiggly on
    // purpose — a monotonic ramp would never exercise RSI's loss leg or ATR's downside case.
    private static final double[] CLOSES_RAW = new double[40];
    static {
        for (int i = 0; i < 40; i++) {
            CLOSES_RAW[i] = 100 + i * 0.5 + 5 * Math.sin(i / 3.0);
        }
    }

    private List<PricePoint> series40() {
        List<PricePoint> points = new ArrayList<>();
        LocalDate start = LocalDate.of(2025, 1, 1);
        for (int i = 0; i < 40; i++) {
            BigDecimal close = round2(CLOSES_RAW[i]);
            BigDecimal high = round2(close.doubleValue() + 1.2);
            BigDecimal low = round2(close.doubleValue() - 1.1);
            long volume = 100_000 + (i % 7) * 5_000L;
            points.add(new PricePoint(start.plusDays(i), close, high, low, volume, null));
        }
        return points;
    }

    private List<PricePoint> series(int length, double slope, double amplitude, double period) {
        List<PricePoint> points = new ArrayList<>();
        LocalDate start = LocalDate.of(2020, 1, 1);
        for (int i = 0; i < length; i++) {
            double v = 100 + i * slope + amplitude * Math.sin(i / period);
            points.add(new PricePoint(start.plusDays(i), round2(v), null, null, null, null));
        }
        return points;
    }

    private static BigDecimal round2(double v) {
        return BigDecimal.valueOf(v).setScale(2, RoundingMode.HALF_UP);
    }

    private static BigDecimal round4(BigDecimal v) {
        assertNotNull(v, "expected a value but got null");
        return v.setScale(4, RoundingMode.HALF_UP);
    }

    @Nested
    @DisplayName("40-day series, verified against an independent Python implementation")
    class ShortSeries {

        @Test
        void computesSma20AndEma20AtTheirFirstAvailableIndex() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            assertNull(r.get(18).ema20, "day 19 of history is one short of the 20-day window");
            assertEquals(new BigDecimal("104.7585"), round4(r.get(19).sma20));
            assertEquals(new BigDecimal("104.7585"), round4(r.get(19).ema20),
                    "the EMA seed is the plain SMA of the first `period` values");
        }

        @Test
        void computesEma20AtTheEnd() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            assertEquals(new BigDecimal("114.0122"), round4(r.get(39).ema20));
        }

        @Test
        void computesRsi14() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            assertNull(r.get(13).rsi14, "14 gain/loss samples aren't available until day 15");
            assertEquals(new BigDecimal("57.4944"), round4(r.get(14).rsi14));
            assertEquals(new BigDecimal("79.2028"), round4(r.get(39).rsi14));
        }

        @Test
        void computesAtr14() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            assertEquals(new BigDecimal("2.4757"), round4(r.get(14).atr14));
            assertEquals(new BigDecimal("2.6556"), round4(r.get(39).atr14));
        }

        @Test
        void computesMacdAndSignalAtTheirOwnIndependentSeedPoints() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            // MACD needs ema26, so it can't exist before day 26.
            assertNull(r.get(24).macd);
            assertEquals(new BigDecimal("4.7153"), round4(r.get(25).macd));
            // The signal line is its own 9-day EMA of the MACD series, seeded independently
            // 8 days after MACD itself starts — not at day 26 + 9.
            assertNull(r.get(32).macdSignal);
            assertEquals(new BigDecimal("3.8902"), round4(r.get(33).macdSignal));

            assertEquals(new BigDecimal("3.1595"), round4(r.get(39).macd));
            assertEquals(new BigDecimal("3.0141"), round4(r.get(39).macdSignal));
            assertEquals(new BigDecimal("0.1455"), round4(r.get(39).macdHistogram));
        }

        @Test
        void computesBollingerBands() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            TechnicalIndicatorResult last = r.get(39);
            assertEquals(new BigDecimal("114.8645"), round4(last.bollingerMiddle));
            assertEquals(new BigDecimal("120.3490"), round4(last.bollingerUpper));
            assertEquals(new BigDecimal("109.3800"), round4(last.bollingerLower));
        }

        @Test
        void computesVolumeSma20() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            assertEquals(new BigDecimal("114500.00"), round4(r.get(39).volumeSma20));
        }

        @Test
        void ema50AndSma50AreNullForTheWholeShortSeries() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            for (TechnicalIndicatorResult row : r) {
                assertNull(row.ema50, "only 40 days exist; a 50-day average cannot be computed");
                assertNull(row.sma50);
                assertNull(row.ema200);
                assertNull(row.sma200);
            }
        }

        @Test
        void flagsInsufficientHistoryForThe200DayAverages() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series40());
            assertTrue(r.get(39).warnings.stream()
                    .anyMatch(w -> w.startsWith("insufficient_history_for_200d_average")));
        }
    }

    @Nested
    @DisplayName("No lookahead")
    class NoLookahead {

        @Test
        void aLaterDayNeverChangesAnEarlierDaysValue() {
            List<PricePoint> full = series40();
            List<TechnicalIndicatorResult> fullResult = calc.computeSeries(full);

            List<PricePoint> truncated = full.subList(0, 25);
            List<TechnicalIndicatorResult> truncatedResult = calc.computeSeries(truncated);

            // Day 20 (index 19) computed from 40 days of history and from 25 days of
            // history must agree exactly — day 20's EMA20 cannot depend on days 21-40.
            assertEquals(0, fullResult.get(19).ema20.compareTo(truncatedResult.get(19).ema20));
            assertEquals(0, fullResult.get(19).rsi14.compareTo(truncatedResult.get(19).rsi14));
        }
    }

    @Nested
    @DisplayName("210-day series: the 200-day averages actually become available")
    class LongSeries {

        @Test
        void ema200AndSma200AreNullUntilDay200ThenPopulated() {
            List<TechnicalIndicatorResult> r = calc.computeSeries(series(210, 0.3, 5, 4.0));
            assertNull(r.get(198).sma200, "day 199 is one short of the 200-day window");
            assertNull(r.get(198).ema200);

            assertEquals(new BigDecimal("129.8564"), round4(r.get(199).sma200));
            assertEquals(new BigDecimal("129.8564"), round4(r.get(199).ema200),
                    "the EMA200 seed is the plain SMA of the first 200 values");

            assertEquals(new BigDecimal("132.8288"), round4(r.get(209).sma200));
            assertEquals(new BigDecimal("133.1356"), round4(r.get(209).ema200));

            assertTrue(r.get(209).warnings.isEmpty(),
                    "200 days are on file by the last row, so nothing should be flagged");
        }
    }
}
