package com.stockscreener.screener;

import java.util.ArrayList;
import java.util.List;

/**
 * Parsed query tree.
 *
 * <p>Nodes carry a resolved {@link MetricDef} rather than a metric name string. By the time
 * a tree exists, every identifier has already been validated against the whitelist, so
 * {@link SpecCompiler} cannot be handed anything unsafe.
 */
public final class Ast {

    private Ast() {
    }

    public abstract static class Node {
    }

    public static class And extends Node {
        public final List<Node> children = new ArrayList<>();

        public And(List<Node> kids) {
            children.addAll(kids);
        }
    }

    public static class Or extends Node {
        public final List<Node> children = new ArrayList<>();

        public Or(List<Node> kids) {
            children.addAll(kids);
        }
    }

    public static class Not extends Node {
        public final Node child;

        public Not(Node child) {
            this.child = child;
        }
    }

    /** metric OP value */
    public static class Cmp extends Node {
        public final MetricDef metric;
        public final String op;
        /** BigDecimal, String or Boolean. */
        public final Object value;
        public final NormalizedValue normalized;
        public final int position;

        public Cmp(MetricDef metric, String op, Object value,
                   NormalizedValue normalized, int position) {
            this.metric = metric;
            this.op = op;
            this.value = value;
            this.normalized = normalized;
            this.position = position;
        }
    }

    /** metric BETWEEN lo AND hi */
    public static class Between extends Node {
        public final MetricDef metric;
        public final NormalizedValue lo;
        public final NormalizedValue hi;
        public final int position;

        public Between(MetricDef metric, NormalizedValue lo, NormalizedValue hi, int position) {
            this.metric = metric;
            this.lo = lo;
            this.hi = hi;
            this.position = position;
        }
    }

    /** metric IN (a, b, c) */
    public static class In extends Node {
        public final MetricDef metric;
        public final List<Object> values = new ArrayList<>();
        public final int position;

        public In(MetricDef metric, List<Object> values, int position) {
            this.metric = metric;
            this.values.addAll(values);
            this.position = position;
        }
    }

    /** metric IS [NOT] NULL */
    public static class IsNull extends Node {
        public final MetricDef metric;
        public final boolean negated;
        public final int position;

        public IsNull(MetricDef metric, boolean negated, int position) {
            this.metric = metric;
            this.negated = negated;
            this.position = position;
        }
    }
}
