package com.stockscreener.api;

import com.stockscreener.screener.ScreenerService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/screener")
public class ScreenerController {

    private final ScreenerService screener;

    public ScreenerController(ScreenerService screener) {
        this.screener = screener;
    }

    /**
     * Runs a query such as {@code roe > 18% AND roce > 20% AND marketcap > 1000cr}.
     *
     * @param strict when true, rows carrying calculation warnings are excluded — so an ROE
     *     of 412% from near-zero equity cannot top a quality screen
     * @param includeFinancials banks and NBFCs are excluded by default when filtering on a
     *     metric that is meaningless for them
     */
    @GetMapping
    public ScreenerService.ScreenResult screen(
            @RequestParam("q") String q,
            @RequestParam(value = "sort", required = false) String sort,
            @RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "size", defaultValue = "50") int size,
            @RequestParam(value = "strict", defaultValue = "false") boolean strict,
            @RequestParam(value = "includeFinancials", defaultValue = "false")
            boolean includeFinancials) {
        return screener.run(q, sort, page, size, strict, includeFinancials);
    }

    /** The metric whitelist, for autocomplete in an editor. */
    @GetMapping("/metrics")
    public List<Map<String, Object>> metrics() {
        return screener.metrics();
    }

    /** Parse-only. Returns how each condition was interpreted, or a positioned error. */
    @PostMapping("/validate")
    public ResponseEntity<Map<String, Object>> validate(@RequestParam("q") String q) {
        return ResponseEntity.ok(Map.of("query", q, "interpretation", screener.validate(q)));
    }
}
