package com.stockscreener.llm;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.stockscreener.domain.CompanyMetrics;
import com.stockscreener.domain.Enums.Verdict;
import com.stockscreener.domain.repo.CompanyMetricsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Asks a model to interpret the computed ratios.
 *
 * <p>The division of labour is the whole reliability story: <b>Java computes every number,
 * the model only interprets them.</b> Nothing is asked of the model that arithmetic can
 * answer, so a wrong verdict is a judgement call rather than a miscalculation.
 *
 * <p>Nulls and warnings are passed through deliberately. A model told "no price feed, ROE
 * annualised from six months, no multi-year history" reasons correctly about what it cannot
 * conclude; one shown bare numbers invents confidence it has not earned.
 */
@Service
public class AnalysisService {

    private static final Logger log = LoggerFactory.getLogger(AnalysisService.class);

    private static final String SYSTEM = String.join(" ",
            "You are a conservative equity fundamental analyst.",
            "Judge ONLY on the data supplied. Never speculate beyond it and never invent",
            "figures. Missing values are genuinely unknown, not zero. If the key inputs for",
            "a judgement are absent, return verdict INSUFFICIENT_DATA. Do not give",
            "personalised investment advice.",
            "Respond with a single JSON object and no other text, using exactly these keys:",
            "verdict (one of STRONG_BUY, BUY, HOLD, AVOID, INSUFFICIENT_DATA),",
            "score (integer 0-100), summary (string, at most 120 words),",
            "strengths (array of strings), concerns (array of strings).");

    private final CompanyMetricsRepository metrics;
    private final LlmClient llm;
    private final ObjectMapper json = new ObjectMapper();
    private final boolean enabled;
    private final BigDecimal minCompleteness;

    public AnalysisService(CompanyMetricsRepository metrics, LlmClient llm,
                           @Value("${app.llm.enabled:false}") boolean enabled,
                           @Value("${app.llm.min-completeness-pct:40}") int minCompleteness) {
        this.metrics = metrics;
        this.llm = llm;
        this.enabled = enabled;
        this.minCompleteness = BigDecimal.valueOf(minCompleteness);
    }

    @Transactional
    public Optional<CompanyMetrics> analyse(String symbol, boolean force) {
        Optional<CompanyMetrics> found = metrics.findBySymbol(symbol);
        if (found.isEmpty()) {
            return Optional.empty();
        }
        CompanyMetrics m = found.get();

        if (!enabled) {
            log.debug("LLM disabled; skipping {}", symbol);
            return Optional.of(m);
        }
        if (!force && m.getLlmAnalyzedAt() != null) {
            return Optional.of(m);
        }

        // Don't pay to analyse a stub. Below this threshold there isn't enough to judge.
        if (m.getDataCompletenessPct() == null
                || m.getDataCompletenessPct().compareTo(minCompleteness) < 0) {
            m.setLlmVerdict(Verdict.INSUFFICIENT_DATA.name());
            m.setLlmScore(null);
            m.setLlmSummary("Too few metrics available to form a view.");
            m.setLlmAnalyzedAt(LocalDateTime.now());
            return Optional.of(m);
        }

        String payload = buildPayload(m);
        try {
            String raw = llm.complete(SYSTEM, payload);
            apply(m, raw);
        } catch (RuntimeException e) {
            log.warn("Analysis for {} failed: {}", symbol, e.getMessage());
        }
        return Optional.of(m);
    }

    /** Compact JSON of derived metrics. Never the filing itself. */
    String buildPayload(CompanyMetrics m) {
        ObjectNode n = json.createObjectNode();
        n.put("symbol", m.getSymbol());
        n.put("name", m.getCompanyName());
        n.put("sector", m.getSector());
        n.put("basis", m.getBasis());
        n.put("asOf", String.valueOf(m.getAsOfDate()));

        ObjectNode v = n.putObject("valuation");
        put(v, "marketCapCr", m.getMarketCapCr());
        put(v, "pe", m.getPeRatio());
        put(v, "pb", m.getPbRatio());
        put(v, "bookValue", m.getBookValue());
        put(v, "evEbitda", m.getEvToEbitda());
        put(v, "dividendYieldPct", m.getDividendYieldPct());

        ObjectNode q = n.putObject("quality");
        put(q, "roePct", m.getRoePct());
        put(q, "rocePct", m.getRocePct());
        put(q, "roaPct", m.getRoaPct());
        put(q, "operatingMarginPct", m.getOperatingMarginPct());
        put(q, "netMarginPct", m.getNetProfitMarginPct());
        put(q, "debtToEquity", m.getDebtToEquity());
        put(q, "interestCoverage", m.getInterestCoverage());
        put(q, "ocfToNetProfit", m.getOcfToNetProfit());

        ObjectNode g = n.putObject("growth");
        put(g, "salesGrowth1yPct", m.getSalesGrowth1yPct());
        put(g, "salesGrowth3yPct", m.getSalesGrowth3yPct());
        put(g, "salesGrowth5yPct", m.getSalesGrowth5yPct());
        put(g, "profitGrowth1yPct", m.getProfitGrowth1yPct());
        put(g, "profitGrowth3yPct", m.getProfitGrowth3yPct());
        put(g, "qtrSalesYoyPct", m.getQtrSalesYoyPct());
        put(g, "qtrProfitYoyPct", m.getQtrProfitYoyPct());

        ObjectNode s = n.putObject("scale");
        put(s, "salesTtmCr", m.getSalesTtmCr());
        put(s, "ebitdaTtmCr", m.getEbitdaTtmCr());
        put(s, "netProfitTtmCr", m.getNetProfitTtmCr());
        put(s, "epsTtm", m.getEpsTtm());
        put(s, "fcfTtmCr", m.getFcfTtmCr());

        ObjectNode h = n.putObject("shareholding");
        put(h, "promoterPct", m.getPromoterHoldingPct());
        put(h, "pledgePct", m.getPromoterPledgePct());
        put(h, "fiiPct", m.getFiiHoldingPct());
        put(h, "diiPct", m.getDiiHoldingPct());

        put(n, "dataCompletenessPct", m.getDataCompletenessPct());
        n.put("calcWarnings", m.getWarnings() == null ? "[]" : m.getWarnings());

        n.put("rubric", String.join(" ",
                "Assess: margin level and trend; balance-sheet strength;",
                "whether operating cash flow supports reported profit;",
                "growth durability; valuation against the quality on offer.",
                "Treat null as unknown. Name explicitly what you cannot assess."));
        return n.toString();
    }

    private void put(ObjectNode n, String k, BigDecimal v) {
        if (v == null) {
            n.putNull(k);
        } else {
            n.put(k, v);
        }
    }

    /** Validates and stores the model's answer; a malformed reply is discarded, not guessed at. */
    private void apply(CompanyMetrics m, String raw) {
        try {
            String text = raw == null ? "" : raw.trim();
            int start = text.indexOf('{');
            int end = text.lastIndexOf('}');
            if (start < 0 || end <= start) {
                throw new IllegalArgumentException("no JSON object in response");
            }
            JsonNode r = json.readTree(text.substring(start, end + 1));

            String verdict = r.path("verdict").asText("");
            Verdict parsed = Verdict.valueOf(verdict);

            m.setLlmVerdict(parsed.name());
            m.setLlmScore(r.hasNonNull("score") ? r.get("score").asInt() : null);

            StringBuilder summary = new StringBuilder(r.path("summary").asText(""));
            appendList(summary, "Strengths", r.path("strengths"));
            appendList(summary, "Concerns", r.path("concerns"));
            m.setLlmSummary(summary.toString());
            m.setLlmAnalyzedAt(LocalDateTime.now());
        } catch (Exception e) {
            log.warn("Unparseable LLM response, leaving verdict unset: {}", e.getMessage());
        }
    }

    private void appendList(StringBuilder sb, String label, JsonNode arr) {
        if (!arr.isArray() || arr.isEmpty()) {
            return;
        }
        sb.append("\n\n").append(label).append(":");
        arr.forEach(x -> sb.append("\n- ").append(x.asText()));
    }
}
