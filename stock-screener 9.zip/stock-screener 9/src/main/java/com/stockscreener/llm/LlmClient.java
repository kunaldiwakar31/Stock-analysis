package com.stockscreener.llm;

/** Provider-agnostic completion call, so the model vendor is a config choice. */
public interface LlmClient {

    /**
     * @param systemPrompt role and constraints
     * @param userPrompt the metrics payload plus the rubric
     * @return raw model output, expected to be a JSON object
     */
    String complete(String systemPrompt, String userPrompt);

    String modelName();

    String providerName();
}
