package com.stockscreener.xbrl;

import com.stockscreener.common.FiscalCalendar;
import com.stockscreener.common.Nums;
import com.stockscreener.common.RoundingLevel;
import com.stockscreener.domain.Enums.Derivation;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Turns a parsed XBRL instance into {@link Financial} rows.
 *
 * <p>Three things make this less mechanical than it looks, and each is handled explicitly:
 *
 * <ol>
 *   <li><b>Scale.</b> Every filer declares its own rounding level. Values are normalised
 *       to rupees lakh here, and a filing with no declared level is rejected rather than
 *       guessed at — a silent scale error is the worst outcome this system can produce.
 *       Paid-up capital gets an extra guard for exactly this reason: see
 *       {@link #resolvePaidUpCapitalLakh}.</li>
 *   <li><b>Comparatives.</b> An instance contains prior-period figures alongside current
 *       ones. Contexts are therefore selected by matching the period end to the filing's
 *       own quarter end, never by taking the first duration found.</li>
 *   <li><b>Quarter versus year-to-date.</b> Filings carry both a three-month and a
 *       cumulative column, and some filers populate only the latter. Both are emitted
 *       when present; deriving the missing quarter needs the previous filing and so
 *       happens one layer up.</li>
 * </ol>
 */
@Component
public class FilingExtractor {

    private static final Logger log = LoggerFactory.getLogger(FilingExtractor.class);

    private final ConceptMap concepts;

    public FilingExtractor(ConceptMap concepts) {
        this.concepts = concepts;
    }

    /** What one filing yields. */
    public static class Result {
        public RoundingLevel roundingLevel;
        public String isin;
        public BigDecimal faceValue;
        public BigDecimal paidUpCapital;
        /** Rupees lakh. */
        public final List<Financial> rows = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        /** Every context seen, populated only when selection failed. */
        public final List<String> contextDump = new ArrayList<>();
        public int factsParsed;
        public int factsUnmapped;
    }

    public Result extract(XbrlDocument doc, LocalDate quarterEnd, boolean consolidated,
                          String sourceUrl, Boolean audited) {
        Result res = new Result();

        // 1. Scale. No default: an unreadable rounding level fails the filing.
        String levelText = text("roundingLevel", doc);
        res.roundingLevel = RoundingLevel.parse(levelText);

        res.isin = text("isin", doc);
        res.factsParsed = doc.facts.size();
        countUnmapped(doc, res);

        // 2. Contexts that belong to this filing period, chosen by which one actually
        //    carries the facts rather than by shape alone.
        XbrlDocument.Context quarterCtx =
                selectDuration(doc, quarterEnd, 3, 4, PNL_MARKERS, false);
        XbrlDocument.Context ytdCtx =
                selectDuration(doc, quarterEnd, 3, 12, PNL_MARKERS, true);
        XbrlDocument.Context instantCtx =
                selectInstant(doc, quarterEnd, BALANCE_SHEET_MARKERS);

        // A three-month and a cumulative window can resolve to the same context (Q1), which
        // is correct. But if the "quarter" pick is actually the longer cumulative one, drop
        // it: treating six months of revenue as a quarter would overstate it outright.
        if (quarterCtx != null && ytdCtx != null && !quarterCtx.id.equals(ytdCtx.id)
                && quarterCtx.months() > 4) {
            quarterCtx = null;
        }

        noteDateTolerance(quarterCtx, quarterEnd, "quarter", res);
        noteDateTolerance(ytdCtx, quarterEnd, "ytd", res);
        noteDateTolerance(instantCtx, quarterEnd, "balance_sheet", res);

        if (quarterCtx != null && !quarterCtx.isPlain()) {
            res.warnings.add("pnl_on_dimensioned_context_" + quarterCtx.dimensionKey);
        }
        if (instantCtx == null) {
            // Expected for most quarters: SEBI requires the balance sheet half-yearly.
            res.warnings.add("no_balance_sheet_context");
        }

        // Face value and paid-up capital sit on whichever period context exists.
        XbrlDocument.Context anyCtx = firstNonNull(quarterCtx, ytdCtx, instantCtx);
        res.faceValue = raw("faceValue", doc, anyCtx);
        BigDecimal paidUpRaw = raw("paidUpCapital", doc, anyCtx);
        if (paidUpRaw == null && instantCtx != null) {
            paidUpRaw = raw("equityShareCapitalBs", doc, instantCtx);
        }
        res.paidUpCapital = resolvePaidUpCapitalLakh(paidUpRaw, res.roundingLevel,
                res.faceValue, res, "shares");

        if (quarterCtx == null && ytdCtx == null) {
            res.warnings.add("no_period_context_matching_" + quarterEnd);
            dumpContexts(doc, quarterEnd, sourceUrl, res);
            return res;
        }

        // 3. Rows.
        if (quarterCtx != null) {
            Financial q = row(doc, res, quarterCtx, instantCtx, quarterEnd, consolidated,
                    sourceUrl, audited, PeriodType.Q, 3);
            res.rows.add(q);
        }

        if (ytdCtx != null) {
            int months = ytdCtx.months();
            if (months == 12 && FiscalCalendar.isFiscalYearEnd(quarterEnd)) {
                // A March filing's cumulative column is the full fiscal year, which is what
                // multi-year growth is computed from.
                Financial fy = row(doc, res, ytdCtx, instantCtx, quarterEnd, consolidated,
                        sourceUrl, audited, PeriodType.FY, 12);
                res.rows.add(fy);
            } else if (quarterCtx == null) {
                // Only cumulative figures were filed. Keep them so the quarter can be
                // derived later as YTD(n) - YTD(n-1); dropping them loses the period.
                Financial ytd = row(doc, res, ytdCtx, instantCtx, quarterEnd, consolidated,
                        sourceUrl, audited, PeriodType.Q, months);
                ytd.setDerivation(Derivation.REPORTED);
                ytd.setMonthsCovered(months);
                res.warnings.add("only_ytd_reported_" + months + "m");
                res.rows.add(ytd);
            }
        }

        return res;
    }

    /**
     * Resolves paid-up equity share capital to rupees lakh, guarding against the scale
     * bug that produces a share count off by a factor of 10<sup>7</sup>.
     *
     * <p>The declared "Level of rounding used in financial results" governs the Financial
     * Results / Balance Sheet / Cash Flow tables. It does <b>not</b> reliably govern the
     * "Details of equity share capital" block: many preparers tag paid-up capital there in
     * absolute rupees regardless of what the statement-level rounding says, the same way
     * face value is always absolute (and is deliberately read via {@link #raw} rather than
     * {@link #money}, never scaled). When paid-up capital follows that convention but the
     * code applies the statement's rounding factor anyway, the two mistakes compound
     * multiplicatively — e.g. a filing whose statements are in Crores (factor 100) but whose
     * share-capital block is absolute (factor 0.00001) inflates the result by
     * 100 / 0.00001 = 10,000,000, which is the exact 1e7 distortion this method exists to
     * catch.
     *
     * <p>The same {@link RoundingLevel#plausibleShareCount} oracle used at ingest time to
     * flag this is used here to actively decide between the two readings, rather than
     * merely warning while still storing the implausible one:
     *
     * <ol>
     *   <li>Scale by the declared rounding level, as for every other monetary field.</li>
     *   <li>If the implied share count is implausible, retry treating the raw value as
     *       already-absolute rupees (the same convention face value follows).</li>
     *   <li>If that reading is plausible, use it — this is what fixes the 1e7 case.</li>
     *   <li>If neither reading is plausible, refuse to guess further: return null rather
     *       than persist a share count, market cap or book value built on it. A missing
     *       number is recoverable; a confidently wrong one is not.</li>
     * </ol>
     *
     * <p>No face value, or a face value ≤ 0, means the oracle cannot run at all — the
     * declared-scale reading is returned unchecked in that case, same as before this fix.
     */
    private BigDecimal resolvePaidUpCapitalLakh(BigDecimal raw, RoundingLevel lvl,
                                                BigDecimal faceValue, Result res,
                                                String warnLabel) {
        if (raw == null) {
            return null;
        }
        BigDecimal scaled = lvl.toLakh(raw);
        if (faceValue == null || faceValue.signum() <= 0) {
            return scaled;
        }
        if (RoundingLevel.plausibleShareCount(scaled, faceValue)) {
            return scaled;
        }

        BigDecimal asAbsolute = RoundingLevel.UNITS.toLakh(raw);
        if (RoundingLevel.plausibleShareCount(asAbsolute, faceValue)) {
            res.warnings.add(warnLabel + "_paid_up_capital_treated_as_absolute_not_"
                    + lvl.name());
            return asAbsolute;
        }

        // Neither reading survives the sanity check. Recording both attempted values
        // makes the failure diagnosable via /admin/inspect-filing without re-deriving it
        // by hand.
        res.warnings.add(warnLabel + "_paid_up_capital_scale_unresolved_declared_" + lvl
                + "_raw_" + raw);
        return null;
    }

    // ------------------------------------------------------------------
    // Row assembly
    // ------------------------------------------------------------------

    private Financial row(XbrlDocument doc, Result res,
                          XbrlDocument.Context flowCtx, XbrlDocument.Context instantCtx,
                          LocalDate periodEnd, boolean consolidated, String sourceUrl,
                          Boolean audited, PeriodType type, int months) {

        RoundingLevel lvl = res.roundingLevel;
        Financial f = new Financial();
        f.setPeriodEnd(periodEnd);
        f.setPeriodType(type);
        f.setConsolidated(consolidated);
        f.setMonthsCovered(months);
        f.setDerivation(Derivation.REPORTED);
        f.setAudited(audited);
        f.setSourceUrl(sourceUrl);
        f.setRoundingLevel(lvl.name());

        // ---- P&L, from the flow context ----
        f.setRevenue(money("revenue", doc, flowCtx, lvl));
        f.setOtherIncome(money("otherIncome", doc, flowCtx, lvl));
        f.setTotalExpenses(money("totalExpenses", doc, flowCtx, lvl));
        f.setDepreciation(money("depreciation", doc, flowCtx, lvl));
        f.setFinanceCosts(money("financeCosts", doc, flowCtx, lvl));
        f.setProfitBeforeTax(money("profitBeforeTax", doc, flowCtx, lvl));
        f.setTaxExpense(money("taxExpense", doc, flowCtx, lvl));

        BigDecimal netProfit = money("netProfit", doc, flowCtx, lvl);
        if (netProfit == null) {
            netProfit = money("netProfitContinuing", doc, flowCtx, lvl);
        }
        f.setNetProfit(netProfit);

        // EPS is per share, so it must not be scaled.
        f.setEps(raw("epsBasic", doc, flowCtx));

        // Same scale-mismatch risk as res.paidUpCapital above: some preparers tag the
        // share-capital-detail block in absolute rupees regardless of the statement's
        // declared rounding, so this goes through the same resolve-and-verify path rather
        // than a blind lvl.toLakh().
        BigDecimal paidUpRawRow = raw("paidUpCapital", doc, flowCtx);
        f.setPaidUpCapital(resolvePaidUpCapitalLakh(paidUpRawRow, lvl, res.faceValue, res,
                "row_" + type + "_" + periodEnd));

        // Operating profit is derived, not tagged: PBT + finance costs + depreciation,
        // less other income so the margin describes the operating business rather than
        // treasury returns.
        BigDecimal base = Nums.add(f.getProfitBeforeTax(), f.getFinanceCosts(),
                f.getDepreciation());
        if (base != null) {
            f.setOperatingProfit(f.getOtherIncome() == null
                    ? base : Nums.sub(base, f.getOtherIncome()));
        }

        // ---- Balance sheet, from the instant context ----
        if (instantCtx != null) {
            BigDecimal equity = money("totalEquity", doc, instantCtx, lvl);
            if (equity == null) {
                // Reserves are frequently left blank in the P&L block, so build equity
                // from the balance sheet instead of trusting that field.
                equity = Nums.addLenient(
                        money("equityShareCapitalBs", doc, instantCtx, lvl),
                        money("otherEquity", doc, instantCtx, lvl));
            }
            f.setTotalEquity(equity);
            f.setTotalAssets(money("totalAssets", doc, instantCtx, lvl));

            f.setTotalBorrowings(Nums.addLenient(
                    money("borrowingsCurrent", doc, instantCtx, lvl),
                    money("borrowingsNonCurrent", doc, instantCtx, lvl)));

            f.setCashAndInvestments(Nums.addLenient(
                    money("cashAndCashEquivalents", doc, instantCtx, lvl),
                    money("otherBankBalances", doc, instantCtx, lvl),
                    money("currentInvestments", doc, instantCtx, lvl)));

            balanceCheck(doc, instantCtx, lvl, f, res);
        }

        // ---- Cash flow ----
        // Attached only when its window matches this row's. The cash flow statement is
        // filed half-yearly, so pairing a six-month operating cash flow with a three-month
        // profit would make OCF/PAT read as roughly double. In practice this means cash
        // flow lands on the full-year rows, which is where cash-quality ratios are computed.
        XbrlDocument.Context cfCtx =
                selectDuration(doc, periodEnd, 3, 12, CASH_FLOW_MARKERS, true);
        if (cfCtx != null) {
            if (cfCtx.months() == months) {
                f.setCashFromOperations(money("cashFromOperations", doc, cfCtx, lvl));
                f.setCapex(Nums.addLenient(
                        money("purchaseOfPpe", doc, cfCtx, lvl),
                        money("purchaseOfIntangibles", doc, cfCtx, lvl)));
                f.setDividendsPaid(money("dividendsPaid", doc, cfCtx, lvl));
            } else {
                res.warnings.add("cash_flow_window_" + cfCtx.months()
                        + "m_not_matching_row_" + months + "m");
            }
        }

        return f;
    }

    /**
     * Assets must equal equity plus liabilities.
     *
     * <p>A free integrity test on the concept mapping. If this does not hold, a mapping is
     * wrong, and every ratio derived from the row is wrong in a way no downstream test will
     * catch — so the deviation is recorded rather than allowed to pass quietly.
     */
    private void balanceCheck(XbrlDocument doc, XbrlDocument.Context ctx, RoundingLevel lvl,
                             Financial f, Result res) {
        BigDecimal assets = f.getTotalAssets();
        BigDecimal liabilities = money("totalLiabilities", doc, ctx, lvl);
        BigDecimal equity = f.getTotalEquity();
        if (assets == null || liabilities == null || equity == null) {
            return;
        }
        BigDecimal diff = assets.subtract(equity.add(liabilities, Nums.MC), Nums.MC).abs();
        BigDecimal tolerance = assets.abs().multiply(new BigDecimal("0.005"), Nums.MC);
        if (diff.compareTo(tolerance.max(BigDecimal.ONE)) > 0) {
            res.warnings.add("balance_sheet_does_not_balance_by_" + diff.setScale(0,
                    java.math.RoundingMode.HALF_UP) + "_lakh");
        }
    }

    // ------------------------------------------------------------------
    // Context selection
    // ------------------------------------------------------------------

    // ==================================================================
    // Context selection
    //
    // Originally this matched on shape alone — plain (no dimensions), duration, exact end
    // date — which worked only when the primary statement happened to sit on the plain
    // context (typically "OneD"). Four things made that fail silently elsewhere:
    //
    //   1. Rejecting every dimensioned context. Some preparers tag the primary statement
    //      on an axis, so all its facts live on a dimensioned context and the filing
    //      yielded nothing at all.
    //   2. A null end date. The date parser only accepted plain ISO, so anything with a
    //      timezone suffix or a non-ISO form silently dropped the context.
    //   3. Requiring the period end to equal the index CSV's quarter end exactly. A
    //      52/53-week filer, or a preparer off by a day, matched nothing.
    //   4. Iterating a HashMap, so ties between equally-shaped contexts resolved
    //      arbitrarily and the same file could parse differently between runs.
    //
    // Selection is now driven by which context actually carries the mapped facts, with
    // shape used only to rank candidates. That is the same approach the cash flow lookup
    // already used, and it degrades gracefully instead of returning null.
    // ==================================================================

    /** Fields whose presence identifies a profit and loss context. */
    private static final List<String> PNL_MARKERS = List.of(
            "revenue", "otherIncome", "totalExpenses", "profitBeforeTax",
            "netProfit", "netProfitContinuing", "epsBasic", "depreciation",
            "financeCosts", "taxExpense");

    /** Fields whose presence identifies a balance sheet context. */
    private static final List<String> BALANCE_SHEET_MARKERS = List.of(
            "totalAssets", "totalEquity", "equityShareCapitalBs", "otherEquity",
            "inventories", "cashAndCashEquivalents", "totalLiabilities",
            "borrowingsCurrent", "borrowingsNonCurrent");

    private static final List<String> CASH_FLOW_MARKERS = List.of(
            "cashFromOperations", "cashFromInvesting", "cashFromFinancing", "cashAtEnd");

    /**
     * Tolerance on the period end, in days.
     *
     * <p>Absorbs 52/53-week fiscal calendars and preparers whose stated period end is a
     * day or two off the exchange's quarter-end label. Anything matched only by tolerance
     * is recorded as a warning rather than accepted quietly.
     */
    private static final int END_DATE_TOLERANCE_DAYS = 7;

    /** A ranked candidate. */
    private static final class Candidate {
        final XbrlDocument.Context ctx;
        final int factScore;
        final long dateDistance;

        Candidate(XbrlDocument.Context ctx, int factScore, long dateDistance) {
            this.ctx = ctx;
            this.factScore = factScore;
            this.dateDistance = dateDistance;
        }
    }

    /**
     * Duration context for a window of {@code minMonths}..{@code maxMonths} ending at or
     * near {@code end}, chosen by how many of {@code markers} it actually carries.
     *
     * @param preferLongest true to pick the cumulative window, false for the shortest
     */
    private XbrlDocument.Context selectDuration(XbrlDocument doc, LocalDate end,
                                                int minMonths, int maxMonths,
                                                List<String> markers,
                                                boolean preferLongest) {
        List<Candidate> candidates = new ArrayList<>();
        for (XbrlDocument.Context c : doc.orderedContexts()) {
            if (c.isInstant() || c.end == null || c.start == null) {
                continue;
            }
            long distance = Math.abs(ChronoUnit.DAYS.between(c.end, end));
            if (distance > END_DATE_TOLERANCE_DAYS) {
                continue;
            }
            int m = c.months();
            if (m < minMonths || m > maxMonths) {
                continue;
            }
            candidates.add(new Candidate(c, factScore(doc, c, markers), distance));
        }
        return rank(candidates, preferLongest);
    }

    private XbrlDocument.Context selectInstant(XbrlDocument doc, LocalDate at,
                                               List<String> markers) {
        List<Candidate> candidates = new ArrayList<>();
        for (XbrlDocument.Context c : doc.orderedContexts()) {
            if (!c.isInstant() || c.instant == null) {
                continue;
            }
            long distance = Math.abs(ChronoUnit.DAYS.between(c.instant, at));
            if (distance > END_DATE_TOLERANCE_DAYS) {
                continue;
            }
            candidates.add(new Candidate(c, factScore(doc, c, markers), distance));
        }
        return rank(candidates, false);
    }

    /**
     * Picks the best candidate.
     *
     * <p>Order of preference: carries more of the expected facts; then closer to the
     * expected date; then plain before dimensioned, and fewer dimensions before more; then
     * the desired window length; then context id, so the outcome is deterministic.
     *
     * <p>Facts outrank shape deliberately. A dimensioned context holding the whole profit
     * and loss account is far more useful than a plain one holding nothing.
     */
    private XbrlDocument.Context rank(List<Candidate> candidates, boolean preferLongest) {
        if (candidates.isEmpty()) {
            return null;
        }
        candidates.sort((a, b) -> {
            int cmp = Integer.compare(b.factScore, a.factScore);
            if (cmp != 0) {
                return cmp;
            }
            cmp = Long.compare(a.dateDistance, b.dateDistance);
            if (cmp != 0) {
                return cmp;
            }
            cmp = Integer.compare(a.ctx.dimensionCount(), b.ctx.dimensionCount());
            if (cmp != 0) {
                return cmp;
            }
            cmp = preferLongest
                    ? Integer.compare(b.ctx.months(), a.ctx.months())
                    : Integer.compare(a.ctx.months(), b.ctx.months());
            if (cmp != 0) {
                return cmp;
            }
            return String.valueOf(a.ctx.id).compareTo(String.valueOf(b.ctx.id));
        });
        Candidate best = candidates.get(0);
        // A context with none of the expected facts is not the statement we want. Better to
        // return nothing and warn than to attach an empty context and emit null ratios.
        return best.factScore > 0 ? best.ctx : null;
    }

    /** How many of {@code fields} have a usable numeric fact in this context. */
    private int factScore(XbrlDocument doc, XbrlDocument.Context ctx, List<String> fields) {
        int score = 0;
        for (String field : fields) {
            for (String concept : concepts.conceptsFor(field)) {
                boolean found = false;
                for (XbrlDocument.Fact f : doc.facts(concept)) {
                    if (ctx.id.equals(f.contextRef) && number(f.value) != null) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    score++;
                    break;
                }
            }
        }
        return score;
    }

    /** Notes when a context was accepted only because of the date tolerance. */
    private void noteDateTolerance(XbrlDocument.Context ctx, LocalDate expected,
                                   String label, Result res) {
        if (ctx == null) {
            return;
        }
        LocalDate actual = ctx.anchor();
        if (actual != null && !actual.equals(expected)) {
            res.warnings.add(label + "_period_end_" + actual + "_vs_expected_" + expected);
        }
    }

    /**
     * Dumps every context when selection fails.
     *
     * <p>The previous behaviour was to return null and store a row of nulls, leaving no way
     * to tell whether the filing was unusual, the date was off, or a concept name was
     * wrong. This makes that answerable from one log line.
     */
    private void dumpContexts(XbrlDocument doc, LocalDate quarterEnd, String sourceUrl,
                              Result res) {
        Map<String, Integer> counts = doc.factCountByContext();
        List<String> lines = new ArrayList<>();
        for (XbrlDocument.Context c : doc.orderedContexts()) {
            lines.add(c.describe() + " facts=" + counts.getOrDefault(c.id, 0));
        }
        res.contextDump.addAll(lines);
        log.warn("No usable period context for {} (expected end {}). Contexts seen:\n  {}",
                sourceUrl, quarterEnd, String.join("\n  ", lines));
    }

    private XbrlDocument.Context firstNonNull(XbrlDocument.Context... cs) {
        for (XbrlDocument.Context c : cs) {
            if (c != null) {
                return c;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Fact lookup
    // ------------------------------------------------------------------

    /** Numeric value scaled to rupees lakh. */
    private BigDecimal money(String field, XbrlDocument doc, XbrlDocument.Context ctx,
                             RoundingLevel lvl) {
        return lvl.toLakh(raw(field, doc, ctx));
    }

    /** Numeric value exactly as filed, unscaled. Use for per-share and ratio fields. */
    private BigDecimal raw(String field, XbrlDocument doc, XbrlDocument.Context ctx) {
        if (ctx == null) {
            return null;
        }
        for (String concept : concepts.conceptsFor(field)) {
            for (XbrlDocument.Fact f : doc.facts(concept)) {
                if (!ctx.id.equals(f.contextRef)) {
                    continue;
                }
                BigDecimal v = number(f.value);
                if (v != null) {
                    return v;
                }
            }
        }
        return null;
    }

    private String text(String field, XbrlDocument doc) {
        for (String concept : concepts.conceptsFor(field)) {
            for (XbrlDocument.Fact f : doc.facts(concept)) {
                if (f.value != null && !f.value.isEmpty()) {
                    return f.value;
                }
            }
        }
        return null;
    }

    /** Parses a filed number, tolerating grouping and accounting-style negatives. */
    static BigDecimal number(String s) {
        if (s == null) {
            return null;
        }
        String v = s.trim();
        if (v.isEmpty() || "-".equals(v)) {
            return null;
        }
        boolean negative = false;
        if (v.startsWith("(") && v.endsWith(")")) {
            negative = true;
            v = v.substring(1, v.length() - 1);
        }
        v = v.replace(",", "").replace("₹", "").replace("%", "").trim();
        if (v.isEmpty()) {
            return null;
        }
        try {
            BigDecimal d = new BigDecimal(v);
            return negative ? d.negate() : d;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** Exposed for the inspect endpoint, so diagnostics agree with the parser. */
    public boolean knowsConcept(String concept) {
        return concepts.isKnown(concept);
    }

    private void countUnmapped(XbrlDocument doc, Result res) {
        int unmapped = 0;
        for (XbrlDocument.Fact f : doc.facts) {
            if (!concepts.isKnown(f.concept)) {
                concepts.noteUnmapped(f.concept);
                unmapped++;
            }
        }
        res.factsUnmapped = unmapped;
    }
}
