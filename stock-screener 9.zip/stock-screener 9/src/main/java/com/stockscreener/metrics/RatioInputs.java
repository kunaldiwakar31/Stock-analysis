package com.stockscreener.metrics;

import java.math.BigDecimal;
import java.util.NavigableMap;
import java.util.TreeMap;

/**
 * Everything {@link RatioCalculator} needs, assembled by the caller.
 *
 * <p><b>All money is in rupees lakh</b> (the unit NSE filings mostly use), except
 * {@link #currentPrice}, {@link #high52w}, {@link #low52w} and {@link #reportedEpsSum},
 * which are rupees per share. {@link #sharesOutstanding} is an absolute count.
 *
 * <p>Plain mutable fields on purpose: this is a data carrier assembled field-by-field
 * from several sources, and a 30-argument constructor would be worse.
 */
public class RatioInputs {

    /**
     * Months the P&amp;L flow figures (revenue, net profit, EBITDA, ...) cover: 12 for a
     * clean trailing-twelve-months window, or less when the newest run of consecutive
     * quarters is shorter (a gap in filings, or a recent IPO).
     *
     * <p>Cash flow and dividends are <b>not</b> on this window — see
     * {@link #cashFlowWindowMonths}, which is deliberately tracked separately because
     * {@link #cashFromOperations} is always sourced from the latest annual row regardless
     * of how many quarters {@code windowMonths} covers. Annualising cash flow with this
     * field instead of {@code cashFlowWindowMonths} was the cause of an inflated
     * {@code cfo_ttm_cr}/{@code fcf_ttm_cr} whenever the quarter run was under 12 months.
     */
    public int windowMonths = 12;

    /** How many quarterly rows were summed. Below 4 the TTM is incomplete. */
    public int quartersUsed;

    // ---- Flows over windowMonths (rupees lakh) ----
    public BigDecimal revenue;
    public BigDecimal otherIncome;
    public BigDecimal ebitda;
    public BigDecimal depreciation;
    public BigDecimal financeCosts;
    public BigDecimal profitBeforeTax;
    public BigDecimal taxExpense;
    public BigDecimal netProfit;
    public BigDecimal cashFromOperations;
    public BigDecimal capex;
    public BigDecimal dividendsPaid;

    /**
     * Months actually covered by {@link #cashFromOperations}/{@link #capex}/
     * {@link #dividendsPaid} — the {@code monthsCovered} of whichever annual row they were
     * read from (always 12 in practice, since only {@code PeriodType.FY} rows are used).
     * Null only if no cash-flow-bearing row was found, in which case those fields are
     * null too and nothing gets annualised against a mismatched window.
     */
    public Integer cashFlowWindowMonths;

    /** Reported EPS summed over the window; used only as a fallback. */
    public BigDecimal reportedEpsSum;

    // ---- Balance sheet, point in time (rupees lakh) ----
    public BigDecimal totalEquity;
    public BigDecimal prevTotalEquity;
    public BigDecimal totalBorrowings;
    public BigDecimal cashAndInvestments;
    public BigDecimal totalAssets;
    public BigDecimal prevTotalAssets;

    /** Months covered by the profit figure paired with this balance sheet. */
    public Integer balanceSheetWindowMonths;

    // ---- Share and price data ----
    public BigDecimal sharesOutstanding;
    public BigDecimal currentPrice;
    public BigDecimal high52w;
    public BigDecimal low52w;

    // ---- Latest quarter, for year-on-year ----
    public BigDecimal latestQuarterRevenue;
    public BigDecimal yearAgoQuarterRevenue;
    public BigDecimal latestQuarterNetProfit;
    public BigDecimal yearAgoQuarterNetProfit;

    // ---- Annual series for CAGR: fiscal year -> value ----
    public NavigableMap<Integer, BigDecimal> annualRevenue = new TreeMap<>();
    public NavigableMap<Integer, BigDecimal> annualNetProfit = new TreeMap<>();
    public NavigableMap<Integer, BigDecimal> annualEps = new TreeMap<>();

    /**
     * Banks and NBFCs. ROCE, debt/equity and EV/EBITDA are meaningless for them —
     * leverage of 6x is normal banking, not distress — so those are skipped rather
     * than emitted as nonsense.
     */
    public boolean financialCompany;
}
