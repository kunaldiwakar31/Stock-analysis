package com.stockscreener.xbrl;

import com.stockscreener.common.RoundingLevel;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Reproduces a confirmed real-world case: NAVINFLUOR's filing declared "Crores" as its
 * rounding level, but tagged revenue, net profit and dividends in absolute rupees anyway —
 * the same convention face value and EPS always follow. Applying the declared CRORES factor
 * (100) to an already-absolute value instead of the UNITS factor (0.00001) inflates every
 * monetary figure by exactly 100 / 0.00001 = 10,000,000, which is what turned
 * {@code earnings_yield_pct} and {@code dividend_yield_pct} into "Data truncation: Out of
 * range value" instead of a sane percentage.
 *
 * <p>Unlike {@link PaidUpCapitalScaleTest}, this is not a single mistagged field — it is the
 * declared rounding level itself being wrong for the whole filing. {@code
 * resolveActualRoundingLevel} catches it once, document-wide, via an EPS cross-check, rather
 * than needing a bespoke guard on every monetary field one at a time.
 */
class RoundingLevelCrossCheckTest {

    private static final LocalDate Q_END = LocalDate.of(2025, 9, 30);

    private final FilingExtractor extractor = new FilingExtractor(new ConceptMap());

    private void fact(XbrlDocument doc, String concept, String ctxId, String value) {
        XbrlDocument.Fact f = new XbrlDocument.Fact();
        f.concept = concept;
        f.contextRef = ctxId;
        f.value = value;
        doc.facts.add(f);
    }

    /**
     * A minimal filing carrying just enough P&amp;L facts to win context selection, plus
     * face value, paid-up capital, net profit and EPS under whatever raw values the test
     * wants to check.
     */
    private XbrlDocument minimalFiling(String roundingLevelText, String faceValue,
                                       String paidUpCapitalRaw, String netProfitRaw,
                                       String epsRaw) {
        XbrlDocument doc = new XbrlDocument();

        XbrlDocument.Context ctx = new XbrlDocument.Context();
        ctx.id = "ThreeD";
        ctx.start = LocalDate.of(2025, 7, 1);
        ctx.end = Q_END;
        ctx.dimensionKey = "";
        doc.contexts.put(ctx.id, ctx);

        fact(doc, "LevelOfRoundingUsedInFinancialResults", "ThreeD", roundingLevelText);
        fact(doc, "RevenueFromOperations", "ThreeD", "9445000000"); // magnitude irrelevant here
        if (netProfitRaw != null) {
            fact(doc, "ProfitLossForPeriod", "ThreeD", netProfitRaw);
        }
        if (epsRaw != null) {
            fact(doc, "BasicEarningsLossPerShareFromContinuingAndDiscontinuedOperations",
                    "ThreeD", epsRaw);
        }
        if (faceValue != null) {
            fact(doc, "FaceValueOfEquityShareCapital", "ThreeD", faceValue);
        }
        if (paidUpCapitalRaw != null) {
            fact(doc, "PaidUpValueOfEquityShareCapital", "ThreeD", paidUpCapitalRaw);
        }

        doc.index();
        return doc;
    }

    private FilingExtractor.Result extract(XbrlDocument doc) {
        return extractor.extract(doc, Q_END, false, "https://example/test.xml", Boolean.FALSE);
    }

    @Test
    @DisplayName("reproduces the NAVINFLUOR bug: declared Crores, tagged in absolute rupees")
    void reproducesTheNavinfluorBug() {
        // 51.3m shares, face value 2 -> paid-up capital 102,600,000 absolute rupees.
        // Net profit 1,900,000,000 absolute rupees -> filed EPS 37.04, exactly as reported.
        XbrlDocument doc = minimalFiling("Crores", "2", "102600000", "1900000000", "37.04");

        FilingExtractor.Result res = extract(doc);

        assertEquals(RoundingLevel.UNITS, res.roundingLevel,
                "the EPS cross-check should override the declared level");
        assertTrue(res.warnings.stream()
                        .anyMatch(w -> w.equals(
                                "rounding_level_declared_CRORES_actual_UNITS_detected_via_eps_cross_check")),
                "the correction must be recorded: " + res.warnings);

        Financial q = res.rows.stream()
                .filter(f -> f.getPeriodType() == PeriodType.Q)
                .findFirst().orElse(null);
        assertNotNull(q);
        // Pre-fix this would have been 190,000,000,000 lakh (100 / 0.00001 too large).
        assertEquals(0, new BigDecimal("19000").compareTo(q.getNetProfit()));
    }

    @Test
    @DisplayName("leaves a filing alone when the declared level already matches the tagged facts")
    void leavesACorrectlyTaggedFilingAlone() {
        // Same company, but here net profit is genuinely tagged in Lakhs, matching the
        // declared level - the common, correct case, which must not be second-guessed.
        XbrlDocument doc = minimalFiling("Lakhs", "2", "1026", "19000", "37.04");

        FilingExtractor.Result res = extract(doc);

        assertEquals(RoundingLevel.LAKHS, res.roundingLevel);
        assertTrue(res.warnings.stream()
                        .noneMatch(w -> w.contains("rounding_level_declared")),
                "a correctly declared filing should need no override: " + res.warnings);
    }

    @Test
    @DisplayName("falls back to the declared level when EPS is absent - no oracle, no guess")
    void fallsBackWhenEpsIsMissing() {
        XbrlDocument doc = minimalFiling("Crores", "2", "102600000", "1900000000", null);

        FilingExtractor.Result res = extract(doc);

        assertEquals(RoundingLevel.CRORES, res.roundingLevel,
                "with no EPS to check against, the declared level must be trusted as before");
        assertTrue(res.warnings.stream().noneMatch(w -> w.contains("rounding_level")),
                "no oracle ran, so there is nothing to warn about: " + res.warnings);
    }

    @Test
    @DisplayName("flags an inconclusive check rather than picking the least-wrong candidate")
    void flagsInconclusiveRatherThanGuessing() {
        // An EPS that doesn't correspond to any RoundingLevel factor applied to this net
        // profit and share count - e.g. a genuinely corrupted or unrelated tag.
        XbrlDocument doc = minimalFiling("Crores", "2", "102600000", "1900000000", "999.99");

        FilingExtractor.Result res = extract(doc);

        assertEquals(RoundingLevel.CRORES, res.roundingLevel,
                "no candidate reproduces this EPS, so the declared level must not be swapped");
        assertTrue(res.warnings.stream()
                        .anyMatch(w -> w.contains("rounding_level_eps_cross_check_inconclusive")),
                "the failed check must still be recorded: " + res.warnings);
    }
}
