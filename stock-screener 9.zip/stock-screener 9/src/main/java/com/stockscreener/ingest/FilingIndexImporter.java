package com.stockscreener.ingest;

import com.stockscreener.domain.Company;
import com.stockscreener.domain.Enums.IngestStatus;
import com.stockscreener.domain.FilingIngest;
import com.stockscreener.domain.repo.CompanyRepository;
import com.stockscreener.domain.repo.FilingIngestRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Imports the NSE filing index CSV: upserts companies and queues filings for download.
 *
 * <p>Idempotent by construction. The XBRL URL is unique per filing and daily index files
 * overlap heavily, so re-importing yesterday's file adds nothing rather than duplicating
 * work.
 *
 * <p>Supersession matters here. Roughly 11% of rows are revisions, and their stated
 * reasons range from a typo in a meeting date to a corrected <em>denomination</em> — that
 * last one being a filer's own scale error. Only the latest filing per
 * (symbol, quarter, basis) is queued; earlier ones are marked skipped and kept as an
 * audit trail rather than deleted.
 */
@Service
public class FilingIndexImporter {

    private static final Logger log = LoggerFactory.getLogger(FilingIndexImporter.class);

    private final CompanyRepository companies;
    private final FilingIngestRepository ingests;
    private final IndexCsvReader reader = new IndexCsvReader();

    public FilingIndexImporter(CompanyRepository companies, FilingIngestRepository ingests) {
        this.companies = companies;
        this.ingests = ingests;
    }

    public static class ImportSummary {
        public int totalRows;
        public int distinctSymbols;
        public int newCompanies;
        public int queued;
        public int superseded;
        public int alreadyKnown;
        public final List<String> notes = new ArrayList<>();
    }

    @Transactional
    public ImportSummary importIndex(InputStream csv) throws IOException {
        List<IndexRow> rows = reader.read(csv);
        ImportSummary s = new ImportSummary();
        s.totalRows = rows.size();

        Set<String> symbols = new HashSet<>();
        for (IndexRow r : rows) {
            symbols.add(r.symbol);
        }
        s.distinctSymbols = symbols.size();

        // Companies first, so queued filings always have a parent.
        Map<String, Company> bySymbol = new HashMap<>();
        for (IndexRow r : rows) {
            if (bySymbol.containsKey(r.symbol)) {
                continue;
            }
            Company c = companies.findBySymbol(r.symbol).orElse(null);
            if (c == null) {
                c = new Company();
                c.setSymbol(r.symbol);
                c.setCompanyName(r.companyName != null ? r.companyName : r.symbol);
                companies.save(c);
                s.newCompanies++;
            } else if (r.companyName != null && !r.companyName.equals(c.getCompanyName())) {
                c.setCompanyName(r.companyName);
            }
            bySymbol.put(r.symbol, c);
        }

        // Keep only the latest filing per natural key.
        Map<String, IndexRow> winners = new LinkedHashMap<>();
        for (IndexRow r : rows) {
            String key = r.symbol + "|" + r.quarterEnd + "|" + r.consolidated;
            IndexRow existing = winners.get(key);
            if (existing == null || isNewer(r, existing)) {
                winners.put(key, r);
            }
        }
        s.superseded = rows.size() - winners.size();

        for (IndexRow r : winners.values()) {
            if (ingests.existsByXbrlUrl(r.xbrlUrl)) {
                s.alreadyKnown++;
                continue;
            }
            FilingIngest fi = new FilingIngest();
            fi.setSymbol(r.symbol);
            fi.setCompanyName(r.companyName);
            fi.setQuarterEnd(r.quarterEnd);
            fi.setConsolidated(r.consolidated);
            fi.setSubmissionType(r.submissionType);
            fi.setAudited(r.audited);
            fi.setXbrlUrl(r.xbrlUrl);
            fi.setHtmlUrl(r.htmlUrl);
            fi.setBroadcastAt(r.broadcastAt);
            fi.setStatus(IngestStatus.PENDING);
            ingests.save(fi);
            s.queued++;

            markOlderSuperseded(r);
        }

        detectPartialQuarter(rows, s);

        log.info("Index import: {} rows, {} symbols, {} queued, {} superseded, {} known",
                s.totalRows, s.distinctSymbols, s.queued, s.superseded, s.alreadyKnown);
        return s;
    }

    /**
     * Warns when the most recent quarter is only partly filed.
     *
     * <p>Companies report over several weeks, so the newest quarter in any index file is
     * incomplete. A screen run against it silently compares early filers with each other,
     * which is a real and easily-missed distortion — better to say so and let the caller
     * fall back to the previous quarter.
     */
    private void detectPartialQuarter(List<IndexRow> rows, ImportSummary s) {
        Map<LocalDate, Integer> perQuarter = new LinkedHashMap<>();
        for (IndexRow r : rows) {
            perQuarter.merge(r.quarterEnd, 1, Integer::sum);
        }
        if (perQuarter.size() < 2) {
            return;
        }
        LocalDate newest = perQuarter.keySet().stream().max(LocalDate::compareTo).orElse(null);
        List<Integer> others = new ArrayList<>();
        for (Map.Entry<LocalDate, Integer> e : perQuarter.entrySet()) {
            if (!e.getKey().equals(newest)) {
                others.add(e.getValue());
            }
        }
        others.sort(Integer::compareTo);
        int median = others.get(others.size() / 2);
        int newestCount = perQuarter.get(newest);
        if (median > 0 && newestCount < median * 0.7) {
            s.notes.add("Quarter " + newest + " looks partially filed (" + newestCount
                    + " rows vs ~" + median + " typical); prefer the previous quarter"
                    + " when screening");
        }
    }

    private boolean isNewer(IndexRow candidate, IndexRow current) {
        if (candidate.effectiveAt() == null) {
            return false;
        }
        if (current.effectiveAt() == null) {
            return true;
        }
        int cmp = candidate.effectiveAt().compareTo(current.effectiveAt());
        if (cmp != 0) {
            return cmp > 0;
        }
        // Same timestamp: a revision wins over an original.
        return "REVISION".equals(candidate.submissionType)
                && !"REVISION".equals(current.submissionType);
    }

    /** Marks previously queued filings for the same period as superseded. */
    private void markOlderSuperseded(IndexRow winner) {
        List<FilingIngest> siblings =
                ingests.findBySymbolAndQuarterEndAndConsolidatedOrderByBroadcastAtDesc(
                        winner.symbol, winner.quarterEnd, winner.consolidated);
        for (FilingIngest sib : siblings) {
            if (!sib.getXbrlUrl().equals(winner.xbrlUrl)
                    && sib.getStatus() == IngestStatus.PENDING) {
                sib.setStatus(IngestStatus.SKIPPED);
                sib.setErrorMessage("Superseded by " + winner.xbrlUrl);
            }
        }
    }
}
