package com.stockscreener.screener;

import java.math.BigDecimal;

/**
 * A literal after unit conversion, kept alongside what the user actually typed.
 *
 * <p>The original input unit is retained so the API can echo an "interpretation" block
 * back with the results. Showing that {@code 1000cr} was read as {@code 1000} crore is
 * what lets a user trust a result set instead of guessing whether the filter did what
 * they meant.
 */
public class NormalizedValue {

    public final BigDecimal value;
    /** What the user wrote: PERCENT, CRORE, LAKH, RATIO, DAYS, or NONE. */
    public final String inputUnit;
    /** What the column stores. */
    public final Unit storedUnit;

    public NormalizedValue(BigDecimal value, String inputUnit, Unit storedUnit) {
        this.value = value;
        this.inputUnit = inputUnit;
        this.storedUnit = storedUnit;
    }
}
