package com.stockscreener.domain;

import com.stockscreener.domain.Enums.Derivation;
import com.stockscreener.domain.Enums.PeriodType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * One reporting period for one company on one basis.
 *
 * <p><b>All money is rupees lakh</b>, normalised on write from whatever the filer
 * declared. Only the line items needed to compute ratios are kept; the rest of the
 * filing is parsed and discarded.
 */
@Entity
@Table(name = "financials",
        uniqueConstraints = @UniqueConstraint(
                name = "uk_fin",
                columnNames = {"company_id", "period_end", "period_type", "consolidated"}))
@Getter
@Setter
public class Financial {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "company_id", nullable = false)
    private Long companyId;

    @Column(name = "period_end", nullable = false)
    private LocalDate periodEnd;

    @Enumerated(EnumType.STRING)
    @Column(name = "period_type", nullable = false, length = 8)
    private PeriodType periodType;

    @Column(nullable = false)
    private boolean consolidated;

    @Column(name = "months_covered", nullable = false)
    private Integer monthsCovered;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Derivation derivation = Derivation.REPORTED;

    private Boolean audited;

    /** Link back to the filing, so any stored number can be checked at source. */
    @Column(name = "source_url", length = 700)
    private String sourceUrl;

    /** Kept for reproducibility: which scale the filer declared. */
    @Column(name = "rounding_level", length = 12)
    private String roundingLevel;

    @Column(name = "filed_at")
    private LocalDateTime filedAt;

    // ---- P&L ----
    private BigDecimal revenue;
    @Column(name = "other_income")
    private BigDecimal otherIncome;
    @Column(name = "total_expenses")
    private BigDecimal totalExpenses;
    @Column(name = "operating_profit")
    private BigDecimal operatingProfit;
    private BigDecimal depreciation;
    @Column(name = "finance_costs")
    private BigDecimal financeCosts;
    @Column(name = "profit_before_tax")
    private BigDecimal profitBeforeTax;
    @Column(name = "tax_expense")
    private BigDecimal taxExpense;
    @Column(name = "net_profit")
    private BigDecimal netProfit;
    private BigDecimal eps;

    // ---- Balance sheet (half-yearly in practice) ----
    @Column(name = "total_equity")
    private BigDecimal totalEquity;
    @Column(name = "total_borrowings")
    private BigDecimal totalBorrowings;
    @Column(name = "cash_and_investments")
    private BigDecimal cashAndInvestments;
    @Column(name = "total_assets")
    private BigDecimal totalAssets;
    @Column(name = "paid_up_capital")
    private BigDecimal paidUpCapital;

    // ---- Cash flow (half-yearly in practice) ----
    @Column(name = "cash_from_operations")
    private BigDecimal cashFromOperations;
    private BigDecimal capex;
    @Column(name = "dividends_paid")
    private BigDecimal dividendsPaid;

    @Column(columnDefinition = "json")
    private String warnings;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    public boolean hasBalanceSheet() {
        return totalEquity != null || totalAssets != null;
    }

    public boolean hasCashFlow() {
        return cashFromOperations != null;
    }
}
