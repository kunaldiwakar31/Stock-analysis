package com.stockscreener.api;

import com.stockscreener.domain.CompanyMetrics;
import com.stockscreener.domain.Enums.PeriodType;
import com.stockscreener.domain.Financial;
import com.stockscreener.domain.repo.CompanyMetricsRepository;
import com.stockscreener.domain.repo.CompanyRepository;
import com.stockscreener.domain.repo.FinancialRepository;
import com.stockscreener.llm.AnalysisService;
import com.stockscreener.metrics.MetricsService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("/api/v1/companies")
public class CompanyController {

    private final CompanyRepository companies;
    private final CompanyMetricsRepository metrics;
    private final FinancialRepository financials;
    private final MetricsService metricsService;
    private final AnalysisService analysis;

    public CompanyController(CompanyRepository companies, CompanyMetricsRepository metrics,
                            FinancialRepository financials, MetricsService metricsService,
                            AnalysisService analysis) {
        this.companies = companies;
        this.metrics = metrics;
        this.financials = financials;
        this.metricsService = metricsService;
        this.analysis = analysis;
    }

    @GetMapping("/{symbol}")
    public ResponseEntity<CompanyMetrics> metrics(@PathVariable String symbol) {
        return metrics.findBySymbol(norm(symbol))
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Quarterly series. Every row carries its {@code sourceUrl}, so any figure shown here
     * can be checked against the original filing.
     */
    @GetMapping("/{symbol}/quarterly")
    public ResponseEntity<List<Financial>> quarterly(@PathVariable String symbol) {
        return series(symbol, PeriodType.Q);
    }

    @GetMapping("/{symbol}/annual")
    public ResponseEntity<List<Financial>> annual(@PathVariable String symbol) {
        return series(symbol, PeriodType.FY);
    }

    private ResponseEntity<List<Financial>> series(String symbol, PeriodType type) {
        return companies.findBySymbol(norm(symbol))
                .map(c -> ResponseEntity.ok(financials.findSeries(c.getId(), type)))
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /** Recomputes ratios for one company, useful after a concept-mapping fix. */
    @PostMapping("/{symbol}/recompute")
    public ResponseEntity<CompanyMetrics> recompute(@PathVariable String symbol) {
        return companies.findBySymbol(norm(symbol))
                .flatMap(c -> metricsService.recompute(c.getId()))
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/{symbol}/analysis")
    public ResponseEntity<CompanyMetrics> analyse(
            @PathVariable String symbol,
            @RequestParam(value = "force", defaultValue = "false") boolean force) {
        return analysis.analyse(norm(symbol), force)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    private String norm(String symbol) {
        return symbol == null ? "" : symbol.trim().toUpperCase(Locale.ENGLISH);
    }
}
