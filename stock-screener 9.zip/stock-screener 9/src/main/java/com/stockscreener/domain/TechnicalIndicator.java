package com.stockscreener.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * One trading day's technical indicators for one company — same granularity as
 * {@link DailyPrice}, kept as a separate table rather than columns bolted onto it because
 * this is entirely derived, recomputable data: a bug in the indicator math must never risk
 * corrupting the raw price it was computed from. See {@code TechnicalIndicatorCalculator}
 * for the formulas and {@code TechnicalIndicatorService} for how this row gets built.
 *
 * <p>No association to {@link Company}, for the same reason {@link CompanyMetrics} has
 * none: {@code open-in-view} is off, so a lazy association risks
 * {@code LazyInitializationException} on serialisation, and this table is looked up by
 * {@code companyId} directly rather than through a join.
 */
@Entity
@Table(name = "technical_indicators",
        uniqueConstraints = @UniqueConstraint(name = "uk_ti",
                columnNames = {"company_id", "trade_date"}))
@Getter
@Setter
public class TechnicalIndicator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "company_id", nullable = false)
    private Long companyId;

    @Column(name = "trade_date", nullable = false)
    private LocalDate tradeDate;

    @Column(name = "close_price", nullable = false)
    private BigDecimal closePrice;

    @Column(name = "ema_20")
    private BigDecimal ema20;
    @Column(name = "ema_50")
    private BigDecimal ema50;
    @Column(name = "ema_200")
    private BigDecimal ema200;
    @Column(name = "sma_20")
    private BigDecimal sma20;
    @Column(name = "sma_50")
    private BigDecimal sma50;
    @Column(name = "sma_200")
    private BigDecimal sma200;

    @Column(name = "rsi_14")
    private BigDecimal rsi14;

    @Column(name = "macd")
    private BigDecimal macd;
    @Column(name = "macd_signal")
    private BigDecimal macdSignal;
    @Column(name = "macd_histogram")
    private BigDecimal macdHistogram;

    @Column(name = "atr_14")
    private BigDecimal atr14;

    @Column(name = "bollinger_upper")
    private BigDecimal bollingerUpper;
    @Column(name = "bollinger_middle")
    private BigDecimal bollingerMiddle;
    @Column(name = "bollinger_lower")
    private BigDecimal bollingerLower;

    private Long volume;
    @Column(name = "volume_sma_20")
    private BigDecimal volumeSma20;

    @Column(name = "delivery_pct")
    private BigDecimal deliveryPct;

    @Column(columnDefinition = "json")
    private String warnings;

    @Column(name = "computed_at", insertable = false, updatable = false)
    private LocalDateTime computedAt;
}
