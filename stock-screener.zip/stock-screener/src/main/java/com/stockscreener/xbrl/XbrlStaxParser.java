package com.stockscreener.xbrl;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Streaming XBRL instance parser.
 *
 * <p>Namespace-agnostic by design: it matches on element local names only. Filings come
 * from many preparers and the SEBI taxonomy has revisions, so binding to specific
 * namespace URIs would make the parser brittle for no benefit.
 *
 * <p>Streaming rather than DOM because instances are large and only a couple of hundred
 * of roughly six hundred available concepts are wanted.
 *
 * <p>External entity resolution and DTD loading are disabled — these files come off the
 * public internet and must never be able to make the parser fetch anything.
 */
public class XbrlStaxParser {

    public XbrlDocument parse(InputStream in) throws XMLStreamException {
        XMLInputFactory f = XMLInputFactory.newInstance();
        f.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, Boolean.FALSE);
        f.setProperty(XMLInputFactory.SUPPORT_DTD, Boolean.FALSE);
        f.setProperty(XMLInputFactory.IS_COALESCING, Boolean.TRUE);

        XMLStreamReader r = f.createXMLStreamReader(in);
        XbrlDocument doc = new XbrlDocument();

        // Context assembly state
        XbrlDocument.Context ctx = null;
        boolean inPeriod = false;
        boolean inEntity = false;
        List<String> dimParts = new ArrayList<>();
        String pendingDimension = null;

        // Fact assembly state
        XbrlDocument.Fact fact = null;
        StringBuilder text = new StringBuilder();
        Deque<String> stack = new ArrayDeque<>();

        try {
            while (r.hasNext()) {
                int ev = r.next();

                if (ev == XMLStreamConstants.START_ELEMENT) {
                    String name = r.getLocalName();
                    stack.push(name);

                    if ("context".equals(name)) {
                        ctx = new XbrlDocument.Context();
                        ctx.id = r.getAttributeValue(null, "id");
                        dimParts.clear();
                        continue;
                    }
                    if (ctx != null) {
                        if ("period".equals(name)) {
                            inPeriod = true;
                            continue;
                        }
                        if ("entity".equals(name)) {
                            inEntity = true;
                            continue;
                        }
                        if (inEntity && "explicitMember".equals(name)) {
                            pendingDimension = r.getAttributeValue(null, "dimension");
                            text.setLength(0);
                            continue;
                        }
                        if (inPeriod) {
                            text.setLength(0);
                            continue;
                        }
                    }

                    // A fact is any element carrying a contextRef.
                    String contextRef = r.getAttributeValue(null, "contextRef");
                    if (contextRef != null) {
                        fact = new XbrlDocument.Fact();
                        fact.concept = name;
                        fact.contextRef = contextRef;
                        fact.unitRef = r.getAttributeValue(null, "unitRef");
                        // xsi:nil marks an explicitly empty fact; treat it as absent.
                        String nil = r.getAttributeValue(
                                "http://www.w3.org/2001/XMLSchema-instance", "nil");
                        if ("true".equalsIgnoreCase(nil)) {
                            fact = null;
                        }
                        text.setLength(0);
                    }
                    continue;
                }

                if (ev == XMLStreamConstants.CHARACTERS || ev == XMLStreamConstants.CDATA) {
                    text.append(r.getText());
                    continue;
                }

                if (ev == XMLStreamConstants.END_ELEMENT) {
                    String name = r.getLocalName();
                    if (!stack.isEmpty()) {
                        stack.pop();
                    }

                    if (ctx != null) {
                        if ("context".equals(name)) {
                            if (!dimParts.isEmpty()) {
                                ctx.dimensionKey = String.join("|", dimParts);
                            }
                            if (ctx.id != null) {
                                doc.contexts.put(ctx.id, ctx);
                            }
                            ctx = null;
                            continue;
                        }
                        if ("period".equals(name)) {
                            inPeriod = false;
                            continue;
                        }
                        if ("entity".equals(name)) {
                            inEntity = false;
                            continue;
                        }
                        if ("explicitMember".equals(name)) {
                            // Guarded: a member without a dimension attribute would otherwise
                            // record the literal "null=...", corrupting dimensionKey and so
                            // the isPlain() check that gates all context selection.
                            if (pendingDimension != null) {
                                dimParts.add(pendingDimension + "=" + text.toString().trim());
                            }
                            pendingDimension = null;
                            text.setLength(0);
                            continue;
                        }
                        if (inPeriod) {
                            String v = text.toString().trim();
                            if ("startDate".equals(name)) {
                                ctx.start = parseDate(v);
                            } else if ("endDate".equals(name)) {
                                ctx.end = parseDate(v);
                            } else if ("instant".equals(name)) {
                                ctx.instant = parseDate(v);
                            }
                            text.setLength(0);
                            continue;
                        }
                    }

                    if (fact != null && fact.concept.equals(name)) {
                        fact.value = text.toString().trim();
                        if (!fact.value.isEmpty()) {
                            doc.facts.add(fact);
                        }
                        fact = null;
                        text.setLength(0);
                    }
                }
            }
        } finally {
            try {
                r.close();
            } catch (XMLStreamException ignored) {
                // Nothing useful to do while closing.
            }
        }

        doc.index();
        return doc;
    }

    private LocalDate parseDate(String s) {
        if (s == null || s.isEmpty()) {
            return null;
        }
        try {
            // Instant dates occasionally carry a time component.
            return LocalDate.parse(s.length() > 10 ? s.substring(0, 10) : s);
        } catch (RuntimeException e) {
            return null;
        }
    }
}
