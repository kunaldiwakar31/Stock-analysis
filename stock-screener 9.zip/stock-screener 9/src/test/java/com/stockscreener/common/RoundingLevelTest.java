package com.stockscreener.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Scale normalisation.
 *
 * <p>This is the highest-consequence code in the project. The rounding level is declared
 * per filing, so the same concept arrives at hundredfold-different magnitudes across
 * companies, and getting it wrong throws nothing — it just produces a screener in which a
 * small-cap outranks a conglomerate.
 */
class RoundingLevelTest {

    @Test
    @DisplayName("normalises every declared scale to rupees lakh")
    void normalisesToLakh() {
        BigDecimal oneCroreRupees = new BigDecimal("100");   // = 100 lakh

        assertEquals(0, RoundingLevel.CRORES.toLakh(new BigDecimal("1"))
                .compareTo(oneCroreRupees));
        assertEquals(0, RoundingLevel.LAKHS.toLakh(new BigDecimal("100"))
                .compareTo(oneCroreRupees));
        assertEquals(0, RoundingLevel.MILLIONS.toLakh(new BigDecimal("10"))
                .compareTo(oneCroreRupees));
        assertEquals(0, RoundingLevel.THOUSANDS.toLakh(new BigDecimal("10000"))
                .compareTo(oneCroreRupees));
        assertEquals(0, RoundingLevel.UNITS.toLakh(new BigDecimal("10000000"))
                .compareTo(oneCroreRupees));
    }

    @Test
    @DisplayName("parses the wording filers actually use")
    void parsesFilerWording() {
        assertEquals(RoundingLevel.LAKHS, RoundingLevel.parse("Lakhs"));
        assertEquals(RoundingLevel.LAKHS, RoundingLevel.parse("In Lacs"));
        assertEquals(RoundingLevel.CRORES, RoundingLevel.parse("Rs. in Crores"));
        assertEquals(RoundingLevel.MILLIONS, RoundingLevel.parse("Millions"));
        assertEquals(RoundingLevel.THOUSANDS, RoundingLevel.parse("Thousands"));
        assertEquals(RoundingLevel.UNITS, RoundingLevel.parse("Absolute"));
    }

    @Test
    @DisplayName("refuses to guess when the level is absent or unrecognised")
    void refusesToGuess() {
        // Defaulting here would risk a hundredfold error in every figure from the filing,
        // so the filing is rejected instead.
        assertThrows(IllegalArgumentException.class, () -> RoundingLevel.parse(null));
        assertThrows(IllegalArgumentException.class, () -> RoundingLevel.parse("  "));
        assertThrows(IllegalArgumentException.class, () -> RoundingLevel.parse("furlongs"));
    }

    @Test
    @DisplayName("the share-count cross-check catches a hundredfold scale error")
    void shareCountCrossCheck() {
        // Thyrocare: 5,299 lakh of paid-up capital at a face value of 10 implies
        // 529.9 lakh shares, which is plausible.
        assertTrue(RoundingLevel.plausibleShareCount(
                new BigDecimal("5299"), new BigDecimal("10")));

        // The same filing misread as crore inflates capital a hundredfold.
        assertFalse(RoundingLevel.plausibleShareCount(
                new BigDecimal("529900000"), new BigDecimal("10")));

        // A zero or missing face value must not cause a division, nor a guess of 10.
        assertFalse(RoundingLevel.plausibleShareCount(
                new BigDecimal("5299"), BigDecimal.ZERO));
        assertFalse(RoundingLevel.plausibleShareCount(new BigDecimal("5299"), null));
    }
}
