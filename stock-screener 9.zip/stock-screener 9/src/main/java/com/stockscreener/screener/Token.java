package com.stockscreener.screener;

/** A lexical token with its source position, used for pointing at parse errors. */
public class Token {

    public enum Type {
        IDENT, NUMBER, STRING, BOOL,
        OP, LPAREN, RPAREN, COMMA,
        AND, OR, NOT, BETWEEN, IN, IS, NULL,
        EOF
    }

    public final Type type;
    public final String text;
    /** Unit suffix attached to a NUMBER: "%", "cr", "l", "x", "d", or empty. */
    public final String unitSuffix;
    public final int position;

    public Token(Type type, String text, int position) {
        this(type, text, "", position);
    }

    public Token(Type type, String text, String unitSuffix, int position) {
        this.type = type;
        this.text = text;
        this.unitSuffix = unitSuffix == null ? "" : unitSuffix;
        this.position = position;
    }

    public boolean is(Type t) {
        return type == t;
    }

    @Override
    public String toString() {
        return type + "(" + text + (unitSuffix.isEmpty() ? "" : unitSuffix) + ")@" + position;
    }
}
