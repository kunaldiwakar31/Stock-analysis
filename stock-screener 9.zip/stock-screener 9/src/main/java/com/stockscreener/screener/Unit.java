package com.stockscreener.screener;

/** How a metric's value is stored, and therefore how user input must be converted. */
public enum Unit {
    /** Stored as a plain number: 18.50 means 18.50%. */
    PERCENT,
    /** Stored in rupees crore. */
    CRORE,
    /** Dimensionless multiple, e.g. debt/equity, P/E. */
    RATIO,
    /** Rupees per share. */
    RUPEE,
    DAYS,
    INT,
    TEXT,
    ENUM,
    BOOL
}
