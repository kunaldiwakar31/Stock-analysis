package com.stockscreener.xbrl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** A parsed XBRL instance: contexts plus the facts that reference them. */
public class XbrlDocument {

    /** A reporting period. Durations have start and end; instants have only {@link #instant}. */
    public static class Context {
        public String id;
        public LocalDate start;
        public LocalDate end;
        public LocalDate instant;
        /** Non-empty when the context is dimensionally qualified, e.g. per segment. */
        public String dimensionKey = "";

        public boolean isInstant() {
            return instant != null;
        }

        public boolean isPlain() {
            return dimensionKey.isEmpty();
        }

        /** Months covered, rounded to the nearest whole month. */
        public int months() {
            if (start == null || end == null) {
                return 0;
            }
            long days = java.time.temporal.ChronoUnit.DAYS.between(start, end) + 1;
            return (int) Math.round(days / 30.4375);
        }
    }

    public static class Fact {
        public String concept;
        public String contextRef;
        public String unitRef;
        public String value;
    }

    public final Map<String, Context> contexts = new HashMap<>();
    public final List<Fact> facts = new ArrayList<>();

    /** Lowercased concept name to the facts that carry it, for cheap lookup. */
    private final Map<String, List<Fact>> byConcept = new HashMap<>();

    public void index() {
        byConcept.clear();
        for (Fact f : facts) {
            byConcept.computeIfAbsent(f.concept.toLowerCase(Locale.ENGLISH),
                    k -> new ArrayList<>()).add(f);
        }
    }

    public List<Fact> facts(String concept) {
        List<Fact> l = byConcept.get(concept.toLowerCase(Locale.ENGLISH));
        return l == null ? List.of() : l;
    }

    public Context context(String ref) {
        return contexts.get(ref);
    }
}
