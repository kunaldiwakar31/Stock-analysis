package com.stockscreener.domain;

/** Small enums shared across the domain, kept together to avoid a file per constant. */
public final class Enums {

    private Enums() {
    }

    /** Q = a three-month quarter, FY = a full twelve-month fiscal year. */
    public enum PeriodType {
        Q, FY
    }

    /**
     * Whether a quarter's figures were filed directly or back-computed.
     *
     * <p>Filings carry both a three-month and a year-to-date column, and some filers
     * populate only the latter. A quarter derived as {@code YTD(n) - YTD(n-1)} is still
     * usable but must be labelled, because Q4 derived that way absorbs every year-end
     * audit adjustment into a single quarter.
     */
    public enum Derivation {
        REPORTED, YTD_DIFF
    }

    public enum Basis {
        CONSOLIDATED, STANDALONE
    }

    public enum IngestStatus {
        PENDING, DONE, FAILED, SKIPPED
    }

    public enum SubmissionType {
        ORIGINAL, REVISION
    }

    public enum Verdict {
        STRONG_BUY, BUY, HOLD, AVOID, INSUFFICIENT_DATA
    }
}
