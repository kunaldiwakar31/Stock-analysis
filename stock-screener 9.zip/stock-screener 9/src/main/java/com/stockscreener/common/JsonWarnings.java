package com.stockscreener.common;

import java.util.List;

/**
 * Tiny helper for the {@code warnings} JSON-array columns ({@code financials.warnings},
 * {@code company_metrics.warnings}).
 *
 * <p>Deliberately not a real JSON library: every warning here is an internally-generated
 * snake_case token, never user input, so string concatenation is safe and avoids pulling
 * in a JSON dependency for a one-line array.
 */
public final class JsonWarnings {

    private JsonWarnings() {
    }

    public static String arrayOf(List<String> items) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) {
                sb.append(',');
            }
            sb.append('"').append(items.get(i).replace("\"", "'")).append('"');
        }
        return sb.append(']').toString();
    }

    /** Appends one warning to an existing (possibly null/empty) JSON array. */
    public static String append(String json, String warning) {
        if (json == null || json.isBlank() || "[]".equals(json.trim())) {
            return "[\"" + warning + "\"]";
        }
        String trimmed = json.trim();
        if (trimmed.endsWith("]")) {
            return trimmed.substring(0, trimmed.length() - 1) + ",\"" + warning + "\"]";
        }
        return "[\"" + warning + "\"]";
    }
}
