package com.stockscreener.domain.repo;

import com.stockscreener.domain.CompanyMetrics;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import java.util.Optional;

/**
 * The screener queries through {@link JpaSpecificationExecutor}, which is what lets the
 * query DSL compile to a Criteria tree with bound parameters instead of assembled SQL.
 */
public interface CompanyMetricsRepository
        extends JpaRepository<CompanyMetrics, Long>, JpaSpecificationExecutor<CompanyMetrics> {

    Optional<CompanyMetrics> findBySymbol(String symbol);
}
