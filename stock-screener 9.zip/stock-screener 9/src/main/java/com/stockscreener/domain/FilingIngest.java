package com.stockscreener.domain;

import com.stockscreener.domain.Enums.IngestStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Work queue and audit log for filing downloads.
 *
 * <p>Operational, not domain data. It exists because ingesting roughly 23,000 filings
 * needs restartability and a record of what failed and why — without it a failed run
 * either re-downloads everything or silently drops filings.
 *
 * <p>The unique key is the XBRL URL. Filings are immutable and a revision arrives as a
 * new URL, so the URL is both the natural identifier and the guarantee that repeated
 * imports of overlapping daily index files stay idempotent.
 */
@Entity
@Table(name = "filing_ingest")
@Getter
@Setter
public class FilingIngest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 30)
    private String symbol;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "quarter_end", nullable = false)
    private LocalDate quarterEnd;

    @Column(nullable = false)
    private boolean consolidated;

    @Column(name = "submission_type", nullable = false, length = 12)
    private String submissionType;

    private Boolean audited;

    @Column(name = "xbrl_url", nullable = false, unique = true, length = 700)
    private String xbrlUrl;

    @Column(name = "html_url", length = 700)
    private String htmlUrl;

    @Column(name = "broadcast_at")
    private LocalDateTime broadcastAt;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 12)
    private IngestStatus status = IngestStatus.PENDING;

    @Column(nullable = false)
    private Integer attempts = 0;

    @Column(name = "error_message", columnDefinition = "text")
    private String errorMessage;

    @Column(name = "created_at", insertable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at", insertable = false, updatable = false)
    private LocalDateTime updatedAt;
}
