package com.stockscreener.technicals;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * One day's indicator values, aligned to a {@link PricePoint} at the same index in the input
 * series. Same null-in-null-out rule as {@code RatioOutputs}: a field is null whenever the
 * trailing window it needs isn't fully covered by history yet (e.g. {@code ema200} for a
 * company with under 200 days on file), never a zero or a guess.
 */
public class TechnicalIndicatorResult {

    public LocalDate date;
    public BigDecimal close;

    public BigDecimal ema20;
    public BigDecimal ema50;
    public BigDecimal ema200;
    public BigDecimal sma20;
    public BigDecimal sma50;
    public BigDecimal sma200;

    public BigDecimal rsi14;

    public BigDecimal macd;
    public BigDecimal macdSignal;
    public BigDecimal macdHistogram;

    public BigDecimal atr14;

    public BigDecimal bollingerUpper;
    public BigDecimal bollingerMiddle;
    public BigDecimal bollingerLower;

    public Long volume;
    public BigDecimal volumeSma20;

    public BigDecimal deliveryPct;

    public final List<String> warnings = new ArrayList<>();

    public void warn(String w) {
        warnings.add(w);
    }
}
