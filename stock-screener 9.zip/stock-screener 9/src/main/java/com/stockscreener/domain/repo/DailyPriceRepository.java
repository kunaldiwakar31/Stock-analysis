package com.stockscreener.domain.repo;

import com.stockscreener.domain.DailyPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface DailyPriceRepository extends JpaRepository<DailyPrice, Long> {

    Optional<DailyPrice> findByCompanyIdAndTradeDate(Long companyId, LocalDate tradeDate);

    Optional<DailyPrice> findFirstByCompanyIdOrderByTradeDateDesc(Long companyId);

    /** 52-week high, computed from stored history rather than trusted from a feed. */
    @Query("select max(p.highPrice) from DailyPrice p "
            + "where p.companyId = :companyId and p.tradeDate >= :from")
    BigDecimal findHigh(@Param("companyId") Long companyId, @Param("from") LocalDate from);

    @Query("select min(p.lowPrice) from DailyPrice p "
            + "where p.companyId = :companyId and p.tradeDate >= :from")
    BigDecimal findLow(@Param("companyId") Long companyId, @Param("from") LocalDate from);

    /** Retention: history older than the 52-week window is only dead weight. */
    @Modifying
    @Transactional
    @Query("delete from DailyPrice p where p.tradeDate < :before")
    int deleteOlderThan(@Param("before") LocalDate before);

    List<DailyPrice> findByTradeDate(LocalDate tradeDate);

    /** Oldest first — the order technical indicators are computed forward over. */
    List<DailyPrice> findByCompanyIdOrderByTradeDateAsc(Long companyId);

    /** Distinct company ids that have at least one stored price, for driving the compute job. */
    @Query("select distinct p.companyId from DailyPrice p")
    List<Long> findCompanyIdsWithData();
}
