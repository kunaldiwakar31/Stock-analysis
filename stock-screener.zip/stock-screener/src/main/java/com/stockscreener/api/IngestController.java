package com.stockscreener.api;

import com.stockscreener.domain.Enums.IngestStatus;
import com.stockscreener.domain.repo.FilingIngestRepository;
import com.stockscreener.ingest.FilingIndexImporter;
import com.stockscreener.ingest.FilingParseService;
import com.stockscreener.metrics.MetricsService;
import com.stockscreener.prices.BhavcopyLoader;
import com.stockscreener.xbrl.ConceptMap;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1")
public class IngestController {

    private final FilingIndexImporter importer;
    private final FilingParseService parser;
    private final BhavcopyLoader bhavcopy;
    private final MetricsService metrics;
    private final FilingIngestRepository ingests;
    private final ConceptMap concepts;

    public IngestController(FilingIndexImporter importer, FilingParseService parser,
                            BhavcopyLoader bhavcopy, MetricsService metrics,
                            FilingIngestRepository ingests, ConceptMap concepts) {
        this.importer = importer;
        this.parser = parser;
        this.bhavcopy = bhavcopy;
        this.metrics = metrics;
        this.ingests = ingests;
        this.concepts = concepts;
    }

    /** Upload the NSE integrated-filing index CSV. Safe to re-run on overlapping files. */
    @PostMapping("/filings")
    public FilingIndexImporter.ImportSummary importIndex(@RequestParam("file") MultipartFile file)
            throws IOException {
        return importer.importIndex(file.getInputStream());
    }

    /** Downloads and parses pending filings. Call repeatedly until nothing is pending. */
    @PostMapping("/jobs/parse")
    public Map<String, Object> parse(@RequestParam(value = "limit", defaultValue = "200")
                                     int limit) {
        int ok = parser.processPending(limit);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("processed", ok);
        out.put("stillPending", ingests.countByStatus(IngestStatus.PENDING));
        out.put("failed", ingests.countByStatus(IngestStatus.FAILED));
        return out;
    }

    /**
     * Loads one day's NSE bhavcopy.
     *
     * <p>Without this, ten metrics stay null — market cap, price, 52-week high and low,
     * P/E, P/B, EV/EBITDA and both yields. It is the single highest-leverage loader here.
     */
    @PostMapping("/prices/bhavcopy")
    public BhavcopyLoader.LoadSummary loadPrices(
            @RequestParam("file") MultipartFile file,
            @RequestParam("tradeDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
            LocalDate tradeDate) throws IOException {
        return bhavcopy.load(file.getInputStream(), tradeDate);
    }

    /** Recomputes every company's flat metrics row. */
    @PostMapping("/jobs/metrics")
    public Map<String, Object> recomputeMetrics() {
        return Map.of("companiesUpdated", metrics.recomputeAll());
    }

    @GetMapping("/jobs/status")
    public Map<String, Object> status() {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("pending", ingests.countByStatus(IngestStatus.PENDING));
        out.put("done", ingests.countByStatus(IngestStatus.DONE));
        out.put("failed", ingests.countByStatus(IngestStatus.FAILED));
        out.put("superseded", ingests.countByStatus(IngestStatus.SKIPPED));
        return out;
    }

    /**
     * XBRL concepts seen in filings that no field claims, most frequent first.
     *
     * <p>This is the endpoint that keeps parser coverage improving rather than quietly
     * decaying: it converts silent data loss into a ranked worklist for
     * {@code xbrl-concepts.yml}.
     */
    @GetMapping("/admin/unmapped-concepts")
    public List<Map<String, Object>> unmapped() {
        return concepts.unmappedByFrequency();
    }
}
