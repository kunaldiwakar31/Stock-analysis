package com.stockscreener.metrics;

import java.math.BigDecimal;
import java.util.NavigableMap;
import java.util.TreeMap;

/**
 * Everything {@link RatioCalculator} needs, assembled by the caller.
 *
 * <p><b>All money is in rupees lakh</b> (the unit NSE filings mostly use), except
 * {@link #currentPrice}, {@link #high52w}, {@link #low52w} and {@link #reportedEpsSum},
 * which are rupees per share. {@link #sharesOutstanding} is an absolute count.
 *
 * <p>Plain mutable fields on purpose: this is a data carrier assembled field-by-field
 * from several sources, and a 30-argument constructor would be worse.
 */
public class RatioInputs {

    /**
     * Months the flow figures cover. 12 for a clean trailing-twelve-months window,
     * 6 when only a half-year is available (which is the common case for balance-sheet
     * and cash-flow backed ratios, since SEBI requires those half-yearly).
     */
    public int windowMonths = 12;

    /** How many quarterly rows were summed. Below 4 the TTM is incomplete. */
    public int quartersUsed;

    // ---- Flows over windowMonths (rupees lakh) ----
    public BigDecimal revenue;
    public BigDecimal otherIncome;
    public BigDecimal ebitda;
    public BigDecimal depreciation;
    public BigDecimal financeCosts;
    public BigDecimal profitBeforeTax;
    public BigDecimal taxExpense;
    public BigDecimal netProfit;
    public BigDecimal cashFromOperations;
    public BigDecimal capex;
    public BigDecimal dividendsPaid;

    /** Reported EPS summed over the window; used only as a fallback. */
    public BigDecimal reportedEpsSum;

    // ---- Balance sheet, point in time (rupees lakh) ----
    public BigDecimal totalEquity;
    public BigDecimal prevTotalEquity;
    public BigDecimal totalBorrowings;
    public BigDecimal cashAndInvestments;
    public BigDecimal totalAssets;
    public BigDecimal prevTotalAssets;

    /** Months covered by the profit figure paired with this balance sheet. */
    public Integer balanceSheetWindowMonths;

    // ---- Share and price data ----
    public BigDecimal sharesOutstanding;
    public BigDecimal currentPrice;
    public BigDecimal high52w;
    public BigDecimal low52w;

    // ---- Latest quarter, for year-on-year ----
    public BigDecimal latestQuarterRevenue;
    public BigDecimal yearAgoQuarterRevenue;
    public BigDecimal latestQuarterNetProfit;
    public BigDecimal yearAgoQuarterNetProfit;

    // ---- Annual series for CAGR: fiscal year -> value ----
    public NavigableMap<Integer, BigDecimal> annualRevenue = new TreeMap<>();
    public NavigableMap<Integer, BigDecimal> annualNetProfit = new TreeMap<>();
    public NavigableMap<Integer, BigDecimal> annualEps = new TreeMap<>();

    /**
     * Banks and NBFCs. ROCE, debt/equity and EV/EBITDA are meaningless for them —
     * leverage of 6x is normal banking, not distress — so those are skipped rather
     * than emitted as nonsense.
     */
    public boolean financialCompany;
}
