package com.stockscreener.screener;

import com.stockscreener.domain.CompanyMetrics;
import com.stockscreener.domain.repo.CompanyMetricsRepository;
import com.stockscreener.screener.MetricDef.Availability;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Parses a query, runs it, and reports enough context for the result to be trusted. */
@Service
public class ScreenerService {

    private final CompanyMetricsRepository repo;
    private final int maxPredicates;
    private final int maxPageSize;

    public ScreenerService(CompanyMetricsRepository repo,
                           @Value("${app.screener.max-predicates:20}") int maxPredicates,
                           @Value("${app.screener.max-page-size:200}") int maxPageSize) {
        this.repo = repo;
        this.maxPredicates = maxPredicates;
        this.maxPageSize = maxPageSize;
    }

    public ScreenResult run(String query, String sort, int page, int size,
                            boolean strict, boolean includeFinancials) {

        QueryParser parser = new QueryParser(query, maxPredicates);
        Ast.Node ast = parser.parse();

        List<Ast.Node> leaves = new ArrayList<>();
        SpecCompiler.collect(ast, leaves);

        ScreenResult result = new ScreenResult();
        result.query = query;
        result.interpretation = interpret(leaves);
        result.warnings = availabilityWarnings(leaves);

        int capped = Math.min(Math.max(size, 1), maxPageSize);
        PageRequest pr = PageRequest.of(Math.max(page, 0), capped, parseSort(sort));

        SpecCompiler compiler = new SpecCompiler(strict, includeFinancials);
        Page<CompanyMetrics> hits = repo.findAll(compiler.compile(ast), pr);

        result.universe = repo.count();
        result.totalHits = hits.getTotalElements();
        result.page = hits.getNumber();
        result.size = hits.getSize();
        result.results = hits.getContent();
        // Counted rather than inferred from the shortfall: rows that simply failed the
        // filter and rows that had no value to test are different things, and conflating
        // them makes "6 of 2,337 matched" look like a bug.
        result.excludedForMissingData =
                repo.count(compiler.anyFilteredMetricMissing(leaves));
        return result;
    }

    /**
     * Echoes how each condition was read, including the unit conversion.
     *
     * <p>This is what makes the DSL trustworthy: seeing that {@code 1000cr} became
     * {@code 1000} crore against {@code market_cap_cr} lets the user believe the result
     * set instead of wondering whether the filter meant what they intended.
     */
    private List<Map<String, Object>> interpret(List<Ast.Node> leaves) {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Ast.Node n : leaves) {
            Map<String, Object> m = new LinkedHashMap<>();
            if (n instanceof Ast.Cmp) {
                Ast.Cmp c = (Ast.Cmp) n;
                m.put("metric", c.metric.key());
                m.put("attribute", c.metric.attribute());
                m.put("op", c.op);
                m.put("value", c.value);
                if (c.normalized != null) {
                    m.put("inputUnit", c.normalized.inputUnit);
                    m.put("storedUnit", c.normalized.storedUnit.name());
                }
                m.put("availability", c.metric.availability().name());
            } else if (n instanceof Ast.Between) {
                Ast.Between b = (Ast.Between) n;
                m.put("metric", b.metric.key());
                m.put("op", "BETWEEN");
                m.put("low", b.lo.value);
                m.put("high", b.hi.value);
                m.put("inputUnit", b.lo.inputUnit);
                m.put("availability", b.metric.availability().name());
            } else if (n instanceof Ast.In) {
                Ast.In in = (Ast.In) n;
                m.put("metric", in.metric.key());
                m.put("op", "IN");
                m.put("values", in.values);
                m.put("availability", in.metric.availability().name());
            } else if (n instanceof Ast.IsNull) {
                Ast.IsNull isn = (Ast.IsNull) n;
                m.put("metric", isn.metric.key());
                m.put("op", isn.negated ? "IS NOT NULL" : "IS NULL");
            }
            out.add(m);
        }
        return out;
    }

    /**
     * Flags conditions whose data does not refresh as often as a user might assume.
     *
     * <p>Without this, a screen on {@code roe} silently reflects a six-month-old balance
     * sheet, and a screen on {@code sales_growth_5y} returns nothing at all because the
     * history does not exist yet. Both look like bugs; neither is.
     */
    private List<String> availabilityWarnings(List<Ast.Node> leaves) {
        List<String> w = new ArrayList<>();
        for (Ast.Node n : leaves) {
            MetricDef m = metricOf(n);
            if (m == null) {
                continue;
            }
            if (m.availability() == Availability.HALF_YEARLY) {
                add(w, "'" + m.key() + "' is balance-sheet backed and refreshes half-yearly, "
                        + "not every quarter");
            } else if (m.availability() == Availability.NEEDS_PRICE) {
                add(w, "'" + m.key() + "' requires the bhavcopy price feed; rows without a "
                        + "loaded price are excluded");
            } else if (m.availability() == Availability.NEEDS_SHAREHOLDING) {
                add(w, "'" + m.key() + "' requires the NSE shareholding-pattern filing");
            } else if (m.availability() == Availability.NEEDS_HISTORY) {
                add(w, "'" + m.key() + "' needs several years of annual history and may be "
                        + "empty until it accumulates");
            } else if (m.availability() == Availability.NEEDS_ANALYSIS) {
                add(w, "'" + m.key() + "' is only set for companies that have had an LLM pass");
            }
        }
        return w;
    }

    private void add(List<String> list, String s) {
        if (!list.contains(s)) {
            list.add(s);
        }
    }

    private MetricDef metricOf(Ast.Node n) {
        if (n instanceof Ast.Cmp) {
            return ((Ast.Cmp) n).metric;
        }
        if (n instanceof Ast.Between) {
            return ((Ast.Between) n).metric;
        }
        if (n instanceof Ast.In) {
            return ((Ast.In) n).metric;
        }
        if (n instanceof Ast.IsNull) {
            return ((Ast.IsNull) n).metric;
        }
        return null;
    }

    /** Sort spec such as {@code roce:desc,marketcap:desc}, resolved through the whitelist. */
    private Sort parseSort(String sort) {
        if (sort == null || sort.trim().isEmpty()) {
            return Sort.by(Sort.Direction.DESC, "marketCapCr");
        }
        List<Sort.Order> orders = new ArrayList<>();
        for (String part : sort.split(",")) {
            String[] bits = part.trim().split(":");
            if (bits[0].isEmpty()) {
                continue;
            }
            MetricDef d = MetricRegistry.resolve(bits[0].trim(), 0);
            boolean desc = bits.length > 1 && bits[1].trim().equalsIgnoreCase("desc");
            orders.add(new Sort.Order(desc ? Sort.Direction.DESC : Sort.Direction.ASC,
                    d.attribute()).nullsLast());
        }
        return orders.isEmpty() ? Sort.unsorted() : Sort.by(orders);
    }

    /** Parse-only, for the validate endpoint and editor autocomplete. */
    public List<Map<String, Object>> validate(String query) {
        Ast.Node ast = new QueryParser(query, maxPredicates).parse();
        List<Ast.Node> leaves = new ArrayList<>();
        SpecCompiler.collect(ast, leaves);
        return interpret(leaves);
    }

    /** The metric registry, for autocomplete. */
    public List<Map<String, Object>> metrics() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (MetricDef d : MetricRegistry.all()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("key", d.key());
            m.put("label", d.label());
            m.put("unit", d.unit().name());
            m.put("availability", d.availability().name());
            m.put("aliases", d.aliases());
            out.add(m);
        }
        return out;
    }

    /** Result envelope returned by the screener endpoint. */
    public static class ScreenResult {
        public String query;
        public List<Map<String, Object>> interpretation;
        public long universe;
        public long totalHits;
        public long excludedForMissingData;
        public int page;
        public int size;
        public List<String> warnings;
        public List<CompanyMetrics> results;
        public final String disclaimer =
                "Derived from public NSE filings. Not investment advice.";
    }
}
