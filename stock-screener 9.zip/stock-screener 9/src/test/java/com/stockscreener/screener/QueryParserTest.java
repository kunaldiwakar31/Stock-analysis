package com.stockscreener.screener;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Query language tests.
 *
 * <p>The {@link RealWorldQueries} block is the regression suite that matters: it is the
 * list of queries the screener is meant to support, asserted end to end. Without it a
 * grammar change can silently alter what an existing saved query means, which is the one
 * failure mode a user has no way to notice.
 */
class QueryParserTest {

    private static Ast.Node parse(String q) {
        return new QueryParser(q).parse();
    }

    private static List<Ast.Node> leaves(String q) {
        List<Ast.Node> out = new ArrayList<>();
        SpecCompiler.collect(parse(q), out);
        return out;
    }

    private static Ast.Cmp onlyCmp(String q) {
        List<Ast.Node> l = leaves(q);
        assertEquals(1, l.size());
        return assertInstanceOf(Ast.Cmp.class, l.get(0));
    }

    @Nested
    @DisplayName("Structure")
    class Structure {

        @Test
        void commaBindsAsAnd() {
            // The shorthand the user actually types must not need the AND keyword.
            Ast.Node n = parse("roe > 18%, roce > 20%, marketcap > 1000cr");
            Ast.And and = assertInstanceOf(Ast.And.class, n);
            assertEquals(3, and.children.size());
        }

        @Test
        void andBindsTighterThanOr() {
            Ast.Node n = parse("roe > 18% AND roce > 20% OR pe < 10");
            Ast.Or or = assertInstanceOf(Ast.Or.class, n);
            assertEquals(2, or.children.size());
            assertInstanceOf(Ast.And.class, or.children.get(0));
            assertInstanceOf(Ast.Cmp.class, or.children.get(1));
        }

        @Test
        void parenthesesOverridePrecedence() {
            Ast.Node n = parse("(sector = \"IT\" OR sector = \"Pharma\") AND roce > 20%");
            Ast.And and = assertInstanceOf(Ast.And.class, n);
            assertInstanceOf(Ast.Or.class, and.children.get(0));
        }

        @Test
        void supportsNotBetweenInAndNullChecks() {
            assertInstanceOf(Ast.Not.class, parse("NOT roe > 18%"));
            assertInstanceOf(Ast.Between.class, parse("marketcap BETWEEN 500cr AND 5000cr"));
            assertInstanceOf(Ast.In.class, parse("verdict IN (\"BUY\", \"STRONG_BUY\")"));
            assertInstanceOf(Ast.IsNull.class, parse("pe IS NULL"));
            Ast.IsNull notNull = assertInstanceOf(Ast.IsNull.class, parse("pe IS NOT NULL"));
            assertTrue(notNull.negated);
        }

        @Test
        void acceptsSymbolicOperators() {
            assertInstanceOf(Ast.And.class, parse("roe > 18% && de < 0.5"));
            assertInstanceOf(Ast.Or.class, parse("pe < 10 || pb < 1"));
        }

        @Test
        void resolvesAliasesToTheCanonicalColumn() {
            assertEquals("roePct", onlyCmp("return_on_equity > 18%").metric.attribute());
            assertEquals("marketCapCr", onlyCmp("mcap > 1000cr").metric.attribute());
            assertEquals("debtToEquity", onlyCmp("debt_to_equity < 0.5").metric.attribute());
        }
    }

    @Nested
    @DisplayName("Unit normalisation")
    class Units {

        @Test
        void percentSuffixIsOptional() {
            assertEquals(bd("18"), onlyCmp("roe > 18%").value);
            assertEquals(bd("18"), onlyCmp("roe > 18").value);
        }

        @Test
        void rejectsAFractionOnAPercentMetric() {
            // Silently reading this as "0.18 percent" would return zero rows and look
            // like the screener was broken rather than the query being wrong.
            QueryException e = assertThrows(QueryException.class, () -> parse("roe > 0.18"));
            assertEquals("AMBIGUOUS_PERCENT", e.getCode());
            assertTrue(e.getMessage().contains("18"), "the error should suggest 18%");
        }

        @Test
        void allowsAnExplicitSmallPercentage() {
            // A dividend yield of half a percent is entirely ordinary.
            assertEquals(bd("0.5"), onlyCmp("div_yield > 0.5%").value);
        }

        @Test
        void allowsZeroOnAPercentMetric() {
            assertEquals(bd("0"), onlyCmp("promoter_pledge = 0").value);
        }

        @Test
        void croreIsTheDefaultForAmounts() {
            assertEquals(bd("1000"), onlyCmp("marketcap > 1000cr").value);
            assertEquals(bd("1000"), onlyCmp("marketcap > 1000").value);
            assertEquals(bd("500"), onlyCmp("sales > 500crore").value);
        }

        @Test
        void convertsLakhToCrore() {
            assertEquals(0, bd("50").compareTo((BigDecimal) onlyCmp("marketcap > 5000L").value));
        }

        @Test
        void rejectsAnImplausiblyLargeAmount() {
            // Someone typing rupees rather than crore.
            QueryException e = assertThrows(QueryException.class,
                    () -> parse("marketcap > 10000000000"));
            assertEquals("AMBIGUOUS_SCALE", e.getCode());
        }

        @Test
        void rejectsAUnitThatDoesNotFitTheMetric() {
            QueryException e = assertThrows(QueryException.class, () -> parse("pe > 20%"));
            assertEquals("WRONG_UNIT", e.getCode());
        }

        @Test
        void multipleAndDaySuffixesAreOptional() {
            assertEquals(bd("0.5"), onlyCmp("de < 0.5x").value);
            assertEquals(bd("0.5"), onlyCmp("de < 0.5").value);
        }

        @Test
        void recordsTheInputUnitForTheInterpretationEcho() {
            Ast.Cmp c = onlyCmp("marketcap > 1000cr");
            assertNotNull(c.normalized);
            assertEquals("CRORE", c.normalized.inputUnit);
            assertEquals(Unit.CRORE, c.normalized.storedUnit);
        }
    }

    @Nested
    @DisplayName("Errors point at the problem")
    class Errors {

        @Test
        void unknownMetricSuggestsTheNearestName() {
            QueryException e = assertThrows(QueryException.class, () -> parse("roec > 20%"));
            assertEquals("UNKNOWN_METRIC", e.getCode());
            assertTrue(e.getSuggestions().contains("roce"),
                    "expected 'roce' among " + e.getSuggestions());
            assertEquals(0, e.getPosition());
        }

        @Test
        void reportsThePositionOfALaterError() {
            QueryException e = assertThrows(QueryException.class,
                    () -> parse("roe > 18% AND rocce > 20%"));
            assertTrue(e.getPosition() > 10, "position was " + e.getPosition());
        }

        @Test
        void rejectsAnEmptyQuery() {
            assertEquals("EMPTY_QUERY",
                    assertThrows(QueryException.class, () -> parse("")).getCode());
        }

        @Test
        void rejectsAMissingOperatorOrValue() {
            assertThrows(QueryException.class, () -> parse("roe 18"));
            assertThrows(QueryException.class, () -> parse("roe >"));
            assertThrows(QueryException.class, () -> parse("roe > 18% AND"));
        }

        @Test
        void rejectsUnbalancedParentheses() {
            assertThrows(QueryException.class, () -> parse("(roe > 18%"));
        }

        @Test
        void rejectsAnInvertedRange() {
            QueryException e = assertThrows(QueryException.class,
                    () -> parse("marketcap BETWEEN 5000cr AND 500cr"));
            assertEquals("BAD_RANGE", e.getCode());
        }

        @Test
        void rejectsFuzzyMatchOnANumericMetric() {
            QueryException e = assertThrows(QueryException.class, () -> parse("roe ~ \"high\""));
            assertEquals("TYPE_MISMATCH", e.getCode());
        }

        @Test
        void capsPredicateCount() {
            StringBuilder sb = new StringBuilder("roe > 1%");
            for (int i = 0; i < 25; i++) {
                sb.append(", roe > 1%");
            }
            QueryException e = assertThrows(QueryException.class,
                    () -> new QueryParser(sb.toString(), 20).parse());
            assertEquals("TOO_MANY_PREDICATES", e.getCode());
        }
    }

    @Nested
    @DisplayName("Real-world queries the screener must support")
    class RealWorldQueries {

        @Test
        void allSupportedQueriesParse() {
            String[] queries = {
                    "roe > 18%, roce > 20%, marketcap > 1000cr",
                    "roe > 18% AND roce > 20% AND marketcap > 1000cr",
                    "roe > 15% AND de < 0.5 AND pe < 25 AND sales_growth_3y > 15%",
                    "marketcap BETWEEN 500cr AND 5000cr AND roce > 20% AND de < 0.3",
                    "pe < 15 AND pb < 2 AND roe > 15% AND div_yield > 2%",
                    "ocf_to_pat > 0.9 AND net_margin > 12% AND roce > 20%",
                    "profit_growth_1y > 30% AND ocf_to_pat < 0.6",
                    "promoter_holding > 55% AND promoter_pledge = 0 AND roe > 15%",
                    "fii_holding > 10% AND dii_holding > 10% AND sales_growth_3y > 12%",
                    "pct_from_high < -30% AND roce > 18% AND de < 0.5 AND ocf_to_pat > 0.8",
                    "de = 0 AND sales_growth_3y > 20% AND opm > 15%",
                    "de > 2 AND interest_coverage < 2",
                    "qtr_profit_yoy > 50% AND qtr_sales_yoy > 15% AND opm > 10%",
                    "verdict IN (\"BUY\",\"STRONG_BUY\") AND llm_score > 70",
                    "roe > 20% AND NOT (de > 1 OR interest_coverage < 3)",
                    "(sector = \"Pharmaceuticals\" OR sector = \"IT\") AND roce > 20%",
                    "name ~ \"jewell\" AND opm > 8%",
                    "eps > 10 AND net_profit > 100cr",
                    "fcf > 100cr AND pe IS NOT NULL",
                    "data_completeness > 70 AND roe > 15%"
            };
            for (String q : queries) {
                assertNotNull(parse(q), q);
            }
        }

        @Test
        void theHeadlineQueryCompilesToTheExpectedPredicates() {
            List<Ast.Node> l = leaves("roe > 18% AND roce > 20% AND marketcap > 1000cr");
            assertEquals(3, l.size());

            Ast.Cmp roe = assertInstanceOf(Ast.Cmp.class, l.get(0));
            assertEquals("roePct", roe.metric.attribute());
            assertEquals(">", roe.op);
            assertEquals(bd("18"), roe.value);

            Ast.Cmp roce = assertInstanceOf(Ast.Cmp.class, l.get(1));
            assertEquals("rocePct", roce.metric.attribute());

            Ast.Cmp mcap = assertInstanceOf(Ast.Cmp.class, l.get(2));
            assertEquals("marketCapCr", mcap.metric.attribute());
            assertEquals(bd("1000"), mcap.value);
            assertEquals(MetricDef.Availability.NEEDS_PRICE, mcap.metric.availability());
        }

        @Test
        void metricsCarryAvailabilitySoEmptyResultsAreExplicable() {
            assertEquals(MetricDef.Availability.HALF_YEARLY,
                    onlyCmp("roe > 18%").metric.availability());
            assertEquals(MetricDef.Availability.QUARTERLY,
                    onlyCmp("opm > 20%").metric.availability());
            assertEquals(MetricDef.Availability.NEEDS_HISTORY,
                    onlyCmp("sales_growth_5y > 10%").metric.availability());
            assertEquals(MetricDef.Availability.NEEDS_SHAREHOLDING,
                    onlyCmp("promoter_holding > 50%").metric.availability());
        }

        @Test
        void everyRegisteredMetricIsQueryable() {
            for (MetricDef d : MetricRegistry.all()) {
                String q;
                switch (d.unit()) {
                    case TEXT:
                    case ENUM:
                        q = d.key() + " = \"x\"";
                        break;
                    case BOOL:
                        q = d.key() + " = true";
                        break;
                    default:
                        q = d.key() + " > 1";
                        break;
                }
                assertNotNull(parse(q), "not queryable: " + d.key());
            }
            assertFalse(MetricRegistry.all().isEmpty());
        }
    }

    private static BigDecimal bd(String s) {
        return new BigDecimal(s);
    }
}
