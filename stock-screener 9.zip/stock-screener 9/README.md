# Stock Screener

Fundamental screener over NSE integrated filings. Java 21 / Spring Boot 3.3 / MySQL 8.

Ingests the NSE filing index CSV → parses the linked **XBRL** instances → computes ratios →
stores one flat row per company → filters with a query language:

```
roe > 18%, roce > 20%, marketcap > 1000cr
```

---

## Quick start

```bash
docker compose up -d              # MySQL 8 on :3306
mvn spring-boot:run               # Flyway creates the schema on boot
# Swagger UI at http://localhost:8080/swagger-ui.html
```

Then, in order:

```bash
BASE=http://localhost:8080/api/v1

# 1. Upload the NSE integrated-filing index CSV. Safe to re-run on overlapping files.
curl -F "file=@CF-Integrated-Filing-equities-*.csv" $BASE/filings

# 2. Download and parse queued filings. Repeat until "stillPending" is 0.
curl -X POST "$BASE/jobs/parse?limit=200"

# 3. Load a day's prices. Without this, 10 metrics stay null (P/E, P/B, market cap...).
curl -F "file=@bhavcopy.csv" "$BASE/prices/bhavcopy?tradeDate=2026-08-04"

# 4. Compute the flat metrics rows.
curl -X POST $BASE/jobs/metrics

# 5. Screen.
curl -G $BASE/screener --data-urlencode "q=roe > 18% AND roce > 20% AND marketcap > 1000cr"
```

---

## Schema — 5 tables

| Table | Contents |
|---|---|
| `companies` | Symbol, ISIN, sector, face value, derived share count |
| `financials` | 21 line items per period. `period_type = Q \| FY` in one table. **Rupees lakh** |
| `daily_prices` | Bhavcopy close/high/low. Exists only because 52-week high and low need history |
| `company_metrics` | ~45 computed ratios, one flat row per company. **Rupees crore** |
| `filing_ingest` | Download queue and audit log. Operational, not domain data |

`company_metrics` is wide and denormalised deliberately: every screener query hits one
table with no joins, which is what makes a multi-condition filter a single indexed scan.

Money is stored in **lakh** in `financials` (the unit filings use) and **crore** in
`company_metrics` (the unit users type). Conversion happens once, on write.

---

## Four things that will silently corrupt results

These are not hypothetical. Each one produces plausible-looking wrong numbers rather than
an error, which is why each has a dedicated guard and test.

### 1. The rounding level is declared per filing

`Level of rounding used in financial results` varies: Lakhs, Thousands, Millions, Crores.
The same concept therefore arrives at hundredfold-different magnitudes across companies.

- Everything is normalised to lakh on write (`RoundingLevel`).
- **A filing with no declared level is rejected, not guessed at.**
- Independent cross-check: `paid_up_capital / face_value` must imply a plausible share
  count. On the Thyrocare fixture this reproduces the filed EPS of ₹14.92 exactly, which
  validates the scaling end to end.

### 2. Balance sheet and cash flow are not quarterly

SEBI LODR requires them half-yearly. So margins, EPS and growth refresh every quarter, but
**ROE, ROCE, debt/equity and cash-quality metrics do not.** Every metric carries an
`Availability` flag, and the screener warns rather than returning a confusing empty set.

Consequence in the code: cash flow is attached only to rows whose window matches
(`FilingExtractor`), and cash-quality ratios are computed from the latest full year.
Pairing a six-month operating cash flow with a twelve-month profit would halve OCF/PAT.

### 3. Quarter versus year-to-date

Filings carry both a three-month and a cumulative column; some filers populate only the
latter. `FilingParseService.deriveQuarterFromYtd` back-computes `YTD(n) − YTD(n−1)`, within
one fiscal year and one basis only, and labels the row `YTD_DIFF`.

Q4 is the trap: often filed as audited full-year figures only, so the derived quarter
absorbs every year-end adjustment at once. Flagged `q4_derived_from_fy_minus_9m`.

### 4. Consolidated versus standalone

Both are filed. Consolidated is preferred and the basis used is recorded on every metrics
row — standalone accounts hide subsidiary debt and losses.

---

## Ratio conventions worth knowing

| Decision | Why |
|---|---|
| **ROCE does not net cash** from capital employed | Both forms are defensible but diverge sharply: on the Thyrocare fixture, netting ~₹15,000 lakh of cash moves ROCE from **43.8% to 62.0%**. The unnetted form is what Indian screeners report. Netting is reserved for enterprise value |
| **EBITDA excludes other income** | Keeps the margin about the operating business; treasury income at a cash-rich company would otherwise inflate it |
| **EPS derived from net profit ÷ share count** | A sum of reported quarterly EPS breaks whenever the share count changed mid-year |
| **Flows annualised before dividing by a stock** | A six-month profit over point-in-time equity reads as half the true ROE |
| **CAGR is null when the base is ≤ 0** | An n-th root across a sign flip is not a growth rate |
| **Nulls never become zero** | A missing balance sheet is not zero equity |
| **Nothing is clamped** | An ROE of 412% is reported as 412% with a warning; `strict=true` excludes it from screens |

---

## Query language

```
query      := orExpr
orExpr     := andExpr ( "OR" | "||" ) andExpr )*
andExpr    := notExpr ( ("AND" | "&&" | ",") notExpr )*    -- ',' is implicit AND
notExpr    := "NOT"? primary
primary    := "(" orExpr ")" | comparison
comparison := metric op value
            | metric "BETWEEN" value "AND" value
            | metric "IN" "(" value,... ")"
            | metric "IS" "NOT"? "NULL"
op         := > | >= | < | <= | = | != | ~        -- '~' is contains, text only
```

**Safety.** Metric names resolve through the `MetricRegistry` whitelist; anything else is a
400 with suggestions. The AST compiles to a JPA Criteria `Specification` with bound
parameters. No SQL text is assembled and no user string reaches SQL, so injection is
structurally impossible rather than filtered for.

**Units.** Ambiguous input is rejected with an explanation, because a silently wrong result
is worse than an error:

| Input | Result |
|---|---|
| `roe > 18%` / `roe > 18` | 18 |
| `roe > 0.18` | **400** — "did you mean 18%?" |
| `div_yield > 0.5%` | 0.5 — explicit, so accepted |
| `marketcap > 1000cr` / `> 1000` | 1000 crore |
| `marketcap > 5000L` | 50 crore |
| `marketcap > 10000000000` | **400** — implausible for a crore value |
| `de < 0.5x` / `de < 0.5` | 0.5 |

**NULL semantics.** Comparisons exclude nulls, so `roe > 18` never matches a company with
no computable ROE. The corollary is that `NOT (roe > 18)` excludes it too — intentional,
and documented in `SpecCompiler`.

Responses echo an `interpretation` block showing how each condition was read, including the
unit conversion. That is what makes a result set trustworthy.

---

## What the data supports today

Computable from the index CSV alone: **ROE, ROCE, ROA, operating and net margin,
debt/equity, interest coverage, book value, OCF/PAT, FCF, all TTM absolutes, 1-year growth,
quarterly year-on-year.**

Blocked, and why:

| Missing | Needs |
|---|---|
| Market cap, price, 52w high/low, P/E, P/B, EV/EBITDA, both yields | NSE daily bhavcopy — one small loader, highest leverage by far |
| Promoter / pledge / FII / DII holding | NSE shareholding-pattern filing (separate quarterly filing) |
| Sector, `is_financial_co` | NSE industry classification mapping |
| 2/3/5-year growth | More annual history. The index file spans ~6 quarters, giving FY25 and FY26 only |

Start the daily index download early: history depth is the one thing that cannot be
retrofitted.

---

## XBRL concept mapping

`src/main/resources/xbrl-concepts.yml` maps taxonomy concepts to fields as **ordered
candidate aliases**. Exact element names vary across SEBI taxonomy revisions and preparers,
so this is config rather than code.

> **The shipped aliases are best-effort and must be verified against real instances.**
> A field that never matches stays silently null, and a null revenue yields a null margin,
> which the screener then quietly excludes.

Workflow:

```bash
curl -X POST "$BASE/jobs/parse?limit=50"
curl $BASE/admin/unmapped-concepts     # ranked by frequency
# add the real names to xbrl-concepts.yml, then re-parse from the on-disk cache
```

### Debugging a filing that stored nulls

```bash
curl -G $BASE/admin/inspect-filing \
  --data-urlencode "url=https://nsearchives.nseindia.com/corporate/xbrl/….xml" \
  --data-urlencode "quarterEnd=2025-09-30"
```

Dry run, saves nothing. Returns every context with its period, dimensions and fact count,
the rows that would have been extracted, and any concept in the instance that no field
claims. That distinguishes the three causes: the statement sits on a context you didn't
expect, the period end doesn't match, or a concept alias is wrong.

### How contexts are chosen

Selection is **fact-driven, not shape-driven** — it picks the context that actually carries
the mapped concepts, then uses shape only to rank ties. Matching on shape alone (plain,
duration, exact end date) worked only when the primary statement happened to sit on the
undimensioned context, typically `OneD`, and silently produced a row of nulls otherwise.
Four specific causes, all now handled:

| Cause | Handling |
|---|---|
| Statement tagged on an axis, so its context is dimensioned | Dimensioned contexts are ranked lower, not rejected. Flagged `pnl_on_dimensioned_context_…` |
| Period end a day or two off the exchange label (52/53-week filers) | ±7 day tolerance, and the actual date is recorded in warnings |
| A date the parser couldn't read, leaving the period null | `parseDate` accepts ISO, timezone-suffixed, `dd-MM-yyyy` and `dd-MMM-yyyy` |
| Two same-shaped contexts, resolved by HashMap order | Candidates sorted deterministically; ties break on context id |

Prior-year comparatives live in the same instance and are excluded by the date window.
When nothing matches, every context is logged and returned in `contextDump` rather than
stored as nulls.

Instances are cached on disk by URL hash. Filings are immutable and a revision arrives as a
new URL, so re-parsing 23,000 filings after a mapping fix costs no downloads.

---

## Tests

```bash
mvn test
```

| Suite | Covers |
|---|---|
| `RatioCalculatorTest` | Thyrocare H1 FY26 verified by hand; null-safety; extreme values; CAGR guards |
| `FilingExtractorContextTest` | Context selection: dimensioned statements, prior-year comparatives, off-by-days period ends, quarter vs cumulative, date-format variants |
| `QueryParserTest` | Grammar, unit normalisation, positioned errors, and the real-world query regression list |
| `RoundingLevelTest` | Scale normalisation and the share-count cross-check |
| `FiscalCalendarTest` | April–March year, quarter mapping, month-end arithmetic |
| `IndexCsvReaderTest` | The real CSV's BOM and newline-laden header names |

The Thyrocare fixture is load-bearing: total assets equal equity plus liabilities to the
rupee, and derived EPS reproduces the filed ₹14.92. Both would break under a mapping or
scale error.

**Do not extend the pipeline until `RatioCalculatorTest` passes against a hand-checked
filing.** A scale or annualisation bug at that layer is invisible to every test above it.

---

## Layout

```
common/     Nums, RoundingLevel, FiscalCalendar   — pure, no Spring
metrics/    RatioCalculator (pure) + MetricsService (assembly)
screener/   Lexer, QueryParser, MetricRegistry, ValueNormalizer, SpecCompiler
xbrl/       XbrlStaxParser, ConceptMap, FilingExtractor, XbrlFetcher
ingest/     IndexCsvReader, FilingIndexImporter, FilingParseService
prices/     BhavcopyLoader
llm/        LlmClient + Anthropic implementation + AnalysisService
domain/     Entities and repositories
api/        Controllers and the exception handler
```

`metrics/RatioCalculator` and everything in `common/` have no Spring or database
dependency. Keep it that way — it is what makes the formulas testable.

---

## LLM analysis (optional, off by default)

```yaml
app.llm.enabled: true
app.llm.api-key: ${ANTHROPIC_API_KEY}
```

**Java computes every number; the model only interprets them.** Nothing is asked of the
model that arithmetic can answer, so a wrong verdict is a judgement call rather than a
miscalculation. Nulls and warnings are passed through, and companies below 40% data
completeness are marked `INSUFFICIENT_DATA` without an API call.

---

## Not investment advice

Derived from public NSE filings. Parsers break silently, filers restate figures, balance
sheets arrive half-yearly, and an LLM verdict is an opinion generated from a prompt. Every
`financials` row keeps its `source_url` so any number can be checked against the original
filing.
