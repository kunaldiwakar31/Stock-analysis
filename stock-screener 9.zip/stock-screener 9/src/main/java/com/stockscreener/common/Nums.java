package com.stockscreener.common;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * Null-safe BigDecimal helpers.
 *
 * <p>The governing rule everywhere in this project: <b>any null input yields a null
 * output, and zero is never substituted for missing data.</b> A company with no filed
 * balance sheet does not have zero equity — it has unknown equity, and every ratio
 * derived from it must be null so the screener can exclude it rather than match it.
 */
public final class Nums {

    public static final MathContext MC = new MathContext(16, RoundingMode.HALF_UP);
    public static final BigDecimal HUNDRED = BigDecimal.valueOf(100);
    public static final BigDecimal TWELVE = BigDecimal.valueOf(12);

    private Nums() {
    }

    /** a / b, or null if either side is missing or b is zero. */
    public static BigDecimal div(BigDecimal a, BigDecimal b) {
        if (a == null || b == null || b.signum() == 0) {
            return null;
        }
        return a.divide(b, MC);
    }

    /** a / b as a percentage (18.5 means 18.5%). */
    public static BigDecimal pct(BigDecimal a, BigDecimal b) {
        BigDecimal r = div(a, b);
        return r == null ? null : r.multiply(HUNDRED, MC);
    }

    public static BigDecimal add(BigDecimal... xs) {
        BigDecimal sum = null;
        for (BigDecimal x : xs) {
            if (x == null) {
                return null;
            }
            sum = (sum == null) ? x : sum.add(x, MC);
        }
        return sum;
    }

    /** Adds only the non-null terms; returns null only when every term is null. */
    public static BigDecimal addLenient(BigDecimal... xs) {
        BigDecimal sum = null;
        for (BigDecimal x : xs) {
            if (x != null) {
                sum = (sum == null) ? x : sum.add(x, MC);
            }
        }
        return sum;
    }

    public static BigDecimal sub(BigDecimal a, BigDecimal b) {
        return (a == null || b == null) ? null : a.subtract(b, MC);
    }

    public static BigDecimal mul(BigDecimal a, BigDecimal b) {
        return (a == null || b == null) ? null : a.multiply(b, MC);
    }

    /** Scales a flow covering {@code months} up to a 12-month equivalent. */
    public static BigDecimal annualise(BigDecimal flow, int months) {
        if (flow == null || months <= 0) {
            return null;
        }
        if (months == 12) {
            return flow;
        }
        return flow.multiply(TWELVE, MC).divide(BigDecimal.valueOf(months), MC);
    }

    /** Average of two period-end stock values; falls back to whichever exists. */
    public static BigDecimal avg(BigDecimal a, BigDecimal b) {
        if (a == null) {
            return b;
        }
        if (b == null) {
            return a;
        }
        return a.add(b, MC).divide(BigDecimal.valueOf(2), MC);
    }

    /**
     * Compound annual growth rate as a percentage.
     *
     * <p>Returns null when {@code begin <= 0}: a sign flip (loss to profit, or negative
     * equity) makes the n-th root meaningless, and reporting a number there is worse
     * than reporting nothing. Callers should surface "turned profitable" separately.
     */
    public static BigDecimal cagrPct(BigDecimal begin, BigDecimal end, int years) {
        if (begin == null || end == null || years <= 0 || begin.signum() <= 0) {
            return null;
        }
        if (end.signum() <= 0) {
            return null;
        }
        double ratio = end.doubleValue() / begin.doubleValue();
        double growth = Math.pow(ratio, 1.0 / years) - 1.0;
        if (Double.isNaN(growth) || Double.isInfinite(growth)) {
            return null;
        }
        return BigDecimal.valueOf(growth * 100).round(MC);
    }

    /** Simple period-over-period change, guarding against a negative base. */
    public static BigDecimal changePct(BigDecimal from, BigDecimal to) {
        if (from == null || to == null || from.signum() == 0) {
            return null;
        }
        return to.subtract(from, MC).divide(from.abs(), MC).multiply(HUNDRED, MC);
    }

    /** Rupees lakh to rupees crore (the unit users type queries in). */
    public static BigDecimal lakhToCrore(BigDecimal lakh) {
        return lakh == null ? null : lakh.divide(HUNDRED, MC);
    }

    public static BigDecimal scale(BigDecimal v, int places) {
        return v == null ? null : v.setScale(places, RoundingMode.HALF_UP);
    }

    public static boolean isPositive(BigDecimal v) {
        return v != null && v.signum() > 0;
    }
}
